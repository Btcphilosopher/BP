package com.example.game

import com.example.data.WorldData
import com.example.models.*
import com.squareup.moshi.JsonClass
import kotlin.random.Random

@JsonClass(generateAdapter = true)
data class GameState(
    var currentMonth: Int = 0, // 0 is Jan 2026
    var playerCompany: Company = Company(
        id = "player",
        name = "Ashcombe Energy",
        isPlayer = true,
        cashM = 500.0, // $500 million cash
        debtM = 0.0,
        productionBOPD = 0.0,
        reservesM = 0.0,
        sharePrice = 10.0,
        sharesOutstandingM = 50.0,
        netWorthM = 500.0
    ),
    var aiCompanies: List<Company> = emptyList(),
    var regions: List<Region> = emptyList(),
    var licences: List<Licence> = emptyList(),
    var prospects: List<Prospect> = emptyList(),
    var wells: List<Well> = emptyList(),
    var fields: List<OilField> = emptyList(),
    var infrastructures: List<Infrastructure> = emptyList(),
    var technologies: List<Technology> = emptyList(),
    var market: MarketState = MarketState(
        brentPrice = 75.0,
        wtiPrice = 71.0,
        dubaiPrice = 73.0,
        gasPriceHenryHub = 3.20,
        gasPriceEurope = 12.50,
        gasPriceAsiaLNG = 14.00,
        globalSupplyMBPD = 101.5,
        globalDemandMBPD = 101.2,
        inventoryDays = 55.0,
        economyState = "Normal"
    ),
    var news: List<NewsItem> = emptyList(),
    var activeLoans: List<Loan> = emptyList(),
    var seed: Long = System.currentTimeMillis(),
    var selectedRegionId: String? = null,
    var selectedLicenceId: String? = null,
    var selectedFieldId: String? = null,
    var selectedWellId: String? = null,
    var currentScreen: String = "START_SCREEN", // START_SCREEN, DASHBOARD, WORLD, EXPLORE, ASSETS, MARKET, FINANCE, COMPANY, TECH, NEWS
    var companyNameInput: String = "Ashcombe Energy",
    var gameMode: String = "Career", // "Career", "Sandbox", "Scenario"
    var isGameOver: Boolean = false,
    var isVictory: Boolean = false,
    var tutorialStep: Int = 0 // 0 = not started, 1 = create company, etc.
) {
    companion object {
        fun createNewGame(name: String, mode: String, difficulty: String = "Normal"): GameState {
            val random = Random(System.currentTimeMillis())
            val seed = random.nextLong()

            val startingCash = when (mode) {
                "Sandbox" -> 5000.0 // $5 Billion in Sandbox
                else -> 500.0 // $500 Million in Career
            }

            val player = Company(
                id = "player",
                name = name.ifBlank { "Ashcombe Energy" },
                isPlayer = true,
                cashM = startingCash,
                debtM = 0.0,
                productionBOPD = 0.0,
                reservesM = 0.0,
                sharePrice = 10.0,
                sharesOutstandingM = 50.0,
                netWorthM = startingCash
            )

            // Dynamic licences generated initially
            val initialLicences = mutableListOf<Licence>()
            val initialProspects = mutableListOf<Prospect>()

            // Generate 3 random licences per region to start with
            WorldData.initialRegions.forEach { region ->
                for (i in 1..3) {
                    val block = "${region.id.take(3).uppercase()}-${100 + i * 23}"
                    val estResources = (50..600).random(random).toDouble()
                    val duration = 60 // 5 years
                    val licenseCost = (10..45).random(random).toDouble() * (region.potentialStars / 5.0)

                    val licence = Licence(
                        id = "lic_${region.id}_$i",
                        regionId = region.id,
                        blockNumber = block,
                        costM = licenseCost,
                        durationMonths = duration,
                        royaltyRate = 0.05 + (region.potentialStars * 0.02),
                        taxRate = region.governmentTake - 0.10,
                        estimatedResourcesM = estResources,
                        expiryMonth = duration,
                        seismicConfidence = 0.40
                    )
                    initialLicences.add(licence)

                    // Also generate 1-2 prospects inside each licence
                    val prospectsCount = (1..2).random(random)
                    for (p in 1..prospectsCount) {
                        val pMin = estResources * 0.2
                        val pMax = estResources * 0.8
                        val geologicalProb = 0.10 + (region.potentialStars * 0.12) - (if (region.geologicalRisk == "High") 0.15 else 0.0)
                        
                        val prospect = Prospect(
                            id = "prospect_${licence.id}_$p",
                            licenceId = licence.id,
                            name = "Prospect $block-$p",
                            estimatedResourcesMin = pMin,
                            estimatedResourcesMax = pMax,
                            geologicalProbability = geologicalProb.coerceIn(0.1, 0.9),
                            seismicConfidence = 0.40
                        )
                        initialProspects.add(prospect)
                    }
                }
            }

            return GameState(
                currentMonth = 0,
                playerCompany = player,
                aiCompanies = WorldData.initialCompetitors.map { it.copy() },
                regions = WorldData.initialRegions.map { it.copy() },
                licences = initialLicences,
                prospects = initialProspects,
                technologies = WorldData.initialTechnologies.map { it.copy() },
                seed = seed,
                currentScreen = "START_SCREEN",
                companyNameInput = name,
                gameMode = mode,
                news = listOf(
                    NewsItem(
                        id = "news_init",
                        dateStr = "Jan 2026",
                        title = "Global Energy Sector Enters New Era",
                        content = "A new group of private operators, including ${player.name}, has entered the global playing field. Brent crude starts steady at $75/bbl.",
                        type = "MARKET"
                    )
                )
            )
        }
    }

    val currentYearStr: String
        get() = (2026 + currentMonth / 12).toString()

    val currentMonthStr: String
        get() = when (currentMonth % 12) {
            0 -> "January"
            1 -> "February"
            2 -> "March"
            3 -> "April"
            4 -> "May"
            5 -> "June"
            6 -> "July"
            7 -> "August"
            8 -> "September"
            9 -> "October"
            10 -> "November"
            11 -> "December"
            else -> ""
        }
}
