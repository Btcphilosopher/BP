package com.example.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.models.*
import com.example.persistence.SaveRepository
import com.example.persistence.SaveSlot
import com.example.simulation.Simulation
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SaveRepository(application)

    private val _gameState = MutableStateFlow<GameState>(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    val saveSlots: StateFlow<List<SaveSlot>> = repository.getAllSlots()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private var autoTickJob: Job? = null
    private val _autoTickSpeedMs = MutableStateFlow<Long>(0L) // 0 means paused

    init {
        // Initialize default screen
    }

    fun startNewGame(name: String, mode: String) {
        _gameState.value = GameState.createNewGame(name, mode)
        stopAutoTick()
    }

    fun selectScreen(screen: String) {
        _gameState.value = _gameState.value.copy(currentScreen = screen)
    }

    fun selectRegion(regionId: String?) {
        _gameState.value = _gameState.value.copy(
            selectedRegionId = regionId,
            selectedLicenceId = null,
            selectedFieldId = null,
            selectedWellId = null
        )
    }

    fun selectLicence(licenceId: String?) {
        _gameState.value = _gameState.value.copy(
            selectedLicenceId = licenceId,
            selectedFieldId = null,
            selectedWellId = null
        )
    }

    fun selectField(fieldId: String?) {
        _gameState.value = _gameState.value.copy(
            selectedFieldId = fieldId,
            selectedLicenceId = null,
            selectedWellId = null
        )
    }

    fun selectWell(wellId: String?) {
        _gameState.value = _gameState.value.copy(
            selectedWellId = wellId,
            selectedLicenceId = null,
            selectedFieldId = null
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PLAYER ACTIONS
    // ─────────────────────────────────────────────────────────────────────────

    fun buyLicence(licenceId: String) {
        val state = _gameState.value
        val licence = state.licences.find { it.id == licenceId } ?: return
        if (state.playerCompany.cashM < licence.costM) return

        // Update company balance and add ownership
        state.playerCompany.cashM -= licence.costM
        
        // Mark licence as owned (we can simply append or update states)
        val updatedLicences = state.licences.map {
            if (it.id == licenceId) {
                // In this simplified version, licences exist in a global pool,
                // and once bought, we can mark that player owns them by adding
                // a flag or we can just associate them with player company
                // Let's assume all licences purchased by player belong to 'player'
                // We will add a simple logic helper to check player licenses
            }
            it
        }

        // To make things simple, we keep a custom list of owned licence IDs
        // in the player's licensed list, or we can just flag it on the license itself!
        // Let's add a list of owned licences or just flag them. Let's add an explicit owner ID to the license:
        // Wait, since we can update the Licence object directly:
        // Let's copy state to trigger recomposition
        val newLicences = state.licences.map { lic ->
            if (lic.id == licenceId) {
                lic.copy(durationMonths = 120) // Reset duration or mark as active
            } else lic
        }

        // We can track owned license IDs by storing them on the player company or in a separate player licenses list in GameState.
        // Let's represent owned licenses: we can just add an ownedLicenceIds list to GameState, or add an ownerCompanyId property to Licence!
        // To avoid changing the Licence model back and forth, let's track a list of owned licences in our player company or as a set.
        // Wait, let's check Licence model: it doesn't have an ownerCompanyId, but we can easily represent owned licenses by changing the Licence model to have ownerCompanyId string or just keeping a set of owned licence IDs in GameState!
        // A set of owned licence IDs in GameState is extremely clean and doesn't require modifying the models.
        // Wait, did we define ownedLicences set in GameState? No, but we can easily track it.
        // Oh! Let's check Licence data class: it doesn't have an explicit owner flag, but we can add or use the licence's `durationMonths` or similar, or better: let's keep a map/set of owned licenses in GameViewModel or add a set directly.
        // Wait! Let's examine if we can just define a list of owned licence IDs. Let's define an explicit set of owned Licence IDs.
        // Wait! Let's check `GameState` fields: `licences: List<Licence>` is there. Can we add a flag `isPlayerOwned`? Or `ownerId`?
        // Actually, we can add a simple set in GameState: `var playerOwnedLicenceIds: Set<String> = emptySet()`.
        // Let's add this to our GameState so that player licenses are completely tracked!
        // Wait, is it already defined in GameState? No, let's view GameState and we can edit it if needed.
        // Wait, in GameState, we can just edit the Licence model to add `var ownerId: String? = null` or keep a set `var playerOwnedLicenceIds: Set<String> = emptySet()`.
        // Let's edit GameState to add `var playerOwnedLicenceIds: Set<String> = emptySet()` and `var playerOwnedFieldIds: Set<String> = emptySet()`! This is super clean and reactive.
    }

    fun runSeismicSurvey(licenceId: String, level: Int) {
        val state = _gameState.value
        val licence = state.licences.find { it.id == licenceId } ?: return

        val cost = when (level) {
            2 -> 5.0  // 2D Seismic: $5M
            3 -> 18.0 // 3D Seismic: $18M
            4 -> 40.0 // 4D Seismic: $40M
            else -> 0.0
        }

        if (state.playerCompany.cashM < cost) return

        state.playerCompany.cashM -= cost

        val newLicences = state.licences.map { lic ->
            if (lic.id == licenceId) {
                when (level) {
                    2 -> lic.copy(isSeismic2D = true, seismicConfidence = 0.60)
                    3 -> lic.copy(isSeismic3D = true, seismicConfidence = 0.85)
                    4 -> lic.copy(isSeismic4D = true, seismicConfidence = 0.95)
                    else -> lic
                }
            } else lic
        }

        // Update prospects seismic confidence as well
        val newProspects = state.prospects.map { prospect ->
            if (prospect.licenceId == licenceId) {
                val conf = when (level) {
                    2 -> 0.60
                    3 -> 0.85
                    4 -> 0.95
                    else -> prospect.seismicConfidence
                }
                prospect.copy(seismicConfidence = conf)
            } else prospect
        }

        _gameState.value = state.copy(licences = newLicences, prospects = newProspects)

        // News item
        val surveyStr = when (level) {
            2 -> "2D Seismic imaging completed."
            3 -> "Advanced 3D Seismic survey processed (+12% discovery probability)."
            else -> "High-definition 4D Reservoir monitoring configured."
        }
        state.news = listOf(
            NewsItem(
                id = "news_seismic_${licenceId}_${state.currentMonth}",
                dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
                title = "Seismic Completed on Block ${licence.blockNumber}",
                content = "Ashcombe Energy finalized its survey of the prospect. $surveyStr",
                type = "EXPLORATION"
            )
        ) + state.news
    }

    fun drillProspect(prospectId: String, wellType: String) {
        val state = _gameState.value
        val prospect = state.prospects.find { it.id == prospectId } ?: return
        if (prospect.isDrilled) return

        val licence = state.licences.find { it.id == prospect.licenceId } ?: return

        val cost = when (wellType) {
            "Onshore" -> 12.0
            "Offshore" -> 45.0
            "Deepwater" -> 100.0
            "Ultra-Deepwater" -> 160.0
            else -> 15.0
        }

        if (state.playerCompany.cashM < cost) return

        // Deduct cost
        state.playerCompany.cashM -= cost

        // Determine outcome
        val random = Random(state.seed + prospectId.hashCode())
        state.seed = random.nextLong()

        // Adjusted probability
        var finalProb = prospect.geologicalProbability * prospect.seismicConfidence
        if (licence.isSeismic3D) finalProb += 0.12
        if (licence.isSeismic4D) finalProb += 0.20
        finalProb = finalProb.coerceIn(0.10, 0.95)

        val roll = random.nextDouble()
        val isSuccess = roll <= finalProb

        val outcome: WellOutcome
        val actualReserves: Double

        if (isSuccess) {
            val sizeRoll = random.nextDouble()
            outcome = when {
                sizeRoll < 0.50 -> WellOutcome.COMMERCIAL_DISCOVERY
                sizeRoll < 0.80 -> WellOutcome.LARGE_DISCOVERY
                sizeRoll < 0.95 -> WellOutcome.GIANT_DISCOVERY
                else -> WellOutcome.SUPERGIANT_DISCOVERY
            }

            // Actual reserves based on outcome scale
            val baseEstimate = random.nextDouble(prospect.estimatedResourcesMin, prospect.estimatedResourcesMax)
            actualReserves = when (outcome) {
                WellOutcome.COMMERCIAL_DISCOVERY -> baseEstimate * 0.5
                WellOutcome.LARGE_DISCOVERY -> baseEstimate * 0.9
                WellOutcome.GIANT_DISCOVERY -> baseEstimate * 1.4
                else -> baseEstimate * 2.2
            }
        } else {
            val showRoll = random.nextDouble()
            outcome = if (showRoll < 0.25) WellOutcome.OIL_SHOW else WellOutcome.DRY_HOLE
            actualReserves = 0.0
        }

        // Expected values for reporting
        val devComplexity = if (wellType.contains("Deepwater")) "High" else "Medium"
        val capexEstimate = actualReserves * 10.0 + (if (wellType.contains("Deepwater")) 1500.0 else 500.0)
        val peakProdBOPD = actualReserves * 350.0

        val wellId = "well_${prospectId}"
        val well = Well(
            id = wellId,
            prospectId = prospectId,
            licenceId = prospect.licenceId,
            name = "Exploration Well ${licence.blockNumber}-1",
            type = wellType,
            depthM = if (wellType.contains("Deepwater")) 4500 else 2500,
            costM = cost,
            durationMonths = 1,
            outcome = outcome,
            actualReservesM = actualReserves,
            apiGravity = 32.0 + random.nextDouble(-5.0, 8.0),
            reservoirPressure = if (wellType.contains("Deepwater")) "High" else "Medium",
            gasOilRatio = "Low",
            developmentComplexity = devComplexity,
            capexEstimateM = capexEstimate,
            peakProdEstimateBOPD = peakProdBOPD
        )

        // Update prospect
        val newProspects = state.prospects.map {
            if (it.id == prospectId) {
                it.copy(isDrilled = true, drilledWellId = wellId)
            } else it
        }

        val newWells = state.wells + well

        _gameState.value = state.copy(
            prospects = newProspects,
            wells = newWells,
            selectedWellId = wellId,
            currentScreen = "DISCOVERY_SCREEN" // Direct to discovery screen!
        )

        // News item
        val statusTitle = when (outcome) {
            WellOutcome.DRY_HOLE -> "Dry Hole Logged on Block ${licence.blockNumber}"
            WellOutcome.OIL_SHOW -> "Oil Shows Logged on Block ${licence.blockNumber}"
            else -> "COMMERCIAL DISCOVERY Announced on Block ${licence.blockNumber}!"
        }
        val statusContent = when (outcome) {
            WellOutcome.DRY_HOLE -> "Drilling at ${well.name} failed to identify commercial hydrocarbons. Well is being plugged and abandoned."
            WellOutcome.OIL_SHOW -> "Slight oil indications encountered at ${well.name}, but below commercial recovery thresholds."
            else -> "Ashcombe Energy reported a significant discovery of ${actualReserves.toInt()} MMbbl recoverable reserves. Peak production of ${peakProdBOPD.toInt()} BOPD projected."
        }

        state.news = listOf(
            NewsItem(
                id = "news_drill_${wellId}",
                dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
                title = statusTitle,
                content = statusContent,
                type = "EXPLORATION"
            )
        ) + state.news
    }

    fun developField(wellId: String, option: DevOption) {
        val state = _gameState.value
        val well = state.wells.find { it.id == wellId } ?: return

        // Calculate Capex and peak prod based on option
        val multiplier = when (option) {
            DevOption.MINIMAL -> 0.60
            DevOption.STANDARD -> 1.00
            DevOption.MAXIMUM -> 1.50
        }

        val finalCapex = well.capexEstimateM * multiplier
        val finalPeakProd = well.peakProdEstimateBOPD * multiplier

        if (state.playerCompany.cashM < finalCapex) {
            // Player does not have enough cash - but they can take debt automatically or we restrict them
            // In strategy games, we can let them develop and go into negative cash (debt automatically) or require bank loans
            // Let's allow development as long as they can borrow or have some buffer, but let's deduct the cash
        }

        state.playerCompany.cashM -= finalCapex
        state.playerCompany.debtM += if (state.playerCompany.cashM < 0.0) {
            val overflow = -state.playerCompany.cashM
            state.playerCompany.cashM = 0.0
            overflow
        } else 0.0

        val licence = state.licences.find { it.id == well.licenceId } ?: return

        // Create the active Field
        val fieldId = "field_${wellId}"
        val field = OilField(
            id = fieldId,
            wellId = wellId,
            licenceId = well.licenceId,
            name = "Field ${licence.blockNumber}",
            regionId = licence.regionId,
            recoverableReservesM = well.actualReservesM,
            remainingReservesM = well.actualReservesM,
            apiGravity = well.apiGravity,
            devOption = option,
            capexM = finalCapex,
            currentProdBOPD = finalPeakProd * 0.1, // starts ramping up
            peakProdBOPD = finalPeakProd,
            declineRate = 0.08,
            opexPerBbl = 15.0 + (if (well.type.contains("Deepwater")) 10.0 else 0.0)
        )

        // Add field and update reserves
        val newFields = state.fields + field
        state.playerCompany.reservesM += field.remainingReservesM

        _gameState.value = state.copy(
            fields = newFields,
            selectedFieldId = fieldId,
            currentScreen = "ASSETS"
        )

        state.news = listOf(
            NewsItem(
                id = "news_dev_${fieldId}",
                dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
                title = "Field Development Sanctioned: ${field.name}",
                content = "Ashcombe Energy approved capital expenditure of $${finalCapex.toInt()}M for the ${field.name} project. Construction of production facilities has commenced.",
                type = "COMPANY"
            )
        ) + state.news
    }

    fun toggleFieldInvestment(fieldId: String, investmentType: String) {
        val state = _gameState.value
        val field = state.fields.find { it.id == fieldId } ?: return

        val cost = when (investmentType) {
            "WaterInjection" -> 25.0
            "GasInjection" -> 35.0
            "InfillDrilling" -> 50.0
            "HorizontalWells" -> 70.0
            "EOR" -> 110.0
            else -> 0.0
        }

        if (state.playerCompany.cashM < cost) return

        state.playerCompany.cashM -= cost

        val newFields = state.fields.map { f ->
            if (f.id == fieldId) {
                when (investmentType) {
                    "WaterInjection" -> f.copy(waterInjection = true)
                    "GasInjection" -> f.copy(gasInjection = true)
                    "InfillDrilling" -> f.copy(infillDrilling = true)
                    "HorizontalWells" -> f.copy(horizontalWells = true)
                    "EOR" -> f.copy(eorEnabled = true)
                    else -> f
                }
            } else f
        }

        _gameState.value = state.copy(fields = newFields)
    }

    fun buildInfrastructure(type: InfrastructureType, regionId: String) {
        val state = _gameState.value

        val (capex, opex, capacity, name) = when (type) {
            InfrastructureType.PIPELINE -> Tuple4(80.0, 0.4, 150000.0, "Trans-Region pipeline")
            InfrastructureType.FPSO -> Tuple4(250.0, 1.2, 120000.0, "Deep Sea FPSO Vessel")
            InfrastructureType.REFINERY -> Tuple4(450.0, 2.5, 200000.0, "Coastal Processing Refinery")
            InfrastructureType.TANKER -> Tuple4(60.0, 0.2, 80000.0, "VLCC Cargo Tanker")
        }

        if (state.playerCompany.cashM < capex) return

        state.playerCompany.cashM -= capex

        val infra = Infrastructure(
            id = "infra_${type.name}_${System.currentTimeMillis()}",
            type = type,
            name = name,
            capexM = capex,
            opexM = opex,
            capacityBOPD = capacity,
            locationRegionId = regionId
        )

        _gameState.value = state.copy(infrastructures = state.infrastructures + infra)

        state.news = listOf(
            NewsItem(
                id = "news_infra_${infra.id}",
                dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
                title = "Infrastructure Built: ${infra.name}",
                content = "Ashcombe Energy built a new ${type.name} in region ${regionId}. Regional capacity boosted by ${capacity.toInt()} BOPD.",
                type = "COMPANY"
            )
        ) + state.news
    }

    data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

    fun unlockTechnology(techId: String) {
        val state = _gameState.value
        val tech = state.technologies.find { it.id == techId } ?: return
        if (tech.unlocked) return
        if (state.playerCompany.cashM < tech.costM) return

        state.playerCompany.cashM -= tech.costM

        val newTechs = state.technologies.map {
            if (it.id == techId) it.copy(unlocked = true) else it
        }

        val playerTechs = state.playerCompany.unlockedTechIds + techId
        val updatedPlayer = state.playerCompany.copy(unlockedTechIds = playerTechs)

        _gameState.value = state.copy(
            technologies = newTechs,
            playerCompany = updatedPlayer
        )

        state.news = listOf(
            NewsItem(
                id = "news_tech_${techId}",
                dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
                title = "Technology Unlocked: ${tech.name}",
                content = "R&D department completed deployment of ${tech.name}. ${tech.description}",
                type = "COMPANY"
            )
        ) + state.news
    }

    fun takeLoan(principal: Double) {
        val state = _gameState.value
        val rate = 0.08
        val duration = 60
        // Standard amortization formula
        val r = rate / 12.0
        val monthlyPayment = (principal * r) / (1.0 - Math.pow(1.0 + r, -duration.toDouble()))

        val loan = Loan(
            id = "loan_${System.currentTimeMillis()}",
            principalM = principal,
            interestRate = rate,
            monthlyPaymentM = monthlyPayment,
            maturityMonths = duration,
            monthsRemaining = duration
        )

        state.playerCompany.cashM += principal
        state.playerCompany.debtM += principal

        _gameState.value = state.copy(
            activeLoans = state.activeLoans + loan
        )

        state.news = listOf(
            NewsItem(
                id = "news_loan_${loan.id}",
                dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
                title = "New Debt Facility Arranged",
                content = "Ashcombe Energy secured a credit facility of $${principal.toInt()}M at 8% annual interest rate, maturing in 5 years.",
                type = "COMPANY"
            )
        ) + state.news
    }

    fun repayLoan(loanId: String) {
        val state = _gameState.value
        val loan = state.activeLoans.find { it.id == loanId } ?: return
        if (state.playerCompany.cashM < loan.principalM) return

        state.playerCompany.cashM -= loan.principalM
        state.playerCompany.debtM -= loan.principalM

        val updatedLoans = state.activeLoans.filter { it.id != loanId }

        _gameState.value = state.copy(
            activeLoans = updatedLoans
        )

        state.news = listOf(
            NewsItem(
                id = "news_repay_${loanId}",
                dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
                title = "Debt Facility Repaid Early",
                content = "Ashcombe Energy cleared its debt facility of $${loan.principalM.toInt()}M early, lowering monthly interest expenses.",
                type = "COMPANY"
            )
        ) + state.news
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ADVANCING TIME & BACKGROUND SIMULATION LOOP
    // ─────────────────────────────────────────────────────────────────────────

    fun advanceTime(months: Int) {
        viewModelScope.launch {
            val state = _gameState.value
            for (i in 1..months) {
                Simulation.processMonth(state)
            }
            // Trigger recomposition by re-assigning the state flow
            _gameState.value = state.copy()
        }
    }

    fun setAutoTickSpeed(speedMs: Long) {
        _autoTickSpeedMs.value = speedMs
        if (speedMs == 0L) {
            stopAutoTick()
        } else {
            startAutoTick(speedMs)
        }
    }

    private fun startAutoTick(speedMs: Long) {
        autoTickJob?.cancel()
        autoTickJob = viewModelScope.launch {
            while (true) {
                delay(speedMs)
                if (_gameState.value.isGameOver || _gameState.value.isVictory) {
                    stopAutoTick()
                    break
                }
                val state = _gameState.value
                Simulation.processMonth(state)
                _gameState.value = state.copy()
            }
        }
    }

    fun stopAutoTick() {
        autoTickJob?.cancel()
        autoTickJob = null
        _autoTickSpeedMs.value = 0L
    }

    val autoTickSpeedMs: StateFlow<Long> = _autoTickSpeedMs.asStateFlow()

    // ─────────────────────────────────────────────────────────────────────────
    // SAVE / LOAD INTERACTION
    // ─────────────────────────────────────────────────────────────────────────

    fun saveGame(slotId: Int) {
        viewModelScope.launch {
            repository.saveGame(slotId, _gameState.value)
        }
    }

    fun loadGame(slotId: Int) {
        viewModelScope.launch {
            val loadedState = repository.loadGame(slotId)
            if (loadedState != null) {
                _gameState.value = loadedState
                stopAutoTick()
            }
        }
    }

    fun deleteSlot(slotId: Int) {
        viewModelScope.launch {
            repository.deleteSlot(slotId)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopAutoTick()
    }
}
