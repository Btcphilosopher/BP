package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainContent(viewModel)
            }
        }
    }
}

@Composable
fun MainContent(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()

    if (state.currentScreen == "START_SCREEN") {
        StartScreen(viewModel = viewModel)
        return
    }

    if (state.isGameOver) {
        GameOverScreen(viewModel = viewModel)
        return
    }

    if (state.isVictory) {
        VictoryScreen(viewModel = viewModel)
        return
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = EnergyDarkSurface,
                contentColor = EnergyGold,
                modifier = Modifier.navigationBarsPadding()
            ) {
                // Bottom tab: HOME
                NavigationBarItem(
                    selected = state.currentScreen == "DASHBOARD",
                    onClick = { viewModel.selectScreen("DASHBOARD") },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Dashboard") },
                    label = { Text("HOME", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = EnergyGold,
                        unselectedIconColor = EnergyTextSecondary,
                        unselectedTextColor = EnergyTextSecondary,
                        indicatorColor = EnergyGold
                    )
                )

                // Bottom tab: WORLD MAP
                NavigationBarItem(
                    selected = state.currentScreen == "WORLD",
                    onClick = { viewModel.selectScreen("WORLD") },
                    icon = { Icon(Icons.Default.Public, contentDescription = "World") },
                    label = { Text("WORLD", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = EnergyGold,
                        unselectedIconColor = EnergyTextSecondary,
                        unselectedTextColor = EnergyTextSecondary,
                        indicatorColor = EnergyGold
                    )
                )

                // Bottom tab: EXPLORATION
                NavigationBarItem(
                    selected = state.currentScreen == "EXPLORE",
                    onClick = { viewModel.selectScreen("EXPLORE") },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Exploration") },
                    label = { Text("EXPLORE", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = EnergyGold,
                        unselectedIconColor = EnergyTextSecondary,
                        unselectedTextColor = EnergyTextSecondary,
                        indicatorColor = EnergyGold
                    )
                )

                // Bottom tab: ASSETS
                NavigationBarItem(
                    selected = state.currentScreen == "ASSETS",
                    onClick = { viewModel.selectScreen("ASSETS") },
                    icon = { Icon(Icons.Default.Build, contentDescription = "Assets") },
                    label = { Text("ASSETS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = EnergyGold,
                        unselectedIconColor = EnergyTextSecondary,
                        unselectedTextColor = EnergyTextSecondary,
                        indicatorColor = EnergyGold
                    )
                )

                // Bottom tab: CORPORATE
                NavigationBarItem(
                    selected = state.currentScreen == "CORPORATE",
                    onClick = { viewModel.selectScreen("CORPORATE") },
                    icon = { Icon(Icons.Default.Business, contentDescription = "Corporate") },
                    label = { Text("CORPORATE", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = EnergyGold,
                        unselectedIconColor = EnergyTextSecondary,
                        unselectedTextColor = EnergyTextSecondary,
                        indicatorColor = EnergyGold
                    )
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(EnergyDarkBg)
                .padding(innerPadding)
        ) {
            when (state.currentScreen) {
                "DASHBOARD" -> DashboardScreen(viewModel = viewModel)
                "WORLD" -> WorldScreen(viewModel = viewModel)
                "EXPLORE" -> ExplorationScreen(viewModel = viewModel)
                "ASSETS" -> AssetsScreen(viewModel = viewModel)
                "CORPORATE" -> CorporateScreen(viewModel = viewModel)
                "DISCOVERY_SCREEN" -> DiscoveryScreen(viewModel = viewModel)
                else -> DashboardScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun GameOverScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = EnergyRed, modifier = Modifier.size(64.dp))
            Text(text = "CORPORATE BANKRUPTCY", fontSize = 24.sp, fontWeight = FontWeight.Black, color = EnergyRed)
            Text(
                text = "${state.playerCompany.name} has run out of working liquidity and has defaulted on its debt and operational obligations. Creditors have triggered restructuring liquidation.",
                color = EnergyTextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.fillMaxWidth(0.8f),
                style = LocalTextStyle.current.copy(textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            )
            Button(
                onClick = { viewModel.selectScreen("START_SCREEN") },
                colors = ButtonDefaults.buttonColors(containerColor = EnergyRed, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(0.6f)
            ) {
                Text("RESTART BRAND", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun VictoryScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = EnergyGold, modifier = Modifier.size(64.dp))
            Text(text = "ENERGY MAJOR DOMINANCE", fontSize = 24.sp, fontWeight = FontWeight.Black, color = EnergyGold)
            Text(
                text = "Congratulations! ${state.playerCompany.name} has scaled its global operations to become a supermajor. With a market capitalization exceeding $20 Billion, you have secured total energy sector dominance.",
                color = EnergyTextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.fillMaxWidth(0.8f),
                style = LocalTextStyle.current.copy(textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            )
            Button(
                onClick = { viewModel.selectScreen("START_SCREEN") },
                colors = ButtonDefaults.buttonColors(containerColor = EnergyGold, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(0.6f)
            ) {
                Text("NEW Sandbox CAMPAIGN", fontWeight = FontWeight.Bold)
            }
        }
    }
}
