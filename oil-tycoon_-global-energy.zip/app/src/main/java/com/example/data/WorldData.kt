package com.example.data

import com.example.models.Region
import com.example.models.Company
import com.example.models.AiStrategy
import com.example.models.Technology

object WorldData {
    val initialRegions = listOf(
        Region("north_sea", "North Sea", 4, "Medium", "Low", "Excellent", 180, 85.0, 0.48),
        Region("norwegian_sea", "Norwegian Sea", 4, "Medium", "Low", "Excellent", 350, 95.0, 0.55),
        Region("barrents_sea", "Barents Sea", 3, "High", "Low", "Poor", 450, 110.0, 0.50),
        Region("gulf_of_mexico", "Gulf of Mexico", 5, "Medium", "Low", "Excellent", 1500, 120.0, 0.35),
        Region("permian", "Permian Basin", 5, "Low", "Low", "Excellent", 0, 12.0, 0.21), // Onshore shale
        Region("alaska", "Alaska", 3, "Medium", "Low", "Good", 0, 45.0, 0.40),
        Region("western_canada", "Western Canada", 3, "Low", "Low", "Good", 0, 15.0, 0.30),
        Region("brazil", "Brazil Offshore", 5, "Medium", "Low", "Good", 2200, 140.0, 0.45),
        Region("guyana_suriname", "Guyana-Suriname", 5, "Medium", "Medium", "Poor", 1800, 130.0, 0.30),
        Region("mexico", "Mexico", 3, "Medium", "Medium", "Good", 100, 50.0, 0.60),
        Region("venezuela", "Venezuela", 4, "Low", "High", "Poor", 50, 25.0, 0.70),
        Region("west_africa", "West Africa Deep", 4, "High", "Medium", "Good", 1200, 110.0, 0.50),
        Region("angola", "Angola", 4, "Medium", "Medium", "Poor", 1000, 95.0, 0.45),
        Region("nigeria", "Nigeria", 4, "Medium", "High", "Poor", 200, 75.0, 0.55),
        Region("namibia", "Namibia", 4, "High", "Medium", "Poor", 1500, 115.0, 0.35),
        Region("middle_east", "Middle East Onshore", 5, "Low", "Medium", "Good", 0, 10.0, 0.85),
        Region("caspian", "Caspian Sea", 4, "High", "Medium", "Good", 50, 90.0, 0.65),
        Region("russia", "Russia Siberia", 4, "Low", "High", "Good", 0, 20.0, 0.60),
        Region("central_asia", "Central Asia", 3, "Medium", "Medium", "Poor", 0, 18.0, 0.45),
        Region("north_africa", "North Africa", 4, "Medium", "Medium", "Poor", 0, 15.0, 0.55),
        Region("east_africa", "East Africa", 3, "High", "Medium", "Poor", 200, 65.0, 0.40),
        Region("australia", "Australia LNG", 4, "Medium", "Low", "Excellent", 100, 70.0, 0.38),
        Region("southeast_asia", "Southeast Asia", 3, "Medium", "Medium", "Good", 80, 45.0, 0.50),
        Region("indonesia", "Indonesia", 3, "Medium", "Medium", "Good", 60, 40.0, 0.45),
        Region("china", "China onshore/offshore", 4, "Medium", "Low", "Excellent", 50, 35.0, 0.50)
    )

    val initialCompetitors = listOf(
        Company("c1", "Atlantic Petroleum", false, 4500.0, 1200.0, 280000.0, 2800.0, 45.0, 100.0, 4500.0, aiStrategy = AiStrategy.INTEGRATED_MAJOR, riskTolerance = 0.4, preferredRegionId = "north_sea"),
        Company("c2", "NorthStar Energy", false, 1500.0, 800.0, 110000.0, 1100.0, 32.5, 50.0, 1500.0, aiStrategy = AiStrategy.CONSERVATIVE_MAJOR, riskTolerance = 0.3, preferredRegionId = "alaska"),
        Company("c3", "Pacific Oil & Gas", false, 2500.0, 1500.0, 180000.0, 1700.0, 38.0, 70.0, 2500.0, aiStrategy = AiStrategy.INTEGRATED_MAJOR, riskTolerance = 0.5, preferredRegionId = "gulf_of_mexico"),
        Company("c4", "Oriental Resources", false, 1800.0, 600.0, 95000.0, 900.0, 28.0, 65.0, 1800.0, aiStrategy = AiStrategy.VALUE_INVESTOR, riskTolerance = 0.3, preferredRegionId = "china"),
        Company("c5", "Western Petroleum", false, 3000.0, 2500.0, 240000.0, 2300.0, 52.0, 80.0, 3000.0, aiStrategy = AiStrategy.AGGRESSIVE_EXPLORER, riskTolerance = 0.8, preferredRegionId = "guyana_suriname"),
        Company("c6", "Siberian Giant", false, 5000.0, 3000.0, 450000.0, 5200.0, 65.0, 120.0, 5000.0, aiStrategy = AiStrategy.CONSERVATIVE_MAJOR, riskTolerance = 0.2, preferredRegionId = "russia"),
        Company("c7", "Desert Petroleum", false, 8000.0, 1000.0, 950000.0, 9800.0, 120.0, 150.0, 8000.0, aiStrategy = AiStrategy.VALUE_INVESTOR, riskTolerance = 0.1, preferredRegionId = "middle_east"),
        Company("c8", "Apex Shale", false, 800.0, 1200.0, 150000.0, 600.0, 18.0, 40.0, 800.0, aiStrategy = AiStrategy.SHALE_SPECIALIST, riskTolerance = 0.7, preferredRegionId = "permian"),
        Company("c9", "Gulf Deepwater Corp", false, 1200.0, 2000.0, 85000.0, 1400.0, 24.5, 45.0, 1200.0, aiStrategy = AiStrategy.DEEPWATER_SPECIALIST, riskTolerance = 0.6, preferredRegionId = "gulf_of_mexico"),
        Company("c10", "Aura LNG Ltd", false, 1600.0, 900.0, 120000.0, 1500.0, 31.0, 55.0, 1600.0, aiStrategy = AiStrategy.GAS_SPECIALIST, riskTolerance = 0.4, preferredRegionId = "australia"),
        Company("c11", "Equator Energy", false, 1400.0, 1100.0, 90000.0, 950.0, 26.0, 50.0, 1400.0, aiStrategy = AiStrategy.CONSERVATIVE_MAJOR, riskTolerance = 0.5, preferredRegionId = "west_africa"),
        Company("c12", "Rio Negro Offshore", false, 1100.0, 1800.0, 75000.0, 1200.0, 22.0, 40.0, 1100.0, aiStrategy = AiStrategy.DEEPWATER_SPECIALIST, riskTolerance = 0.7, preferredRegionId = "brazil"),
        Company("c13", "Barents Frontier", false, 700.0, 900.0, 40000.0, 800.0, 15.0, 35.0, 700.0, aiStrategy = AiStrategy.AGGRESSIVE_EXPLORER, riskTolerance = 0.9, preferredRegionId = "barrents_sea"),
        Company("c14", "Orinoco Heavy", false, 1000.0, 1500.0, 130000.0, 3500.0, 19.5, 60.0, 1000.0, aiStrategy = AiStrategy.VALUE_INVESTOR, riskTolerance = 0.3, preferredRegionId = "venezuela"),
        Company("c15", "Nova Energy Corp", false, 1300.0, 2800.0, 145000.0, 1100.0, 21.0, 70.0, 1300.0, aiStrategy = AiStrategy.HIGH_DEBT_GROWTH, riskTolerance = 0.8, preferredRegionId = "guyana_suriname")
    )

    val initialTechnologies = listOf(
        // Exploration
        Technology("t_seismic_2d", "2D Seismic Acquisition", "EXPLORATION", 15.0, true, "Standard linear geological imaging.", 1.0),
        Technology("t_seismic_3d", "3D Seismic Surveying", "EXPLORATION", 35.0, false, "Reduces geological uncertainty by 24% and adds +12% discovery probability.", 0.90),
        Technology("t_seismic_4d", "4D Time-Lapse Seismic", "EXPLORATION", 75.0, false, "Adds real-time reservoir sweep imaging. Reduces decline rates.", 0.80),
        Technology("t_ai_geology", "AI Predictive Geology", "EXPLORATION", 150.0, false, "Uses deep learning models to predict commercial reservoir properties.", 0.70),

        // Drilling
        Technology("t_dir_drilling", "Directional Drilling", "DRILLING", 25.0, true, "Allows drilling multiple wells from a single pad.", 0.95),
        Technology("t_horiz_drilling", "Horizontal Drilling", "DRILLING", 60.0, false, "Multiplies reservoir contact. +30% field peak production capacity.", 0.85),
        Technology("t_auto_drilling", "Automated Drilling Rigs", "DRILLING", 120.0, false, "Reduces drilling mechanical and environmental risks.", 0.75),
        Technology("t_subsea_tree", "Advanced Subsea Trees", "DRILLING", 200.0, false, "Drastically lowers deepwater CAPEX and well times.", 0.65),

        // Production
        Technology("t_water_inj", "Water Injection", "PRODUCTION", 20.0, true, "Enables waterflooding to maintain reservoir pressure.", 1.0),
        Technology("t_smart_wells", "Smart Completions", "PRODUCTION", 80.0, false, "Allows selective flow control to reduce water production.", 0.90),
        Technology("t_eor", "Enhanced Oil Recovery (CO2/Chemical)", "PRODUCTION", 140.0, false, "Increases Ultimate Recovery Factor (URF) of mature fields.", 0.80),
        Technology("t_auto_field", "Autonomous Field Operations", "PRODUCTION", 220.0, false, "Reduces operating costs (OPEX) by 30%.", 0.70),

        // Logistics
        Technology("t_vessels", "Supermax Tanker Fleet", "LOGISTICS", 40.0, true, "Standard long-range crude shipment.", 1.0),
        Technology("t_pipe_opt", "Pipeline Drag Reduction", "LOGISTICS", 75.0, false, "Increases pipeline throughput capacity by 25%.", 0.90),
        Technology("t_dig_terminal", "Digital Port & Terminal Management", "LOGISTICS", 110.0, false, "Reduces export demurrage costs and oil losses.", 0.85),

        // Transition
        Technology("t_ccs", "Carbon Capture & Storage", "ENERGY_TRANSITION", 130.0, false, "Reduces environmental carbon tax liabilities by 50%.", 0.90),
        Technology("t_hydrogen", "Blue Hydrogen Conversion", "ENERGY_TRANSITION", 250.0, false, "Converts gas fields into hydrogen energy assets.", 0.80)
    )
}
