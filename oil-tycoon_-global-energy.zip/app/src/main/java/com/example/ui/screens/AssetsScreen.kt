package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.models.InfrastructureType
import com.example.ui.theme.*

@Composable
fun AssetsScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    val selectedField = state.fields.find { it.id == state.selectedFieldId }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
    ) {
        // Left Column: List of developed oil fields
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "DEVELOPED OIL FIELDS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary,
                modifier = Modifier.padding(start = 8.dp)
            )

            if (state.fields.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = EnergyTextSecondary, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("NO ACTIVE PRODUCING FIELDS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.fields) { field ->
                        val isSelected = field.id == state.selectedFieldId
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) EnergyGold.copy(alpha = 0.15f) else EnergyDarkSurface
                            ),
                            border = BorderStroke(1.dp, if (isSelected) EnergyGold else EnergyBorder),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectField(field.id) }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(field.name, fontSize = 13.sp, fontWeight = FontWeight.Black, color = EnergyTextPrimary)
                                    Text(
                                        "${String.format("%,.0f", field.currentProdBOPD)} BOPD",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EnergyGold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Reserves: ${field.remainingReservesM.toInt()} MMbbl", fontSize = 10.sp, color = EnergyTextSecondary)
                                    Text("Water Cut: ${(field.waterCut * 100).toInt()}%", fontSize = 10.sp, color = EnergyRed, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Reservoir management details
        Column(
            modifier = Modifier
                .weight(1.1f)
                .fillMaxHeight()
                .background(EnergyDarkSurface)
                .border(BorderStroke(1.dp, EnergyBorder))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedField == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("SELECT A FIELD TO MANAGE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                }
            } else {
                Text(
                    text = "${selectedField.name.uppercase()} RESERVOIR",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = EnergyGold
                )

                Divider(color = EnergyBorder)

                // Detailed stats
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    FieldStatRow(label = "Original STOIIP:", value = "${selectedField.recoverableReservesM.toInt()} MMbbl")
                    FieldStatRow(label = "Remaining Reserves:", value = "${selectedField.remainingReservesM.toInt()} MMbbl")
                    FieldStatRow(label = "Reservoir Pressure:", value = "${(selectedField.reservoirPressureFactor * 100).toInt()}%")
                    FieldStatRow(label = "Water Cut:", value = "${(selectedField.waterCut * 100).toInt()}%")
                    FieldStatRow(label = "Opex per bbl:", value = "$${selectedField.opexPerBbl}")
                }

                Divider(color = EnergyBorder)

                // Reservoir pressure boost investments
                Text("RESERVOIR PRESSURE UPGRADES", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Water Injection
                    item {
                        InvestmentButton(
                            label = "WATER INJECTION FLOODING",
                            cost = "$25M",
                            unlocked = selectedField.waterInjection,
                            enabled = state.playerCompany.cashM >= 25.0,
                            onClick = { viewModel.toggleFieldInvestment(selectedField.id, "WaterInjection") }
                        )
                    }

                    // Gas Injection
                    item {
                        InvestmentButton(
                            label = "GAS CAP RE-INJECTION",
                            cost = "$35M",
                            unlocked = selectedField.gasInjection,
                            enabled = state.playerCompany.cashM >= 35.0,
                            onClick = { viewModel.toggleFieldInvestment(selectedField.id, "GasInjection") }
                        )
                    }

                    // Infill Drilling
                    item {
                        InvestmentButton(
                            label = "INFILL WELL CAMPAIGN",
                            cost = "$50M",
                            unlocked = selectedField.infillDrilling,
                            enabled = state.playerCompany.cashM >= 50.0,
                            onClick = { viewModel.toggleFieldInvestment(selectedField.id, "InfillDrilling") }
                        )
                    }

                    // Horizontal Wells
                    item {
                        InvestmentButton(
                            label = "HORIZONTAL MULTILATERALS",
                            cost = "$70M",
                            unlocked = selectedField.horizontalWells,
                            enabled = state.playerCompany.cashM >= 70.0,
                            onClick = { viewModel.toggleFieldInvestment(selectedField.id, "HorizontalWells") }
                        )
                    }

                    // EOR
                    item {
                        InvestmentButton(
                            label = "ENHANCED EOR CO2 SWEEP",
                            cost = "$110M",
                            unlocked = selectedField.eorEnabled,
                            enabled = state.playerCompany.cashM >= 110.0,
                            onClick = { viewModel.toggleFieldInvestment(selectedField.id, "EOR") }
                        )
                    }
                }

                Divider(color = EnergyBorder)

                // Infrastructure action
                Text("BUILD REGION INFRASTRUCTURE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.buildInfrastructure(InfrastructureType.PIPELINE, selectedField.regionId) },
                        colors = ButtonDefaults.buttonColors(containerColor = EnergyCyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("PIPELINE ($80M)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { viewModel.buildInfrastructure(InfrastructureType.FPSO, selectedField.regionId) },
                        colors = ButtonDefaults.buttonColors(containerColor = EnergyCyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("FPSO ($250M)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun FieldStatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = EnergyTextSecondary)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextPrimary)
    }
}

@Composable
fun InvestmentButton(
    label: String,
    cost: String,
    unlocked: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (unlocked) EnergyGreen.copy(alpha = 0.2f) else EnergyDarkBg
        ),
        enabled = !unlocked && enabled,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, if (unlocked) EnergyGreen else EnergyBorder), RoundedCornerShape(6.dp)),
        contentPadding = PaddingValues(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (unlocked) EnergyGreen else EnergyTextPrimary)
            Text(if (unlocked) "DEPLOYED" else "Cost: $cost", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EnergyGold)
        }
    }
}
