package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Energy Terminal Theme Colors
val EnergyDarkBg = Color(0xFF0C0E14)      // Rich dark slate
val EnergyDarkSurface = Color(0xFF141824) // Deep navy slate cards
val EnergyDarkHeader = Color(0xFF1C2234)  // Header panel
val EnergyGold = Color(0xFFFFB300)        // Gold/Amber energy primary
val EnergyGoldLight = Color(0xFFFFD54F)   // Muted gold
val EnergyCyan = Color(0xFF00E5FF)        // Tech cyan
val EnergyGreen = Color(0xFF00E676)       // Profit green
val EnergyRed = Color(0xFFFF1744)         // Dry-well / Debt red
val EnergyTextPrimary = Color(0xFFE2E8F0) // Off-white crisp text
val EnergyTextSecondary = Color(0xFF94A3B8)// Slate gray muted text
val EnergyBorder = Color(0xFF2E384D)      // Grid boundary lines
val EnergyYellowBg = Color(0x1AFFB300)    // Muted gold glow
val EnergyGreenBg = Color(0x1A00E676)     // Muted green glow
val EnergyRedBg = Color(0x1AFF1744)       // Muted red glow
