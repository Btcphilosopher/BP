package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.theme.*

@Composable
fun CompanyScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    
    // Merge player and AI companies, then rank them by net worth (Market Cap)
    val allCompanies = (listOf(state.playerCompany) + state.aiCompanies)
        .sortedByDescending { it.netWorthM }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "ENERGY CONGLOMERATE INTELLIGENCE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = EnergyTextSecondary
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(allCompanies) { index, comp ->
                val isPlayer = comp.isPlayer
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPlayer) EnergyGold.copy(alpha = 0.15f) else EnergyDarkSurface
                    ),
                    border = BorderStroke(1.dp, if (isPlayer) EnergyGold else EnergyBorder),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left: Rank & Name
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "#${index + 1}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isPlayer) EnergyGold else EnergyCyan
                            )
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = comp.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EnergyTextPrimary
                                    )
                                    if (isPlayer) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "[YOU]",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = EnergyGold
                                        )
                                    }
                                }
                                Text(
                                    text = comp.aiStrategy?.name?.replace("_", " ") ?: "INTEGRATED GIANT",
                                    fontSize = 9.sp,
                                    color = EnergyTextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Right: Net Worth & Stats
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Cap: $${String.format("%.1f", comp.netWorthM)}M",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = if (isPlayer) EnergyGold else EnergyTextPrimary
                            )
                            Text(
                                text = "${String.format("%,.0f", comp.productionBOPD)} BOPD",
                                fontSize = 10.sp,
                                color = EnergyGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Res: ${comp.reservesM.toInt()} MMbbl",
                                fontSize = 9.sp,
                                color = EnergyCyan
                            )
                        }
                    }
                }
            }
        }
    }
}
