package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.components.LineChart
import com.example.ui.theme.*

@Composable
fun DashboardScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    val speedMs by viewModel.autoTickSpeedMs.collectAsState()

    val company = state.playerCompany
    val market = state.market

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Corporate Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = company.name.uppercase(),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = EnergyGold
                            )
                            Text(
                                text = "${state.currentMonthStr} ${state.currentYearStr}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = EnergyCyan
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "MARKET CAP",
                                fontSize = 10.sp,
                                color = EnergyTextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$${String.format("%.1f", company.netWorthM)}M",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = EnergyTextPrimary
                            )
                            Text(
                                text = "SHARE: $${String.format("%.2f", company.sharePrice)}",
                                fontSize = 11.sp,
                                color = EnergyGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Time Control Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "SIMULATION CONTROL ENGINE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EnergyTextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Pause
                        Button(
                            onClick = { viewModel.setAutoTickSpeed(0) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (speedMs == 0L) EnergyGold else EnergyDarkBg,
                                contentColor = if (speedMs == 0L) Color.Black else EnergyTextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(Icons.Default.Pause, contentDescription = "Pause", modifier = Modifier.size(16.dp))
                        }

                        // 1 Month step
                        Button(
                            onClick = { viewModel.advanceTime(1) },
                            colors = ButtonDefaults.buttonColors(containerColor = EnergyDarkBg),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("+1M", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // Fast (1.5s per tick)
                        Button(
                            onClick = { viewModel.setAutoTickSpeed(1500) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (speedMs == 1500L) EnergyCyan else EnergyDarkBg,
                                contentColor = if (speedMs == 1500L) Color.Black else EnergyTextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1.5f),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("FAST", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // Fastest (500ms per tick)
                        Button(
                            onClick = { viewModel.setAutoTickSpeed(500) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (speedMs == 500L) EnergyGreen else EnergyDarkBg,
                                contentColor = if (speedMs == 500L) Color.Black else EnergyTextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1.5f),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("FASTEST", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Financial & Resource KPI Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Cash & Debt
                Card(
                    colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                    border = BorderStroke(1.dp, EnergyBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("LIQUIDITY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "$${String.format("%.1f", company.cashM)}M",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = if (company.cashM >= 0) EnergyGreen else EnergyRed
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "DEBT: $${String.format("%.1f", company.debtM)}M",
                            fontSize = 11.sp,
                            color = if (company.debtM > 0) EnergyRed else EnergyTextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Production & Reserves
                Card(
                    colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                    border = BorderStroke(1.dp, EnergyBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("PRODUCTION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "${String.format("%,.0f", company.productionBOPD)} BOPD",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = EnergyGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "RESERVES: ${String.format("%.1f", company.reservesM)} MMbbl",
                            fontSize = 11.sp,
                            color = EnergyCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Market Prices benchmarks
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "GLOBAL HYDROCARBON BENCHMARKS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EnergyTextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("BRENT CRUDE", fontSize = 11.sp, color = EnergyTextSecondary)
                            Text(
                                "$${String.format("%.2f", market.brentPrice)}/bbl",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = EnergyGold
                            )
                        }
                        Column {
                            Text("WTI CRUDE", fontSize = 11.sp, color = EnergyTextSecondary)
                            Text(
                                "$${String.format("%.2f", market.wtiPrice)}/bbl",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = EnergyTextPrimary
                            )
                        }
                        Column {
                            Text("HENRY HUB GAS", fontSize = 11.sp, color = EnergyTextSecondary)
                            Text(
                                "$${String.format("%.2f", market.gasPriceHenryHub)}/MMBtu",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = EnergyCyan
                            )
                        }
                    }
                }
            }
        }

        // Visual Price Chart
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "BRENT OIL PRICE TREND",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EnergyTextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Generate dummy trend from current state to look cool
                    val trend = List(15) { i ->
                        market.brentPrice + Math.sin(i.toDouble() / 2.0) * 8.0 - (15 - i) * 0.5
                    }

                    LineChart(
                        data = trend,
                        color = EnergyGold,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    )
                }
            }
        }

        // Quick Tutorial / Status Checklist
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "OPERATIONAL CHECKLIST",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EnergyCyan
                    )

                    val checks = listOf(
                        "Secure an Exploration Licence" to (state.licences.any { it.durationMonths > 0 }), // simplified buy condition
                        "Process Seismic Survey (improve confidence)" to (state.licences.any { it.isSeismic2D || it.isSeismic3D }),
                        "Drill exploratory wells & strike reserves" to (state.wells.isNotEmpty()),
                        "Develop commercial discoveries & pump oil" to (state.fields.isNotEmpty()),
                        "Sell crude oil & scale your net worth" to (company.revenueM > 0.0)
                    )

                    checks.forEach { (text, checked) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (checked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = if (checked) "Done" else "Pending",
                                tint = if (checked) EnergyGreen else EnergyTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = text,
                                fontSize = 12.sp,
                                color = if (checked) EnergyTextPrimary else EnergyTextSecondary,
                                fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // Active News Preview
        item {
            Text(
                "LATEST WIRE REPORTS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary
            )
        }

        val newsItems = state.news.take(2)
        if (newsItems.isEmpty()) {
            item {
                Text(
                    "No news reports yet. Advance time to trigger updates.",
                    fontSize = 12.sp,
                    color = EnergyTextSecondary
                )
            }
        } else {
            items(newsItems) { news ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                    border = BorderStroke(1.dp, EnergyBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = news.type,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (news.type == "MARKET") EnergyGold else EnergyCyan
                            )
                            Text(
                                text = news.dateStr,
                                fontSize = 9.sp,
                                color = EnergyTextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = news.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = EnergyTextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = news.content,
                            fontSize = 11.sp,
                            color = EnergyTextSecondary,
                            maxLines = 2
                        )
                    }
                }
            }
        }
    }
}
