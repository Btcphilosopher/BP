package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.theme.*

@Composable
fun CorporateScreen(viewModel: GameViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("FINANCE", "COMPETITORS", "TECHNOLOGY", "NEWS FEED")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
    ) {
        // Scrollable Tab Row for Corporate sub-sections
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = EnergyDarkSurface,
            contentColor = EnergyGold,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = EnergyGold
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedTab == index) EnergyGold else EnergyTextSecondary
                        )
                    }
                )
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
                0 -> FinanceScreen(viewModel)
                1 -> CompanyScreen(viewModel)
                2 -> TechScreen(viewModel)
                3 -> NewsScreen(viewModel)
            }
        }
    }
}
