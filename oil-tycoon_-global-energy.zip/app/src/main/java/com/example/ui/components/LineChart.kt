package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke

@Composable
fun LineChart(
    data: List<Double>,
    color: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    fillColor: Color = color.copy(alpha = 0.15f)
) {
    if (data.isEmpty()) {
        Canvas(modifier = modifier) {
            drawRect(Color.Gray.copy(alpha = 0.1f), size = size)
        }
        return
    }

    val maxVal = (data.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
    val minVal = (data.minOrNull() ?: 0.0).coerceAtMost(maxVal - 0.1)
    val range = (maxVal - minVal).coerceAtLeast(0.1)

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        val points = data.mapIndexed { index, value ->
            val x = if (data.size > 1) {
                (index.toFloat() / (data.size - 1)) * width
            } else {
                width / 2f
            }
            // Flip y because (0,0) is top-left
            val y = height - (((value - minVal) / range) * (height - 30f) + 15f).toFloat()
            Offset(x, y)
        }

        // Draw grid lines
        val gridCount = 4
        for (i in 0..gridCount) {
            val y = (height / gridCount) * i
            drawLine(
                color = Color.Gray.copy(alpha = 0.15f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 2f
            )
        }

        // Create line path
        if (points.isNotEmpty()) {
            val path = Path().apply {
                moveTo(points.first().x, points.first().y)
                for (i in 1 until points.size) {
                    lineTo(points[i].x, points[i].y)
                }
            }

            // Draw area under line
            val fillPath = Path().apply {
                addPath(path)
                lineTo(points.last().x, height)
                lineTo(points.first().x, height)
                close()
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(fillColor, Color.Transparent),
                    startY = 0f,
                    endY = height
                )
            )

            // Draw line
            drawPath(
                path = path,
                color = color,
                style = Stroke(width = 6f, cap = StrokeCap.Round)
            )

            // Draw markers for final point
            val lastPoint = points.last()
            drawCircle(
                color = Color.White,
                radius = 12f,
                center = lastPoint
            )
            drawCircle(
                color = color,
                radius = 8f,
                center = lastPoint
            )
        }
    }
}
