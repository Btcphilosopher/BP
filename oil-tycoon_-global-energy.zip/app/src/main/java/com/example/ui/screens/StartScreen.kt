package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.theme.*

@Composable
fun StartScreen(viewModel: GameViewModel) {
    var companyName by remember { mutableStateOf("Ashcombe Energy") }
    var selectedDifficulty by remember { mutableStateOf("Normal") }
    var selectedMode by remember { mutableStateOf("Career") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(EnergyDarkBg, EnergyDarkSurface)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Title Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "OIL TYCOON",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    color = EnergyGold,
                    letterSpacing = 4.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "GLOBAL ENERGY STRATEGY SIMULATOR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EnergyCyan,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Description Card
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Establish and scale an independent energy major from January 2026. Manage exploration licences, 3D seismic surveys, deepwater exploratory wells, oil pipelines, local refineries, global tankers, and coordinate corporate finances.",
                        fontSize = 13.sp,
                        color = EnergyTextSecondary,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Input Fields
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "CORPORATE ENTITY NAME",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EnergyTextSecondary
                )
                OutlinedTextField(
                    value = companyName,
                    onValueChange = { companyName = it },
                    textStyle = TextStyle(color = EnergyTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EnergyGold,
                        unfocusedBorderColor = EnergyBorder,
                        focusedLabelColor = EnergyGold,
                        cursorColor = EnergyGold
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Mode Selector
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "CAMPAIGN MODE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EnergyTextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    listOf("Career", "Sandbox").forEach { mode ->
                        val isSelected = selectedMode == mode
                        Button(
                            onClick = { selectedMode = mode },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) EnergyGold else EnergyDarkSurface,
                                contentColor = if (isSelected) Color.Black else EnergyTextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(
                                    BorderStroke(1.dp, if (isSelected) EnergyGold else EnergyBorder),
                                    shape = RoundedCornerShape(8.dp)
                                )
                        ) {
                            Text(text = mode, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }

            // Difficulty Selector (Only for Career)
            if (selectedMode == "Career") {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "STARTING LIQUIDITY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EnergyTextSecondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Easy", "Normal", "Hard").forEach { diff ->
                            val isSelected = selectedDifficulty == diff
                            val cashStr = when (diff) {
                                "Easy" -> "$1.0B"
                                "Normal" -> "$500M"
                                else -> "$100M"
                            }
                            Button(
                                onClick = { selectedDifficulty = diff },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) EnergyCyan.copy(alpha = 0.2f) else EnergyDarkSurface,
                                    contentColor = if (isSelected) EnergyCyan else EnergyTextSecondary
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        BorderStroke(1.dp, if (isSelected) EnergyCyan else EnergyBorder),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = diff, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(text = cashStr, fontSize = 10.sp, color = EnergyTextPrimary)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Launch Button
            Button(
                onClick = {
                    viewModel.startNewGame(companyName, selectedMode)
                    viewModel.selectScreen("DASHBOARD")
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = EnergyGold,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(
                    text = "LAUNCH GLOBAL OPERATIONS",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}
