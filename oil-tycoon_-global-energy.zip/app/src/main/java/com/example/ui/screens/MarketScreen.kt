package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.components.LineChart
import com.example.ui.theme.*

@Composable
fun MarketScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    val market = state.market

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Market Benchmarks Header
        item {
            Text(
                "GLOBAL ENERGY TRADING FLOOR",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("CRUDE OIL BENCHMARKS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyGold)
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MarketPriceCard(label = "BRENT CRUDE", price = "$${String.format("%.2f", market.brentPrice)}", region = "North Sea / Global", color = EnergyGold)
                        MarketPriceCard(label = "WTI CRUDE", price = "$${String.format("%.2f", market.wtiPrice)}", region = "North America", color = EnergyTextPrimary)
                        MarketPriceCard(label = "DUBAI CRUDE", price = "$${String.format("%.2f", market.dubaiPrice)}", region = "Middle East / Asia", color = EnergyCyan)
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("NATURAL GAS BENCHMARKS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyCyan)
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MarketPriceCard(label = "HENRY HUB", price = "$${String.format("%.2f", market.gasPriceHenryHub)}", region = "US Domestic", color = EnergyCyan)
                        MarketPriceCard(label = "TTF EUROPE", price = "$${String.format("%.2f", market.gasPriceEurope)}", region = "European Union", color = EnergyGold)
                        MarketPriceCard(label = "JKM ASIAN LNG", price = "$${String.format("%.2f", market.gasPriceAsiaLNG)}", region = "Asia Imports", color = EnergyGreen)
                    }
                }
            }
        }

        // Global Balances
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("PHYSICAL SUPPLY & DEMAND BALANCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)

                    Divider(color = EnergyBorder)

                    MarketBalanceRow(label = "Global Demand Volume:", value = "${String.format("%.1f", market.globalDemandMBPD)} MBPD")
                    MarketBalanceRow(label = "Global Supply Volume:", value = "${String.format("%.1f", market.globalSupplyMBPD)} MBPD")
                    
                    val balance = market.globalSupplyMBPD - market.globalDemandMBPD
                    val balanceColor = if (balance > 0) EnergyRed else EnergyGreen
                    val balanceSign = if (balance > 0) "+" else ""
                    MarketBalanceRow(
                        label = "Market Balance:", 
                        value = "$balanceSign${String.format("%.2f", balance)} MBPD", 
                        valueColor = balanceColor
                    )

                    MarketBalanceRow(label = "Global Inventory Days:", value = "${String.format("%.1f", market.inventoryDays)} Days (Target: 55)")
                    MarketBalanceRow(label = "Macroeconomic Climate:", value = market.economyState.uppercase(), valueColor = if (market.economyState == "Boom") EnergyGreen else if (market.economyState == "Recession") EnergyRed else EnergyTextPrimary)
                }
            }
        }
    }
}

@Composable
fun RowScope.MarketPriceCard(label: String, price: String, region: String, color: Color) {
    Column(
        modifier = Modifier.weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = label, fontSize = 10.sp, color = EnergyTextSecondary, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = price, fontSize = 18.sp, fontWeight = FontWeight.Black, color = color)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = region, fontSize = 9.sp, color = EnergyTextSecondary)
    }
}

@Composable
fun MarketBalanceRow(label: String, value: String, valueColor: Color = EnergyTextPrimary) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = EnergyTextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
