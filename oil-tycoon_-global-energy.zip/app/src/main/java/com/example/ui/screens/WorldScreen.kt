package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.models.Region
import com.example.ui.theme.*

@Composable
fun WorldScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    val selectedRegion = state.regions.find { it.id == state.selectedRegionId }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
    ) {
        // Left Column: Regions List
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "GLOBAL ENERGY REGIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary,
                modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(state.regions) { region ->
                    val isSelected = region.id == state.selectedRegionId
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) EnergyGold.copy(alpha = 0.15f) else EnergyDarkSurface
                        ),
                        border = BorderStroke(1.dp, if (isSelected) EnergyGold else EnergyBorder),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectRegion(region.id) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = region.name.uppercase(),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) EnergyGold else EnergyTextPrimary
                                )
                                Row {
                                    for (i in 1..5) {
                                        Icon(
                                            imageVector = if (i <= region.potentialStars) Icons.Default.Star else Icons.Default.StarBorder,
                                            contentDescription = "Rating Star",
                                            tint = if (i <= region.potentialStars) EnergyGold else EnergyTextSecondary,
                                            modifier = Modifier.size(10.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Risk: ${region.geologicalRisk}",
                                    fontSize = 10.sp,
                                    color = when (region.geologicalRisk) {
                                        "High" -> EnergyRed
                                        "Medium" -> EnergyGold
                                        else -> EnergyGreen
                                    },
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Well: $${region.typicalWellCostM}M",
                                    fontSize = 10.sp,
                                    color = EnergyTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Region Details Pane
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(EnergyDarkSurface)
                .border(BorderStroke(1.dp, EnergyBorder))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (selectedRegion == null) {
                // Empty State Detail Pane
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = "No region selected",
                            tint = EnergyTextSecondary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "SELECT A REGION TO INSPECT STATS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = EnergyTextSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
            } else {
                // Region Detail Sheet
                Text(
                    text = selectedRegion.name.uppercase(),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = EnergyGold
                )

                Divider(color = EnergyBorder, thickness = 1.dp)

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    DetailRow(label = "EXPLORATION POTENTIAL", value = "${selectedRegion.potentialStars}/5 Stars")
                    DetailRow(label = "GEOLOGICAL RISK", value = selectedRegion.geologicalRisk, valueColor = when (selectedRegion.geologicalRisk) {
                        "High" -> EnergyRed
                        "Medium" -> EnergyGold
                        else -> EnergyGreen
                    })
                    DetailRow(label = "POLITICAL RISK", value = selectedRegion.politicalRisk, valueColor = when (selectedRegion.politicalRisk) {
                        "High" -> EnergyRed
                        "Medium" -> EnergyGold
                        else -> EnergyGreen
                    })
                    DetailRow(label = "LOCAL INFRASTRUCTURE", value = selectedRegion.infrastructure)
                    DetailRow(label = "TYPICAL WATER DEPTH", value = if (selectedRegion.waterDepthM == 0) "Onshore (0m)" else "${selectedRegion.waterDepthM}m")
                    DetailRow(label = "ESTIMATED DRILL COST", value = "$${selectedRegion.typicalWellCostM}M")
                    DetailRow(label = "GOVERNMENT ROYALTY/TAX", value = "${(selectedRegion.governmentTake * 100).toInt()}%")
                }

                Spacer(modifier = Modifier.weight(1f))

                // Action to quick jump to explore licences in this region
                Button(
                    onClick = {
                        viewModel.selectScreen("EXPLORE")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EnergyCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "ACQUIRE LICENCES", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String, valueColor: Color = EnergyTextPrimary) {
    Column {
        Text(text = label, fontSize = 9.sp, color = EnergyTextSecondary, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 13.sp, color = valueColor, fontWeight = FontWeight.Bold)
    }
}
