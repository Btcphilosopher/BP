package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.models.Licence
import com.example.models.Prospect
import com.example.ui.theme.*

@Composable
fun ExplorationScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    val region = state.regions.find { it.id == state.selectedRegionId }

    var drillingProspect by remember { mutableStateOf<Prospect?>(null) }
    var selectedWellType by remember { mutableStateOf("Onshore") }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
    ) {
        // Left Column: Licenses Available
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = if (region != null) "BLOCK LICENCES: ${region.name.uppercase()}" else "BLOCK LICENCES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary,
                modifier = Modifier.padding(start = 8.dp)
            )

            if (region == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = EnergyTextSecondary, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("SELECT A REGION IN WORLD MAP FIRST", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                    }
                }
            } else {
                val regionLicences = state.licences.filter { it.regionId == region.id }
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(regionLicences) { lic ->
                        val isSelected = lic.id == state.selectedLicenceId
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) EnergyGold.copy(alpha = 0.15f) else EnergyDarkSurface
                            ),
                            border = BorderStroke(1.dp, if (isSelected) EnergyGold else EnergyBorder),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectLicence(lic.id) }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("BLOCK ${lic.blockNumber}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = EnergyTextPrimary)
                                    Text("COST: $${lic.costM}M", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyGold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Est: ${lic.estimatedResourcesM.toInt()} MMbbl", fontSize = 11.sp, color = EnergyTextSecondary)
                                    Text("Seismic: ${(lic.seismicConfidence * 100).toInt()}% Conf", fontSize = 11.sp, color = EnergyCyan, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Exploration / Seismic / Drilling Detail Pane
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(EnergyDarkSurface)
                .border(BorderStroke(1.dp, EnergyBorder))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val selectedLic = state.licences.find { it.id == state.selectedLicenceId }

            if (selectedLic == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("SELECT A BLOCK TO MANAGE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                }
            } else {
                Text(
                    text = "BLOCK ${selectedLic.blockNumber} OPERATIONS",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = EnergyGold
                )

                Divider(color = EnergyBorder)

                // Seismic Upgrades
                Text("SEISMIC ACQUISITIONS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // 3D Seismic
                    Button(
                        onClick = { viewModel.runSeismicSurvey(selectedLic.id, 3) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedLic.isSeismic3D) EnergyCyan.copy(alpha = 0.2f) else EnergyDarkBg
                        ),
                        enabled = !selectedLic.isSeismic3D && state.playerCompany.cashM >= 18.0,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, if (selectedLic.isSeismic3D) EnergyCyan else EnergyBorder), RoundedCornerShape(6.dp))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("RUN 3D SEISMIC SURVEY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedLic.isSeismic3D) EnergyCyan else EnergyTextPrimary)
                            Text("Cost: $18M | Confidence +24%", fontSize = 9.sp, color = EnergyTextSecondary)
                        }
                    }

                    // 4D Seismic
                    Button(
                        onClick = { viewModel.runSeismicSurvey(selectedLic.id, 4) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedLic.isSeismic4D) EnergyCyan.copy(alpha = 0.2f) else EnergyDarkBg
                        ),
                        enabled = !selectedLic.isSeismic4D && state.playerCompany.cashM >= 40.0,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, if (selectedLic.isSeismic4D) EnergyCyan else EnergyBorder), RoundedCornerShape(6.dp))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("RUN 4D SEISMIC SURVEY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedLic.isSeismic4D) EnergyCyan else EnergyTextPrimary)
                            Text("Cost: $40M | Confidence +35%", fontSize = 9.sp, color = EnergyTextSecondary)
                        }
                    }
                }

                Divider(color = EnergyBorder)

                // Prospects identified
                Text("IDENTIFIED PROSPECTS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EnergyTextSecondary)
                
                val licProspects = state.prospects.filter { it.licenceId == selectedLic.id }
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(licProspects) { prospect ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = EnergyDarkBg),
                            border = BorderStroke(1.dp, EnergyBorder),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(prospect.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EnergyTextPrimary)
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Est: ${prospect.estimatedResourcesMin.toInt()}-${prospect.estimatedResourcesMax.toInt()} MMbbl", fontSize = 10.sp, color = EnergyTextSecondary)
                                    Text("Chance: ${(prospect.geologicalProbability * selectedLic.seismicConfidence * 100).toInt()}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EnergyGreen)
                                }
                                Spacer(modifier = Modifier.height(6.dp))

                                if (prospect.isDrilled) {
                                    Button(
                                        onClick = { viewModel.selectWell(prospect.drilledWellId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = EnergyBorder),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.fillMaxWidth().height(28.dp),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text("VIEW WELL LOGS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EnergyTextPrimary)
                                    }
                                } else {
                                    Button(
                                        onClick = { drillingProspect = prospect },
                                        colors = ButtonDefaults.buttonColors(containerColor = EnergyGold, contentColor = Color.Black),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.fillMaxWidth().height(28.dp),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text("DRILL EXPLORATION WELL", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Drilling Choice Dialog
    if (drillingProspect != null) {
        val prospect = drillingProspect!!
        AlertDialog(
            onDismissRequest = { drillingProspect = null },
            title = { Text("SELECT DRILLING ENGINEERING SPEC", color = EnergyGold, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select appropriate subsea or onshore engineering standard for ${prospect.name}.", fontSize = 12.sp, color = EnergyTextSecondary)

                    val specs = listOf(
                        "Onshore" to 12.0,
                        "Offshore" to 45.0,
                        "Deepwater" to 100.0,
                        "Ultra-Deepwater" to 160.0
                    )

                    specs.forEach { (type, cost) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedWellType = type }
                                .background(if (selectedWellType == type) EnergyGold.copy(alpha = 0.15f) else Color.Transparent)
                                .border(BorderStroke(1.dp, if (selectedWellType == type) EnergyGold else EnergyBorder), RoundedCornerShape(4.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(type, fontWeight = FontWeight.Bold, color = EnergyTextPrimary, fontSize = 13.sp)
                            Text("Capex: $${cost}M", color = EnergyGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.drillProspect(prospect.id, selectedWellType)
                        drillingProspect = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EnergyGold, contentColor = Color.Black)
                ) {
                    Text("SPUD WELL", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { drillingProspect = null }) {
                    Text("ABORT", color = EnergyTextSecondary)
                }
            },
            containerColor = EnergyDarkSurface
        )
    }
}
