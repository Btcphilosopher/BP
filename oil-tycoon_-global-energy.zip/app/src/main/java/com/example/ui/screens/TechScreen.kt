package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.theme.*

@Composable
fun TechScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    
    // Group technologies by their categories
    val groupedTechs = state.technologies.groupBy { it.category }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "RESEARCH & DEVELOPMENT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary
            )
        }

        groupedTechs.forEach { (category, techs) ->
            item {
                Text(
                    text = category.replace("_", " "),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = EnergyCyan,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(techs) { tech ->
                val isUnlocked = tech.unlocked
                val canAfford = state.playerCompany.cashM >= tech.costM

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isUnlocked) EnergyGreen.copy(alpha = 0.08f) else EnergyDarkSurface
                    ),
                    border = BorderStroke(1.dp, if (isUnlocked) EnergyGreen else EnergyBorder),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(
                                text = tech.name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = EnergyTextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = tech.description,
                                fontSize = 10.sp,
                                color = EnergyTextSecondary,
                                lineHeight = 13.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // Unlock button / status indicator
                        if (isUnlocked) {
                            Text(
                                text = "UNLOCKED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = EnergyGreen,
                                modifier = Modifier.weight(0.8f),
                                style = LocalTextStyle.current.copy(textAlign = androidx.compose.ui.text.style.TextAlign.End)
                            )
                        } else {
                            Button(
                                onClick = { viewModel.unlockTechnology(tech.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (canAfford) EnergyGold else EnergyBorder,
                                    contentColor = if (canAfford) Color.Black else EnergyTextSecondary
                                ),
                                enabled = canAfford,
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    text = "$${tech.costM.toInt()}M",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
