package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.theme.*

@Composable
fun FinanceScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    val company = state.playerCompany

    var borrowingLoanAmount by remember { mutableStateOf<Double?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Corporate P&L Report
        item {
            Text(
                "CORPORATE TREASURY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("MONTHLY INCOME STATEMENT (P&L)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyGold)

                    Divider(color = EnergyBorder)

                    FinanceRow(label = "Gross Hydrocarbon Revenue:", value = "$${String.format("%.2f", company.revenueM)}M", valueColor = EnergyGreen)
                    FinanceRow(label = "Government Royalties (10%):", value = "-$${String.format("%.2f", company.royaltiesPaidM)}M", valueColor = EnergyRed)
                    FinanceRow(label = "Operating Costs (OPEX & Infra):", value = "-$${String.format("%.2f", company.revenueM - company.royaltiesPaidM - company.ebitdaM)}M", valueColor = EnergyRed)
                    
                    Divider(color = EnergyBorder)

                    FinanceRow(label = "EBITDA:", value = "$${String.format("%.2f", company.ebitdaM)}M", valueColor = EnergyGold, isBold = true)
                    
                    val interestPaid = (company.debtM * 0.08) / 12.0
                    FinanceRow(label = "Debt Interest Payments (8% APY):", value = "-$${String.format("%.2f", interestPaid)}M", valueColor = EnergyRed)
                    FinanceRow(label = "Corporate Income Tax (35%):", value = "-$${String.format("%.2f", company.taxPaidM)}M", valueColor = EnergyRed)

                    Divider(color = EnergyBorder)

                    FinanceRow(label = "Net Income:", value = "$${String.format("%.2f", company.netIncomeM)}M", valueColor = if (company.netIncomeM >= 0) EnergyGreen else EnergyRed, isBold = true)
                }
            }
        }

        // Debt Facilities & Financing
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                border = BorderStroke(1.dp, EnergyBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CREDIT FACILITIES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EnergyCyan)
                            Text("Total Outstanding Debt: $${String.format("%.1f", company.debtM)}M", fontSize = 11.sp, color = EnergyTextSecondary)
                        }
                        Button(
                            onClick = { borrowingLoanAmount = 100.0 }, // default selection trigger
                            colors = ButtonDefaults.buttonColors(containerColor = EnergyCyan, contentColor = Color.Black),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("DRAW CREDIT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Divider(color = EnergyBorder)

                    if (state.activeLoans.isEmpty()) {
                        Text(
                            "No active bank debt. The balance sheet is fully deleveraged.",
                            fontSize = 11.sp,
                            color = EnergyTextSecondary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        state.activeLoans.forEach { loan ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(BorderStroke(1.dp, EnergyBorder), RoundedCornerShape(6.dp))
                                    .background(EnergyDarkBg)
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Facility principal: $${loan.principalM.toInt()}M", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EnergyTextPrimary)
                                    Text("Interest: 8.0% | Pay: $${String.format("%.2f", loan.monthlyPaymentM)}M/mo", fontSize = 10.sp, color = EnergyTextSecondary)
                                    Text("Maturity: ${loan.monthsRemaining} months left", fontSize = 10.sp, color = EnergyCyan)
                                }
                                Button(
                                    onClick = { viewModel.repayLoan(loan.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EnergyRed.copy(alpha = 0.2f), contentColor = EnergyRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.height(28.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text("REPAY EARLY", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Loan Dialog
    if (borrowingLoanAmount != null) {
        AlertDialog(
            onDismissRequest = { borrowingLoanAmount = null },
            title = { Text("DRAW DOWN DEBT CAPITAL", color = EnergyGold, fontWeight = FontWeight.Black, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select debt principal to draw down. Monthly payments amortized over 60 months at 8% APY.", fontSize = 12.sp, color = EnergyTextSecondary)

                    listOf(100.0, 500.0, 1000.0).forEach { amt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { borrowingLoanAmount = amt }
                                .background(if (borrowingLoanAmount == amt) EnergyGold.copy(alpha = 0.15f) else Color.Transparent)
                                .border(BorderStroke(1.dp, if (borrowingLoanAmount == amt) EnergyGold else EnergyBorder), RoundedCornerShape(4.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Draw $${amt.toInt()}M Facility", fontWeight = FontWeight.Bold, color = EnergyTextPrimary, fontSize = 13.sp)
                            Text("Pay: $${String.format("%.1f", amt * 0.02)}M/mo", color = EnergyGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.takeLoan(borrowingLoanAmount!!)
                        borrowingLoanAmount = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EnergyGold, contentColor = Color.Black)
                ) {
                    Text("SANCTION LOAN", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { borrowingLoanAmount = null }) {
                    Text("CANCEL", color = EnergyTextSecondary)
                }
            },
            containerColor = EnergyDarkSurface
        )
    }
}

@Composable
fun FinanceRow(label: String, value: String, valueColor: Color = EnergyTextPrimary, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = EnergyTextSecondary, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal)
        Text(text = value, fontSize = 12.sp, fontWeight = if (isBold) FontWeight.Black else FontWeight.Bold, color = valueColor)
    }
}
