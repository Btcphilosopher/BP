package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.ui.theme.*

@Composable
fun NewsScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "GLOBAL HYDROCARBON WIRE INTELLIGENCE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = EnergyTextSecondary
            )
        }

        if (state.news.isEmpty()) {
            item {
                Text(
                    text = "No intelligence reports logged yet. Advance the month to trigger reports.",
                    fontSize = 12.sp,
                    color = EnergyTextSecondary,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
        } else {
            items(state.news) { news ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = EnergyDarkSurface),
                    border = BorderStroke(1.dp, EnergyBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = news.type,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (news.type) {
                                    "MARKET" -> EnergyGold
                                    "EXPLORATION" -> EnergyCyan
                                    else -> EnergyGreen
                                }
                            )
                            Text(
                                text = news.dateStr,
                                fontSize = 10.sp,
                                color = EnergyTextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = news.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = EnergyTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = news.content,
                            fontSize = 12.sp,
                            color = EnergyTextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
