package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameViewModel
import com.example.models.DevOption
import com.example.models.WellOutcome
import com.example.ui.theme.*

@Composable
fun DiscoveryScreen(viewModel: GameViewModel) {
    val state by viewModel.gameState.collectAsState()
    val well = state.wells.find { it.id == state.selectedWellId }

    if (well == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(EnergyDarkBg),
            contentAlignment = Alignment.Center
        ) {
            Text("No active drilling logs found. Select a prospect to drill.", color = EnergyTextSecondary)
        }
        return
    }

    var selectedDevOption by remember { mutableStateOf(DevOption.STANDARD) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(EnergyDarkBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .background(EnergyDarkSurface, shape = RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, EnergyBorder), shape = RoundedCornerShape(12.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = well.name.uppercase(),
                fontSize = 12.sp,
                color = EnergyCyan,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            val isSuccess = well.outcome != WellOutcome.DRY_HOLE && well.outcome != WellOutcome.OIL_SHOW
            
            Text(
                text = well.outcome.name.replace("_", " "),
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = if (isSuccess) EnergyGreen else EnergyRed,
                textAlign = TextAlign.Center
            )

            Divider(color = EnergyBorder)

            if (isSuccess) {
                // Discover Stats details
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ReportRow(label = "Recoverable reserves:", value = "${well.actualReservesM.toInt()} MMbbl")
                    ReportRow(label = "API Gravity:", value = "${String.format("%.1f", well.apiGravity)}° (Light Sweet)")
                    ReportRow(label = "Reservoir Pressure:", value = well.reservoirPressure)
                    ReportRow(label = "Gas/Oil Ratio:", value = well.gasOilRatio)
                    ReportRow(label = "Development Complexity:", value = well.developmentComplexity)
                    ReportRow(label = "Base CAPEX estimate:", value = "$${well.capexEstimateM.toInt()}M")
                    ReportRow(label = "Peak Production estimate:", value = "${well.peakProdEstimateBOPD.toInt()} BOPD")
                }

                Divider(color = EnergyBorder)

                // Choose Development Option
                Text(
                    text = "SELECT DEVELOPMENT SPECS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EnergyTextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        DevOption.MINIMAL to "MIN (-40% cost/prod)",
                        DevOption.STANDARD to "STANDARD",
                        DevOption.MAXIMUM to "MAX (+50% cost/prod)"
                    ).forEach { (opt, label) ->
                        val isSelected = selectedDevOption == opt
                        Button(
                            onClick = { selectedDevOption = opt },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) EnergyGold.copy(alpha = 0.2f) else EnergyDarkBg,
                                contentColor = if (isSelected) EnergyGold else EnergyTextSecondary
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(BorderStroke(1.dp, if (isSelected) EnergyGold else EnergyBorder), RoundedCornerShape(6.dp)),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Appraise/Develop action
                    Button(
                        onClick = {
                            viewModel.developField(well.id, selectedDevOption)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EnergyGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text("DEVELOP FIELD", fontWeight = FontWeight.Black)
                    }

                    // Abandon
                    Button(
                        onClick = { viewModel.selectScreen("EXPLORE") },
                        colors = ButtonDefaults.buttonColors(containerColor = EnergyDarkBg),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(BorderStroke(1.dp, EnergyBorder), RoundedCornerShape(8.dp))
                    ) {
                        Text("ABANDON", color = EnergyTextSecondary, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                // Dry hole message
                Text(
                    text = "Geological evaluation reveals zero commercial hydrocarbon accumulation. The reservoir is primarily filled with brine water.",
                    fontSize = 13.sp,
                    color = EnergyTextSecondary,
                    lineHeight = 18.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { viewModel.selectScreen("EXPLORE") },
                    colors = ButtonDefaults.buttonColors(containerColor = EnergyGold, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("RETURN TO EXPLORATION", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ReportRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = EnergyTextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EnergyTextPrimary)
    }
}
