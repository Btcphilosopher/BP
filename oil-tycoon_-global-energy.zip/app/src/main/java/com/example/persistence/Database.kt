package com.example.persistence

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "save_slots")
data class SaveSlot(
    @PrimaryKey val id: Int, // 1, 2, 3 (multiple slots)
    val companyName: String,
    val dateStr: String,
    val lastSaved: Long,
    val jsonState: String
)

@Dao
interface SaveSlotDao {
    @Query("SELECT * FROM save_slots ORDER BY id ASC")
    fun getAllSlots(): Flow<List<SaveSlot>>

    @Query("SELECT * FROM save_slots WHERE id = :id LIMIT 1")
    suspend fun getSlotById(id: Int): SaveSlot?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSlot(slot: SaveSlot)

    @Query("DELETE FROM save_slots WHERE id = :id")
    suspend fun deleteSlot(id: Int)
}

@Database(entities = [SaveSlot::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun saveSlotDao(): SaveSlotDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "oil_tycoon_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
