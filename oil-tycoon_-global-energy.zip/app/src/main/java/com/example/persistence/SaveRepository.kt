package com.example.persistence

import android.content.Context
import com.example.game.GameState
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class SaveRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val dao = db.saveSlotDao()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(GameState::class.java)

    fun getAllSlots(): Flow<List<SaveSlot>> = dao.getAllSlots()

    suspend fun loadGame(slotId: Int): GameState? = withContext(Dispatchers.IO) {
        val slot = dao.getSlotById(slotId) ?: return@withContext null
        try {
            adapter.fromJson(slot.jsonState)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun saveGame(slotId: Int, state: GameState) = withContext(Dispatchers.IO) {
        val json = adapter.toJson(state)
        val slot = SaveSlot(
            id = slotId,
            companyName = state.playerCompany.name,
            dateStr = "${state.currentMonthStr} ${state.currentYearStr}",
            lastSaved = System.currentTimeMillis(),
            jsonState = json
        )
        dao.insertSlot(slot)
    }

    suspend fun deleteSlot(slotId: Int) = withContext(Dispatchers.IO) {
        dao.deleteSlot(slotId)
    }
}
