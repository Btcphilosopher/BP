package com.example.simulation

import com.example.models.*
import com.example.game.GameState
import kotlin.random.Random

object Simulation {

    fun processMonth(state: GameState) {
        val random = Random(state.seed + state.currentMonth)
        state.seed = random.nextLong() // Cycle the seed

        // 1. Process Oil & Gas Market
        simulateMarket(state, random)

        // 2. Process Field Production & Reservoir Depletion
        simulateProductionAndReservoirs(state)

        // 3. Process Logistics Bottlenecks
        applyLogisticsBottlenecks(state)

        // 4. Process Company Finances (Player and AI)
        simulateFinances(state)

        // 5. AI Competitor Actions
        simulateCompetitorAI(state, random)

        // 6. Political & Environmental Events & News
        triggerEventsAndNews(state, random)

        // 7. Check Bankruptcy and Victory conditions
        checkBankruptcyAndVictory(state)

        // 8. Advance Clock
        state.currentMonth++
        
        // Expiry of licenses
        state.licences.forEach { lic ->
            // Check if player or AI owns this and check expiry
            // Just simulate natural decay of licenses
        }
    }

    private fun simulateMarket(state: GameState, random: Random) {
        val market = state.market

        // Random economic state transition
        if (random.nextDouble() < 0.05) {
            market.economyState = when (market.economyState) {
                "Normal" -> if (random.nextBoolean()) "Boom" else "Recession"
                "Boom" -> "Normal"
                "Recession" -> "Normal"
                else -> "Normal"
            }
            
            // News about economic shift
            val title = when (market.economyState) {
                "Boom" -> "Global Economy Booming!"
                "Recession" -> "Fears of Global Recession Intensify"
                else -> "Global Economic Growth Stabilizes"
            }
            val content = when (market.economyState) {
                "Boom" -> "Industrial demand is surging worldwide. Factory output is hitting record highs."
                "Recession" -> "Central banks warn of slowing trade and falling demand. Energy consumption is projected to drop."
                else -> "Standard trade flows continue. Supply and demand remain balanced."
            }
            state.news = listOf(NewsItem("news_econ_${state.currentMonth}", state.currentMonthStr + " " + state.currentYearStr, title, content, "MARKET")) + state.news
        }

        // Base demand based on economy
        val targetDemand = when (market.economyState) {
            "Boom" -> 103.5 + random.nextDouble(-0.5, 1.0)
            "Recession" -> 98.0 + random.nextDouble(-1.0, 0.5)
            else -> 101.5 + random.nextDouble(-0.5, 0.5)
        }

        // Calculate global production (player + AI + base OPEC/Non-OPEC production)
        val playerProdMBPD = state.playerCompany.productionBOPD / 1_000_000.0
        val aiProdMBPD = state.aiCompanies.sumOf { it.productionBOPD } / 1_000_000.0
        val baseGlobalProdMBPD = 101.0 - playerProdMBPD - aiProdMBPD

        market.globalSupplyMBPD = baseGlobalProdMBPD + playerProdMBPD + aiProdMBPD
        market.globalDemandMBPD = targetDemand

        // Inventory Days calculation
        val balance = market.globalSupplyMBPD - market.globalDemandMBPD
        market.inventoryDays = (market.inventoryDays + balance * 2.0).coerceIn(40.0, 70.0)

        // Brent price responds to inventory levels
        // Base Brent price is $75. If inventories are low (40 days), Brent can skyrocket to $120. If high (70 days), crash to $40.
        val baseBrent = 75.0
        val inventoryDeviation = 55.0 - market.inventoryDays // Positive means low inventory (bullish)
        market.brentPrice = (baseBrent + (inventoryDeviation * 2.8)).coerceIn(35.0, 140.0)
        
        // Benchmarks follow Brent with realistic spreads
        market.wtiPrice = (market.brentPrice - 4.50 + random.nextDouble(-0.5, 0.5)).coerceAtLeast(30.0)
        market.dubaiPrice = (market.brentPrice - 2.00 + random.nextDouble(-0.3, 0.3)).coerceAtLeast(32.0)

        // Gas prices
        market.gasPriceHenryHub = (3.00 + (inventoryDeviation * 0.1) + random.nextDouble(-0.2, 0.2)).coerceIn(1.50, 8.00)
        market.gasPriceEurope = (market.gasPriceHenryHub * 3.5 + random.nextDouble(-1.0, 1.0)).coerceIn(5.00, 45.00)
        market.gasPriceAsiaLNG = (market.gasPriceEurope * 1.1 + random.nextDouble(-0.5, 0.5)).coerceIn(6.00, 50.00)
    }

    private fun simulateProductionAndReservoirs(state: GameState) {
        state.fields.forEach { field ->
            if (field.remainingReservesM <= 0.0) {
                field.currentProdBOPD = 0.0
                return@forEach
            }

            field.ageMonths++

            // Calculate natural decline
            // Simple decline curve: prod = peak * e ^ (-decline * t)
            // But we can model decline based on fraction of remaining reserves:
            val fractionRemaining = field.remainingReservesM / field.recoverableReservesM
            field.reservoirPressureFactor = fractionRemaining.coerceIn(0.1, 1.0)
            
            // Adjust water cut based on depletion
            field.waterCut = ((1.0 - fractionRemaining) * 0.95).coerceIn(0.0, 0.99)

            // Base decline rate
            var actualDeclineRate = field.declineRate / 12.0 // Monthly decline

            // Technologies and field investments that slow decline or increase production
            var boosterMultiplier = 1.0
            if (field.waterInjection) {
                boosterMultiplier += 0.10
                actualDeclineRate *= 0.8
            }
            if (field.gasInjection) {
                boosterMultiplier += 0.10
                actualDeclineRate *= 0.85
            }
            if (field.infillDrilling) {
                boosterMultiplier += 0.15
                actualDeclineRate *= 0.9
            }
            if (field.horizontalWells) {
                boosterMultiplier += 0.25
                actualDeclineRate *= 0.75
            }
            if (field.eorEnabled) {
                boosterMultiplier += 0.30
                actualDeclineRate *= 0.7
            }

            // Tech tree upgrades unlocked by player
            val isPlayerField = state.licences.any { lic -> lic.id == field.licenceId && lic.regionId == field.regionId } // simplifed check, fields have regionId
            // If player field, apply unlocked technology effects
            if (isPlayerField) {
                if (state.playerCompany.unlockedTechIds.contains("t_horiz_drilling")) {
                    boosterMultiplier += 0.10
                }
                if (state.playerCompany.unlockedTechIds.contains("t_smart_wells")) {
                    field.waterCut = (field.waterCut * 0.85).coerceAtLeast(0.0)
                }
                if (state.playerCompany.unlockedTechIds.contains("t_eor")) {
                    boosterMultiplier += 0.15
                }
            }

            // Current field capacity
            val fieldCapacity = field.peakProdBOPD * field.reservoirPressureFactor * (1.0 - field.waterCut) * boosterMultiplier
            field.currentProdBOPD = fieldCapacity.coerceIn(0.0, field.peakProdBOPD * 1.5)

            // Deplete reservoir reserves
            val monthlyProductionM = (field.currentProdBOPD * 30.0) / 1_000_000.0
            field.remainingReservesM = (field.remainingReservesM - monthlyProductionM).coerceAtLeast(0.0)

            if (field.remainingReservesM <= 0.0) {
                field.currentProdBOPD = 0.0
            }
        }
    }

    private fun applyLogisticsBottlenecks(state: GameState) {
        // Compute total built infrastructure capacity per region for the player
        val regionCapacities = state.infrastructures
            .groupBy { it.locationRegionId }
            .mapValues { (_, infraList) ->
                infraList.sumOf { it.capacityBOPD }
            }

        // Loop through player's fields and cap production if region infrastructure capacity is exceeded
        // For simplicity, we only cap if there is built infrastructure in that region and total production exceeds capacity
        val playerFieldsByRegion = state.fields.groupBy { it.regionId }

        playerFieldsByRegion.forEach { (regionId, fields) ->
            val regionCapacity = regionCapacities[regionId] ?: Double.MAX_VALUE
            // If capacity is not built yet (is null in database), we assume normal export pipelines (no cap, but transport fees are standard)
            // If they have explicitly built FPSOs/Pipelines in that region, we enforce a strict cap.
            // If they have built refineries or pipeline projects in the region, the total production from that region cannot exceed this capacity
            val totalRegionProd = fields.sumOf { it.currentProdBOPD }
            val builtInfraForRegion = state.infrastructures.filter { it.locationRegionId == regionId }
            
            if (builtInfraForRegion.isNotEmpty() && totalRegionProd > regionCapacity) {
                // Scale production down to meet the transport bottleneck
                val scale = regionCapacity / totalRegionProd
                fields.forEach { field ->
                    field.currentProdBOPD *= scale
                }
            }
        }
    }

    private fun simulateFinances(state: GameState) {
        // Player Finances
        simulateCompanyMonthlyFinance(state.playerCompany, state, isPlayer = true)

        // AI Companies Finances
        state.aiCompanies.forEach { aiCompany ->
            simulateCompanyMonthlyFinance(aiCompany, state, isPlayer = false)
        }
    }

    private fun simulateCompanyMonthlyFinance(company: Company, state: GameState, isPlayer: Boolean) {
        val brentPrice = state.market.brentPrice

        // Calculate total production and remaining reserves for this company
        var totalBOPD = 0.0
        var totalReservesM = 0.0

        if (isPlayer) {
            totalBOPD = state.fields.sumOf { it.currentProdBOPD }
            totalReservesM = state.fields.sumOf { it.remainingReservesM }
        } else {
            // Simplified AI production & reserves growth
            totalBOPD = company.productionBOPD
            totalReservesM = company.reservesM
        }

        company.productionBOPD = totalBOPD
        company.reservesM = totalReservesM

        // Calculate Revenues
        // Gas & Oil merged into barrels of oil equivalent (BOE)
        val monthlyRevenue = (totalBOPD * brentPrice * 30.0) / 1_000_000.0 // M$

        // Calculate Royalties & Government Take
        // Average royalty rate 10%
        val royaltyPaid = monthlyRevenue * 0.10
        val remainingRev = monthlyRevenue - royaltyPaid

        // Calculate Operating Costs (OPEX)
        // Average OPEX $12-$35 per barrel based on region and tech
        val baseOpex = if (isPlayer) {
            state.fields.sumOf { it.opexPerBbl * it.currentProdBOPD * 30.0 } / 1_000_000.0
        } else {
            (totalBOPD * 22.0 * 30.0) / 1_000_000.0
        }

        // Apply tech discounts for player
        var opexDiscount = 1.0
        if (isPlayer && company.unlockedTechIds.contains("t_auto_field")) {
            opexDiscount *= 0.70 // 30% discount
        }
        val opexPaid = baseOpex * opexDiscount

        // Infrastructure maintenance cost
        var infraMaintenance = 0.0
        if (isPlayer) {
            infraMaintenance = state.infrastructures.sumOf { it.opexM }
        } else {
            infraMaintenance = company.productionBOPD * 0.0005 // AI simplified
        }

        val totalOpex = opexPaid + infraMaintenance

        // EBITDA
        val ebitda = remainingRev - totalOpex

        // Interest Payments on Debt (Annual rate 8%, so monthly is 0.08 / 12)
        val monthlyInterest = (company.debtM * 0.08) / 12.0

        // Taxation (Government Tax rate ~35%)
        val taxableIncome = (ebitda - monthlyInterest).coerceAtLeast(0.0)
        val taxPaid = taxableIncome * 0.35

        // Net Income
        val netIncome = ebitda - monthlyInterest - taxPaid

        // Update Balance Sheet
        company.revenueM = monthlyRevenue
        company.ebitdaM = ebitda
        company.netIncomeM = netIncome
        company.taxPaidM = taxPaid
        company.royaltiesPaidM = royaltyPaid

        // Update Cash & Debt
        company.cashM += netIncome

        // Check active loan principals
        if (isPlayer) {
            val updatedLoans = mutableListOf<Loan>()
            state.activeLoans.forEach { loan ->
                loan.monthsRemaining--
                company.cashM -= loan.monthlyPaymentM
                if (loan.monthsRemaining > 0) {
                    updatedLoans.add(loan)
                } else {
                    // Loan paid off!
                    company.debtM -= loan.principalM
                    state.news = listOf(
                        NewsItem(
                            id = "news_loan_payoff_${state.currentMonth}",
                            dateStr = state.currentMonthStr + " " + state.currentYearStr,
                            title = "Debt Facility Retired",
                            content = "${company.name} has fully paid off its $${loan.principalM}M credit facility, strengthening its balance sheet.",
                            type = "COMPANY"
                        )
                    ) + state.news
                }
            }
            state.activeLoans = updatedLoans
        }

        // Net Worth & Share Price calculation
        // Valuation: Enterprise Value = EBITDA * 12 months * Multiple (e.g. 6.0) + Reserves Value ($3/bbl)
        val annualEbitda = (ebitda * 12.0).coerceAtLeast(0.0)
        val reservesValue = totalReservesM * 2.5 // $2.50 per barrel of reserves
        val enterpriseValue = annualEbitda * 5.0 + reservesValue
        val marketCap = (enterpriseValue + company.cashM - company.debtM).coerceAtLeast(10.0)

        company.netWorthM = marketCap
        company.sharePrice = (marketCap / company.sharesOutstandingM).coerceAtLeast(0.10)
    }

    private fun simulateCompetitorAI(state: GameState, random: Random) {
        state.aiCompanies.forEach { ai ->
            // Let them pay off some debt or accumulate cash
            if (ai.cashM < 0.0) {
                // Take loan or sell reserves
                ai.debtM += (-ai.cashM) * 1.2
                ai.cashM = 50.0
            }

            // AI Decision Making (Exploration & Drilling simulation)
            if (ai.cashM > 100.0 && random.nextDouble() < 0.15) {
                // They explore and "buy reserves" to simulate growth
                val spend = ai.cashM * ai.riskTolerance * 0.3
                ai.cashM -= spend
                val newReserves = spend * random.nextDouble(1.5, 4.0)
                ai.reservesM += newReserves

                // Increase production in 6-12 months
                val addedProd = newReserves * random.nextDouble(200.0, 500.0)
                ai.productionBOPD += addedProd

                if (random.nextDouble() < 0.3) {
                    state.news = listOf(
                        NewsItem(
                            id = "news_ai_disc_${ai.id}_${state.currentMonth}",
                            dateStr = state.currentMonthStr + " " + state.currentYearStr,
                            title = "${ai.name} Unveils Discovery",
                            content = "In its preferred region, ${ai.name} announced a major discovery adding estimated ${newReserves.toInt()} MMbbl reserves to its portfolio.",
                            type = "EXPLORATION"
                        )
                    ) + state.news
                }
            }
        }
    }

    private fun triggerEventsAndNews(state: GameState, random: Random) {
        // Trigger a random news event periodically (e.g. 20% chance per month)
        if (random.nextDouble() < 0.20) {
            val eventType = random.nextInt(5)
            val title: String
            val content: String
            val priceEffect: Double

            when (eventType) {
                0 -> {
                    title = "OPEC Announces Production Cuts"
                    content = "In an unexpected meeting, OPEC members agreed to slash oil production by 1.5 million BOPD to support crude prices amidst economic uncertainties."
                    priceEffect = 7.50
                    state.market.brentPrice += priceEffect
                }
                1 -> {
                    title = "North Sea Tax Increase Passed"
                    content = "Governments in the North Sea region have increased the offshore environmental surcharge tax, impacting operating profit margins."
                    priceEffect = -2.0
                }
                2 -> {
                    title = "Geopolitical Crisis in the Middle East"
                    content = "Escalating maritime security tensions near key transit straits raise supply disruption fears. Tanker shipping insurance premiums skyrocket."
                    priceEffect = 12.0
                    state.market.brentPrice += priceEffect
                }
                3 -> {
                    title = "Breakthrough in Horizontal Drilling Tech"
                    content = "Drilling service companies reveal new automated rotary steerable systems. Global drilling engineering costs expected to fall by 15%."
                    priceEffect = 0.0
                }
                else -> {
                    title = "Hurricane Sweeps Gulf of Mexico"
                    content = "A Category 4 hurricane has forced operators to evacuate offshore platforms and shut-in over 800,000 BOPD of deepwater production."
                    priceEffect = 4.0
                    state.market.brentPrice += priceEffect
                }
            }

            state.news = listOf(
                NewsItem(
                    id = "news_event_${state.currentMonth}",
                    dateStr = state.currentMonthStr + " " + state.currentYearStr,
                    title = title,
                    content = content,
                    type = "MARKET"
                )
            ) + state.news
        }
    }

    private fun checkBankruptcyAndVictory(state: GameState) {
        // Bankruptcy: Player runs out of cash and cannot service debt
        if (state.playerCompany.cashM < -100.0) {
            state.isGameOver = true
        }

        // Victory: Become a giant major (e.g. $20B Net Worth or 1 Million BOPD production)
        if (state.playerCompany.netWorthM >= 20000.0 || state.playerCompany.productionBOPD >= 1_000_000.0) {
            state.isVictory = true
        }
    }
}
