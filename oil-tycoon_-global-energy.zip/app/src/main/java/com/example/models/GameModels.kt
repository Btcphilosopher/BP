package com.example.models

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Region(
    val id: String,
    val name: String,
    val potentialStars: Int,
    val geologicalRisk: String, // "Low", "Medium", "High"
    val politicalRisk: String, // "Low", "Medium", "High"
    val infrastructure: String, // "Excellent", "Good", "Poor"
    val waterDepthM: Int,
    val typicalWellCostM: Double,
    val governmentTake: Double // e.g. 0.48
)

@JsonClass(generateAdapter = true)
data class Licence(
    val id: String,
    val regionId: String,
    val blockNumber: String,
    val costM: Double,
    val durationMonths: Int,
    val royaltyRate: Double,
    val taxRate: Double,
    val estimatedResourcesM: Double,
    val expiryMonth: Int, // Clock tick count
    var isSeismic2D: Boolean = false,
    var isSeismic3D: Boolean = false,
    var isSeismic4D: Boolean = false,
    var seismicConfidence: Double = 0.40
)

@JsonClass(generateAdapter = true)
data class Prospect(
    val id: String,
    val licenceId: String,
    val name: String,
    val estimatedResourcesMin: Double,
    val estimatedResourcesMax: Double,
    val geologicalProbability: Double,
    var seismicConfidence: Double,
    var isDrilled: Boolean = false,
    var drilledWellId: String? = null
)

enum class WellOutcome {
    DRY_HOLE,
    OIL_SHOW,
    SMALL_DISCOVERY,
    COMMERCIAL_DISCOVERY,
    LARGE_DISCOVERY,
    GIANT_DISCOVERY,
    SUPERGIANT_DISCOVERY,
    GAS_DISCOVERY,
    OIL_GAS_DISCOVERY
}

@JsonClass(generateAdapter = true)
data class Well(
    val id: String,
    val prospectId: String,
    val licenceId: String,
    val name: String,
    val type: String, // "Onshore", "Offshore", "Deepwater", "Ultra-Deepwater"
    val depthM: Int,
    val costM: Double,
    val durationMonths: Int,
    val outcome: WellOutcome,
    val actualReservesM: Double, // MMbbl or Bcf
    val apiGravity: Double, // e.g. 36.0
    val reservoirPressure: String, // "Low", "Medium", "High"
    val gasOilRatio: String, // "Low", "Medium", "High"
    val developmentComplexity: String, // "Low", "Medium", "High"
    val capexEstimateM: Double,
    val peakProdEstimateBOPD: Double
)

enum class DevOption {
    MINIMAL,
    STANDARD,
    MAXIMUM
}

@JsonClass(generateAdapter = true)
data class OilField(
    val id: String,
    val wellId: String,
    val licenceId: String,
    val name: String,
    val regionId: String,
    val recoverableReservesM: Double,
    var remainingReservesM: Double,
    val apiGravity: Double,
    val devOption: DevOption,
    val capexM: Double,
    var currentProdBOPD: Double,
    val peakProdBOPD: Double,
    var reservoirPressureFactor: Double = 1.0, // Declines over time
    var waterCut: Double = 0.0, // Increases over time
    val declineRate: Double, // e.g. 0.08 per year
    val opexPerBbl: Double,
    var ageMonths: Int = 0,
    var waterInjection: Boolean = false,
    var gasInjection: Boolean = false,
    var infillDrilling: Boolean = false,
    var horizontalWells: Boolean = false,
    var eorEnabled: Boolean = false
)

enum class InfrastructureType {
    PIPELINE,
    FPSO,
    REFINERY,
    TANKER
}

@JsonClass(generateAdapter = true)
data class Infrastructure(
    val id: String,
    val type: InfrastructureType,
    val name: String,
    val capexM: Double,
    val opexM: Double,
    val capacityBOPD: Double,
    val locationRegionId: String, // Region ID or "GLOBAL"
    var throughputBOPD: Double = 0.0,
    var ageMonths: Int = 0
)

@JsonClass(generateAdapter = true)
data class Technology(
    val id: String,
    val name: String,
    val category: String, // "EXPLORATION", "DRILLING", "PRODUCTION", "LOGISTICS", "TRANSITION"
    val costM: Double,
    val unlocked: Boolean = false,
    val description: String,
    val effectMultiplier: Double // e.g. reduces drill cost by 0.15 (multiplier = 0.85)
)

@JsonClass(generateAdapter = true)
data class Loan(
    val id: String,
    val principalM: Double,
    val interestRate: Double, // e.g. 0.06
    val monthlyPaymentM: Double,
    val maturityMonths: Int,
    var monthsRemaining: Int
)

enum class AiStrategy {
    AGGRESSIVE_EXPLORER,
    CONSERVATIVE_MAJOR,
    DEEPWATER_SPECIALIST,
    SHALE_SPECIALIST,
    INTEGRATED_MAJOR,
    GAS_SPECIALIST,
    VALUE_INVESTOR,
    HIGH_DEBT_GROWTH
}

@JsonClass(generateAdapter = true)
data class Company(
    val id: String,
    val name: String,
    val isPlayer: Boolean,
    var cashM: Double,
    var debtM: Double,
    var productionBOPD: Double,
    var reservesM: Double,
    var sharePrice: Double,
    var sharesOutstandingM: Double,
    var netWorthM: Double,
    var revenueM: Double = 0.0,
    var ebitdaM: Double = 0.0,
    var netIncomeM: Double = 0.0,
    var taxPaidM: Double = 0.0,
    var royaltiesPaidM: Double = 0.0,
    val aiStrategy: AiStrategy? = null,
    val riskTolerance: Double = 0.5, // 0.0 to 1.0
    val preferredRegionId: String? = null,
    val unlockedTechIds: Set<String> = emptySet()
)

@JsonClass(generateAdapter = true)
data class MarketState(
    var brentPrice: Double,
    var wtiPrice: Double,
    var dubaiPrice: Double,
    var gasPriceHenryHub: Double,
    var gasPriceEurope: Double,
    var gasPriceAsiaLNG: Double,
    var globalSupplyMBPD: Double,
    var globalDemandMBPD: Double,
    var inventoryDays: Double,
    var economyState: String // "Boom", "Normal", "Recession"
)

@JsonClass(generateAdapter = true)
data class NewsItem(
    val id: String,
    val dateStr: String,
    val title: String,
    val content: String,
    val type: String // "MARKET", "EXPLORATION", "POLITICAL", "ENVIRONMENT", "COMPANY"
)
