'use client';

import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Zap, 
  Wind, 
  Ship, 
  Leaf, 
  Globe2,
  DollarSign
} from 'lucide-react';

interface TickerItem {
  id: string;
  label: string;
  value: string;
  change: string;
  isPositive: boolean;
  icon: React.ReactNode;
}

export function LiveTelemetryTicker() {
  const [items, setItems] = useState<TickerItem[]>([
    {
      id: 'stock',
      label: 'BP.L (LSE)',
      value: '488.65 GBX',
      change: '+1.42%',
      isPositive: true,
      icon: <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
    },
    {
      id: 'nyse',
      label: 'BP (NYSE ADR)',
      value: '$34.82 USD',
      change: '+0.88%',
      isPositive: true,
      icon: <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
    },
    {
      id: 'renewables',
      label: 'Renewable Power Pipeline',
      value: '14.2 GW',
      change: '+2.1 GW YoY',
      isPositive: true,
      icon: <Wind className="w-3.5 h-3.5 text-emerald-400" />
    },
    {
      id: 'pulse',
      label: 'bp pulse Ultra-Fast Sockets',
      value: '39,420 Active',
      change: '+620 This Mo.',
      isPositive: true,
      icon: <Zap className="w-3.5 h-3.5 text-yellow-400" />
    },
    {
      id: 'fleet',
      label: 'Active Maritime Fleet',
      value: '84 Vessels Live',
      change: '100% AIS Synced',
      isPositive: true,
      icon: <Ship className="w-3.5 h-3.5 text-cyan-400" />
    },
    {
      id: 'carbon',
      label: 'Operational GHG Intensity',
      value: '-31.4% vs 2019',
      change: 'On Track 2030',
      isPositive: true,
      icon: <Leaf className="w-3.5 h-3.5 text-emerald-400" />
    },
    {
      id: 'crude',
      label: 'Brent Energy Benchmark',
      value: '$78.40 / bbl',
      change: '-0.35%',
      isPositive: false,
      icon: <Activity className="w-3.5 h-3.5 text-slate-400" />
    }
  ]);

  // Subtle live numerical updates
  useEffect(() => {
    const interval = setInterval(() => {
      setItems((prev) =>
        prev.map((item) => {
          if (item.id === 'pulse') {
            const current = parseInt(item.value.replace(/[^0-9]/g, ''), 10);
            return {
              ...item,
              value: `${(current + Math.floor(Math.random() * 3)).toLocaleString()} Active`,
            };
          }
          return item;
        })
      );
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-[#060D13] border-y border-emerald-950/60 overflow-hidden py-2.5 select-none relative z-20">
      <div className="flex items-center">
        {/* Ticker Lead Tag */}
        <div className="hidden md:flex items-center gap-2 pl-6 pr-4 border-r border-emerald-900/40 shrink-0 bg-[#060D13] z-10">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[11px] font-mono-tech uppercase tracking-wider text-emerald-400 font-bold">
            Live Global Telemetry
          </span>
        </div>

        {/* Scrolling Ticker Stream */}
        <div className="flex items-center space-x-8 animate-[marquee_40s_linear_infinite] whitespace-nowrap px-4 hover:[animation-play-state:paused]">
          {[...items, ...items].map((item, index) => (
            <div
              key={`${item.id}-${index}`}
              className="inline-flex items-center gap-2.5 px-3 py-1 rounded-lg bg-slate-900/40 border border-slate-800/60 text-xs font-mono-tech"
            >
              <span className="text-slate-400">{item.icon}</span>
              <span className="text-slate-300 font-medium">{item.label}:</span>
              <span className="text-white font-bold">{item.value}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                  item.isPositive
                    ? 'text-emerald-400 bg-emerald-950/50'
                    : 'text-slate-400 bg-slate-800/40'
                }`}
              >
                {item.change}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
