'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Zap, 
  BatteryCharging, 
  Clock, 
  Car, 
  Leaf, 
  ShieldCheck, 
  Coffee, 
  Smartphone, 
  Sparkles,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';

interface EVVehicle {
  id: string;
  name: string;
  batteryKwh: number;
  maxChargeKw: number;
  rangeMiles: number;
}

const EV_MODELS: EVVehicle[] = [
  { id: 'taycan', name: 'Porsche Taycan / Audi e-tron GT', batteryKwh: 93, maxChargeKw: 320, rangeMiles: 310 },
  { id: 'ioniq', name: 'Hyundai Ioniq 6 / Kia EV6', batteryKwh: 77.4, maxChargeKw: 240, rangeMiles: 338 },
  { id: 'model-y', name: 'Tesla Model Y Long Range', batteryKwh: 78, maxChargeKw: 250, rangeMiles: 330 },
  { id: 'f150', name: 'Ford F-150 Lightning Extended', batteryKwh: 131, maxChargeKw: 180, rangeMiles: 320 },
  { id: 'bmw', name: 'BMW i4 eDrive40', batteryKwh: 83.9, maxChargeKw: 205, rangeMiles: 301 },
];

export function BPPulseExperience() {
  const [selectedVehicle, setSelectedVehicle] = useState<EVVehicle>(EV_MODELS[0]);
  const [targetPercentage, setTargetPercentage] = useState<number>(80);
  const startingPercentage = 15;

  // Calculate charge duration on bp pulse 350kW vs standard 50kW
  const percentageToCharge = Math.max(0, targetPercentage - startingPercentage);
  const energyNeededKwh = (selectedVehicle.batteryKwh * percentageToCharge) / 100;
  
  // Average effective charging speed factoring in 800V vs 400V curves
  const effectiveBpPulseKw = Math.min(350, selectedVehicle.maxChargeKw) * 0.78;
  const bpPulseTimeMinutes = Math.max(8, Math.round((energyNeededKwh / effectiveBpPulseKw) * 60));
  
  const standard50KwTimeMinutes = Math.round((energyNeededKwh / 45) * 60);
  const milesAdded = Math.round((percentageToCharge / 100) * selectedVehicle.rangeMiles);

  return (
    <section id="pulse" className="py-24 bg-[#060C11] relative overflow-hidden border-t border-emerald-950/60">
      
      {/* Background glowing gradients */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-yellow-500/10 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-emerald-600/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-tech uppercase tracking-widest text-yellow-400 font-bold mb-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span>Next-Generation EV Mobility</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display text-white">
              bp pulse Ultra-Fast Network
            </h2>
          </div>
          <p className="max-w-lg text-slate-300 text-sm sm:text-base leading-relaxed">
            Delivering up to 350kW liquid-cooled charging across major transport corridors, backed by 100% certified renewable energy and seamless digital plug & charge.
          </p>
        </div>

        {/* Interactive 350kW Charging Simulator & Feature Matrix */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Interactive EV Speed Calculator */}
          <div className="lg:col-span-7 bp-glass-glow rounded-3xl p-6 sm:p-8 border border-emerald-900/50">
            <div className="flex items-center justify-between pb-4 border-b border-emerald-900/40 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-yellow-400/20 text-yellow-400 border border-yellow-400/30">
                  <BatteryCharging className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold font-display text-white">
                    350kW Charging Speed Modeler
                  </h3>
                  <p className="text-xs text-slate-400">
                    Compare ultra-fast bp pulse vs legacy infrastructure
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-mono-tech px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                100% Clean Power
              </span>
            </div>

            {/* Select EV Model */}
            <div className="mb-6">
              <label className="block text-xs font-mono-tech uppercase text-slate-300 tracking-wider mb-2 font-semibold">
                Select Your Electric Vehicle:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {EV_MODELS.map((ev) => {
                  const isSel = ev.id === selectedVehicle.id;
                  return (
                    <button
                      key={ev.id}
                      onClick={() => setSelectedVehicle(ev)}
                      className={`text-left p-3 rounded-xl border text-xs transition-all ${
                        isSel
                          ? 'bg-emerald-950/80 border-emerald-500 text-white font-semibold shadow-md'
                          : 'bg-black/40 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <div className="truncate font-medium">{ev.name}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5 font-mono-tech">
                        {ev.batteryKwh} kWh • Max {ev.maxChargeKw} kW
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Range Slider for Target Charge */}
            <div className="mb-8 bg-black/40 p-4 rounded-2xl border border-slate-800">
              <div className="flex items-center justify-between text-xs font-mono-tech mb-2">
                <span className="text-slate-400">Target State of Charge:</span>
                <span className="text-yellow-400 font-bold text-sm">
                  {startingPercentage}% ➔ {targetPercentage}%
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="95"
                step="5"
                value={targetPercentage}
                onChange={(e) => setTargetPercentage(parseInt(e.target.value, 10))}
                className="w-full accent-[#008751] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono-tech text-slate-500 mt-1">
                <span>Quick Top-up (50%)</span>
                <span>Optimal Road Trip (80%)</span>
                <span>Full (95%)</span>
              </div>
            </div>

            {/* Calculation Comparison Outcome */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* bp pulse 350kW Result */}
              <div className="p-5 rounded-2xl bg-gradient-to-b from-emerald-950/80 to-slate-900 border-2 border-emerald-500/80 shadow-xl shadow-emerald-950/50 relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-yellow-400 text-black text-[10px] font-bold font-mono-tech px-2.5 py-0.5 rounded-bl-lg">
                  BP PULSE 350kW
                </div>
                <div className="text-xs text-emerald-300 font-mono-tech uppercase mb-1">
                  Estimated Charge Time
                </div>
                <div className="text-3xl sm:text-4xl font-black font-mono-tech text-white mb-2">
                  ~{bpPulseTimeMinutes} <span className="text-sm font-normal text-slate-400">mins</span>
                </div>
                <div className="text-xs text-slate-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Adds <strong>+{milesAdded} miles</strong> of pure electric range</span>
                </div>
              </div>

              {/* Standard 50kW Result */}
              <div className="p-5 rounded-2xl bg-black/40 border border-slate-800 text-slate-400">
                <div className="text-xs font-mono-tech uppercase mb-1 text-slate-500">
                  Legacy 50kW Public Charger
                </div>
                <div className="text-2xl sm:text-3xl font-bold font-mono-tech text-slate-400 mb-2">
                  ~{standard50KwTimeMinutes} <span className="text-sm font-normal">mins</span>
                </div>
                <div className="text-xs text-slate-500">
                  Saves ~{Math.max(0, standard50KwTimeMinutes - bpPulseTimeMinutes)} minutes at bp pulse
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Key Infrastructure Capabilities */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Visual Photo Card */}
            <div className="relative h-56 rounded-3xl overflow-hidden border border-yellow-500/30">
              <img
                src="/images/bp_pulse_hub.jpg"
                alt="bp pulse Ultra-Fast Hub"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="text-xs font-mono-tech text-yellow-300 uppercase tracking-wider mb-0.5">
                  European & US Corridors
                </div>
                <div className="text-base font-bold font-display text-white">
                  Convenience & Ultra-Fast Mobility Hubs
                </div>
              </div>
            </div>

            {/* Benefit Features List */}
            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-900 shrink-0">
                  <Leaf className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">100% Certified Green Power</div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    All electricity supplied across bp pulse UK and European public charging points is backed by renewable energy guarantee certificates.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-yellow-950 text-yellow-400 border border-yellow-900 shrink-0">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">Autocharge & Contactless Tap</div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Plug and charge capability identifies your vehicle automatically—no RFID cards or manual app start required.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-900 shrink-0">
                  <Coffee className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-sm text-white">Wild Bean Cafe & Modern Forecourts</div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Grab barista coffee, fresh bakery items, and high-speed Wi-Fi in clean, secure lounge areas while your vehicle powers up.
                  </p>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
