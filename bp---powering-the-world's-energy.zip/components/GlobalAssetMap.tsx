'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Ship, 
  Wind, 
  Zap, 
  Flame, 
  Sun, 
  Compass, 
  Radio, 
  Activity, 
  ShieldCheck, 
  Layers, 
  ChevronRight,
  Filter
} from 'lucide-react';

interface AssetMarker {
  id: string;
  name: string;
  type: 'fleet' | 'wind' | 'solar' | 'hydrogen' | 'pulse';
  region: string;
  lat: number; // For map positioning
  lng: number;
  status: string;
  speedOrOutput: string;
  coordinates: string;
  detail: string;
  cargoOrCapacity: string;
}

const GLOBAL_ASSETS: AssetMarker[] = [
  {
    id: 'ocean-titan',
    name: 'Ocean Titan (Supertanker)',
    type: 'fleet',
    region: 'Mid-Atlantic Transit',
    lat: 32,
    lng: 32,
    status: 'OPTIMAL TRANSIT • ROTTERDAM GATEWAY',
    speedOrOutput: '18.4 kts Cruise',
    coordinates: "24° 18' N, 068° 54' W",
    detail: 'Next-gen dual-fuel LNG/bio-blend marine propulsion carrier with micro-air hull lubrication.',
    cargoOrCapacity: '72,400 DWT Cryogenic Transit'
  },
  {
    id: 'british-achiever',
    name: 'British Achiever (LNG Carrier)',
    type: 'fleet',
    region: 'Strait of Malacca / Asia',
    lat: 56,
    lng: 78,
    status: 'INBOUND SINGAPORE ENERGY TERMINAL',
    speedOrOutput: '19.1 kts Cruise',
    coordinates: "01° 15' N, 103° 50' E",
    detail: 'High-efficiency M-type Electronically Controlled Gas Injection (ME-GI) containment carrier.',
    cargoOrCapacity: '174,000 m³ Clean LNG'
  },
  {
    id: 'argos-deepwater',
    name: 'Argos Deepwater Semi-Submersible',
    type: 'fleet',
    region: 'Gulf of Mexico, USA',
    lat: 44,
    lng: 22,
    status: 'ACTIVE PRODUCTION • ZERO FLARING',
    speedOrOutput: '140,000 bpd Capacity',
    coordinates: "27° 30' N, 090° 15' W",
    detail: 'BP’s newest semi-submersible platform equipped with water-injection and electrified subsea pumps.',
    cargoOrCapacity: 'Greenfield Deepwater Asset'
  },
  {
    id: 'dogger-bank-wind',
    name: 'Dogger Bank Offshore Wind Array',
    type: 'wind',
    region: 'North Sea, United Kingdom',
    lat: 28,
    lng: 48,
    status: 'FULL GENERATION • 525kV HVDC',
    speedOrOutput: '3.6 GW Array Peak',
    coordinates: "54° 45' N, 001° 55' E",
    detail: 'World’s flagship offshore wind farm powering over 6 million UK homes via subsea DC interconnectors.',
    cargoOrCapacity: '277 Giant Turbines'
  },
  {
    id: 'morgan-mona-wind',
    name: 'Morgan & Mona Offshore Wind Project',
    type: 'wind',
    region: 'Irish Sea, UK',
    lat: 31,
    lng: 46,
    status: 'EXPANSION PHASE',
    speedOrOutput: '3.0 GW Potential',
    coordinates: "53° 50' N, 004° 10' W",
    detail: 'Fixed-bottom offshore wind development with high local economic supply chain content.',
    cargoOrCapacity: 'Joint Venture 50/50'
  },
  {
    id: 'lightsource-australia',
    name: 'Wellington North Solar Farm',
    type: 'solar',
    region: 'New South Wales, Australia',
    lat: 72,
    lng: 88,
    status: 'GRID CONNECTED • 425 MWdc',
    speedOrOutput: '425 MWdc Peak',
    coordinates: "32° 33' S, 148° 56' E",
    detail: 'Lightsource bp utility-scale solar farm integrated with 50MW/100MWh battery energy storage.',
    cargoOrCapacity: '1.2M Bifacial Panels'
  },
  {
    id: 'hygreen-teesside',
    name: 'HyGreen Teesside Hydrogen Hub',
    type: 'hydrogen',
    region: 'North East England, UK',
    lat: 29,
    lng: 49,
    status: 'ELECTROLYSER COMMISSIONING',
    speedOrOutput: '500 MWe Capacity',
    coordinates: "54° 35' N, 001° 13' W",
    detail: 'Green hydrogen production facility supplying decarbonized fuel for heavy transport and chemical synthesis.',
    cargoOrCapacity: '0.15 Mt/Yr Clean H₂'
  },
  {
    id: 'london-pulse-gigahub',
    name: 'London Heathrow bp pulse Gigahub',
    type: 'pulse',
    region: 'Greater London, UK',
    lat: 33,
    lng: 48,
    status: '100% OPERATIONAL • 36 ULTRA-FAST BAYS',
    speedOrOutput: '350 kW Liquid-Cooled',
    coordinates: "51° 28' N, 000° 27' W",
    detail: 'Ultra-fast public and fleet EV charging hub featuring Wild Bean modern convenience cafe.',
    cargoOrCapacity: '100% Green Certified Power'
  },
  {
    id: 'us-ta-corridor-hub',
    name: 'TravelCenters of America Fast Corridor',
    type: 'pulse',
    region: 'Interstate 80 / Midwest USA',
    lat: 38,
    lng: 24,
    status: 'LIVE NETWORK EXPANSION',
    speedOrOutput: '300-350 kW CCS & NACS',
    coordinates: "41° 30' N, 087° 30' W",
    detail: 'Coast-to-coast high power charging corridor for passenger EVs and medium-duty commercial fleets.',
    cargoOrCapacity: 'Multi-Bay Mega Stations'
  }
];

export function GlobalAssetMap() {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'fleet' | 'wind' | 'solar' | 'hydrogen' | 'pulse'>('all');
  const [activeAsset, setActiveAsset] = useState<AssetMarker | null>(GLOBAL_ASSETS[0]);

  const filteredAssets = selectedFilter === 'all'
    ? GLOBAL_ASSETS
    : GLOBAL_ASSETS.filter((a) => a.type === selectedFilter);

  const getAssetIcon = (type: AssetMarker['type']) => {
    switch (type) {
      case 'fleet': return <Ship className="w-4 h-4 text-cyan-400" />;
      case 'wind': return <Wind className="w-4 h-4 text-emerald-300" />;
      case 'solar': return <Sun className="w-4 h-4 text-yellow-400" />;
      case 'hydrogen': return <Flame className="w-4 h-4 text-emerald-400" />;
      case 'pulse': return <Zap className="w-4 h-4 text-yellow-300" />;
    }
  };

  const getAssetColor = (type: AssetMarker['type']) => {
    switch (type) {
      case 'fleet': return 'bg-cyan-400';
      case 'wind': return 'bg-emerald-400';
      case 'solar': return 'bg-yellow-400';
      case 'hydrogen': return 'bg-emerald-500';
      case 'pulse': return 'bg-yellow-300';
    }
  };

  return (
    <section id="fleet" className="py-24 bg-[#050A0E] relative border-t border-emerald-950/60 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header and Filter Controls */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-tech uppercase tracking-widest text-emerald-400 font-bold mb-2">
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>Real-Time Operations Radar</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white">
              Global Fleet & Asset Telemetry
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setSelectedFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono-tech transition-colors ${
                selectedFilter === 'all'
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Assets ({GLOBAL_ASSETS.length})
            </button>
            <button
              onClick={() => setSelectedFilter('fleet')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono-tech transition-colors ${
                selectedFilter === 'fleet'
                  ? 'bg-cyan-700 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Ship className="w-3.5 h-3.5 text-cyan-400" />
              <span>Fleet & Platforms</span>
            </button>
            <button
              onClick={() => setSelectedFilter('wind')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono-tech transition-colors ${
                selectedFilter === 'wind'
                  ? 'bg-emerald-700 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Wind className="w-3.5 h-3.5 text-emerald-300" />
              <span>Offshore Wind</span>
            </button>
            <button
              onClick={() => setSelectedFilter('pulse')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono-tech transition-colors ${
                selectedFilter === 'pulse'
                  ? 'bg-yellow-700 text-white font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-yellow-300" />
              <span>bp pulse</span>
            </button>
          </div>
        </div>

        {/* Interactive World Radar Map & Selected Asset Detail */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Main Map Visualizer Box */}
          <div className="lg:col-span-8 bg-[#09131C] rounded-3xl p-4 sm:p-6 border border-emerald-950/80 relative overflow-hidden min-h-[440px] sm:min-h-[500px] flex flex-col justify-between shadow-2xl">
            
            {/* Map Background Grid & Radar Sweep */}
            <div className="absolute inset-0 bg-[radial-gradient(#152d3a_1px,transparent_1px)] [background-size:24px_24px] opacity-35" />
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#0087510d_1px,transparent_1px),linear-gradient(to_bottom,#0087510d_1px,transparent_1px)] bg-[size:4rem_4rem]" />
            
            {/* Compass rose & metadata overlay */}
            <div className="relative z-10 flex items-center justify-between text-xs font-mono-tech text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-emerald-400 font-bold">AIS & SCADA FEED: ACTIVE</span>
              </div>
              <div>COORDINATE PROJECTION: MERCATOR WGS84</div>
            </div>

            {/* Stylized Vector World Map Silhouettes & Asset Pins */}
            <div className="relative z-10 w-full my-auto h-72 sm:h-96">
              
              {/* World Outline Visual Canvas Representation */}
              <svg
                viewBox="0 0 100 60"
                className="w-full h-full opacity-35 text-emerald-950/90 fill-current stroke-emerald-800/40"
              >
                {/* Americas */}
                <path d="M 12 14 Q 18 10 24 16 Q 28 26 22 36 Q 25 44 26 52 Q 22 56 19 46 Q 16 38 12 30 Z" />
                {/* Europe & Africa */}
                <path d="M 44 12 Q 52 10 54 18 Q 50 26 56 36 Q 54 52 48 50 Q 42 36 44 24 Z" />
                {/* Asia & Australia */}
                <path d="M 64 10 Q 82 8 88 22 Q 86 34 76 38 Q 78 52 86 54 Q 92 48 88 40 Z" />
              </svg>

              {/* Asset Markers on the Map */}
              {filteredAssets.map((asset) => {
                const isSelected = activeAsset?.id === asset.id;
                return (
                  <button
                    key={asset.id}
                    onClick={() => setActiveAsset(asset)}
                    style={{ left: `${asset.lng}%`, top: `${asset.lat}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
                  >
                    {/* Glowing outer pulse */}
                    <span className={`absolute -inset-2 rounded-full opacity-75 animate-ping ${getAssetColor(asset.type)}`} />
                    
                    {/* Inner pin button */}
                    <div className={`relative p-2 rounded-full border-2 transition-all duration-300 shadow-xl ${
                      isSelected
                        ? 'bg-white border-yellow-400 scale-125 shadow-yellow-500/50'
                        : 'bg-[#0B1A24] border-emerald-400 group-hover:scale-110'
                    }`}>
                      {getAssetIcon(asset.type)}
                    </div>

                    {/* Marker label tooltip */}
                    <div className={`absolute top-full left-1/2 -translate-x-1/2 mt-1.5 px-2 py-0.5 rounded bg-black/90 backdrop-blur-md border border-slate-700 text-[10px] font-mono-tech whitespace-nowrap shadow-xl transition-all ${
                      isSelected ? 'text-yellow-300 border-yellow-500/60 font-bold' : 'text-slate-300 opacity-0 group-hover:opacity-100'
                    }`}>
                      {asset.name.split('(')[0]}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Bottom Radar Status */}
            <div className="relative z-10 flex flex-wrap items-center justify-between text-[11px] font-mono-tech text-slate-400 pt-2 border-t border-slate-800">
              <div className="flex items-center gap-4">
                <span className="text-slate-200 font-medium">Tracking {filteredAssets.length} active units</span>
                <span className="text-emerald-400 font-semibold">• High-Frequency Telemetry</span>
              </div>
              <div className="text-slate-500">Latency: 14ms Global AIS</div>
            </div>

          </div>

          {/* Selected Asset Inspection Card */}
          <div className="lg:col-span-4 flex flex-col justify-between">
            {activeAsset ? (
              <motion.div
                key={activeAsset.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4 }}
                className="bp-glass-glow rounded-3xl p-6 sm:p-7 border border-emerald-800/50 h-full flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-emerald-900/40 mb-4">
                    <span className="text-xs font-mono-tech text-emerald-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                      {getAssetIcon(activeAsset.type)}
                      {activeAsset.region}
                    </span>
                    <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-emerald-950/80 text-yellow-400 border border-emerald-700/50">
                      LIVE SCADA
                    </span>
                  </div>

                  <h3 className="text-xl font-bold font-display text-white mb-1.5">
                    {activeAsset.name}
                  </h3>

                  <div className="text-xs font-mono-tech text-emerald-400 mb-4 flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5" />
                    <span>{activeAsset.coordinates}</span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed mb-6">
                    {activeAsset.detail}
                  </p>

                  {/* Telemetry Metric Boxes */}
                  <div className="space-y-3 mb-6">
                    <div className="p-3 rounded-xl bg-black/50 border border-slate-800 flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-mono-tech">Operational Output / Speed</span>
                      <span className="text-xs font-bold font-mono-tech text-white">{activeAsset.speedOrOutput}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-black/50 border border-slate-800 flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-mono-tech">Capacity / Scale</span>
                      <span className="text-xs font-bold font-mono-tech text-emerald-400">{activeAsset.cargoOrCapacity}</span>
                    </div>
                    <div className="p-3 rounded-xl bg-black/50 border border-slate-800 flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-mono-tech">Mission Status</span>
                      <span className="text-[11px] font-bold font-mono-tech text-yellow-300 truncate max-w-[170px]">{activeAsset.status}</span>
                    </div>
                  </div>
                </div>

                <a
                  href="#hero"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 transition-all"
                >
                  <span>View Cinematic Telemetry</span>
                  <ChevronRight className="w-4 h-4" />
                </a>
              </motion.div>
            ) : (
              <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 text-center text-slate-400 text-sm">
                Select an asset from the radar map to view live specifications.
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
