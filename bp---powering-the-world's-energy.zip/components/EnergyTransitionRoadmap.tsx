'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, 
  Zap, 
  Wind, 
  Flame, 
  Ship, 
  Cpu, 
  ArrowRight, 
  CheckCircle2, 
  Layers, 
  BarChart, 
  Sparkles,
  Compass,
  Globe2,
  Anchor
} from 'lucide-react';

interface Pillar {
  id: string;
  number: string;
  title: string;
  tagline: string;
  icon: React.ReactNode;
  accentColor: string;
  summary: string;
  highlights: string[];
  metrics: { label: string; val: string }[];
  projects: { name: string; region: string; status: string }[];
  imageUrl: string;
}

const PILLARS: Pillar[] = [
  {
    id: 'hydrocarbons',
    number: '01',
    title: 'Resilient Hydrocarbons & Fleet Logistics',
    tagline: 'Delivering secure, safer energy with declining operational intensity',
    icon: <Ship className="w-6 h-6 text-emerald-400" />,
    accentColor: 'from-emerald-500/20 to-emerald-700/10',
    summary: 'We continue investing in high-margin, lower-emission oil and gas projects to meet current world energy demand while funding our low-carbon future. Our world-class shipping fleet (including vessels like Ocean Titan) leverages dual-fuel propulsion and AI voyage routing.',
    highlights: [
      'Over 80 modern dual-fuel LNG and crude carriers in active global rotation',
      'Continuous methane optical monitoring across 100% of major production assets',
      'Subsea electrification and zero-routine flaring across deepwater hubs',
      'AI-enhanced predictive maintenance reducing unplanned downtime by 40%'
    ],
    metrics: [
      { label: 'Fleet Reliability Index', val: '99.4%' },
      { label: 'Methane Intensity', val: '< 0.12%' },
      { label: 'Global Barrel Equity', val: '2.3 Mboe/d' }
    ],
    projects: [
      { name: 'Ocean Titan & Mariner Series', region: 'Atlantic & Pacific Transits', status: 'Active Service' },
      { name: 'Argos Deepwater Platform', region: 'Gulf of Mexico', status: 'Full Production' },
      { name: 'Murlach & Seagull Fields', region: 'Central North Sea', status: 'Connected Tie-Back' }
    ],
    imageUrl: '/images/bp_ocean_tanker.jpg'
  },
  {
    id: 'mobility',
    number: '02',
    title: 'Convenience & bp pulse EV Mobility',
    tagline: 'Scaling ultra-fast on-the-go charging and modern customer hubs',
    icon: <Zap className="w-6 h-6 text-yellow-400" />,
    accentColor: 'from-yellow-500/20 to-emerald-600/10',
    summary: 'bp pulse is leading the global rollout of ultra-fast 150kW–350kW EV charging hubs along major highway corridors and metropolitan centers, paired with world-class convenience retail and Castrol ON EV fluids.',
    highlights: [
      '39,000+ ultra-fast charging charge points operational across Europe, US, and Asia',
      '10-minute 100-mile range delivery on high-power 350kW liquid-cooled dispensers',
      '100% certified renewable electricity supplied to all bp pulse public stations',
      'Fleet depots electrification partnerships with global logistics providers'
    ],
    metrics: [
      { label: 'Network Availability', val: '99.1%' },
      { label: 'Peak Charging Power', val: '350 kW' },
      { label: 'Retail Forecourts', val: '21,000+' }
    ],
    projects: [
      { name: 'London Heathrow Gigahub', region: 'United Kingdom', status: '36 Ultra-Fast Bays' },
      { name: 'TravelCenters of America Fast Hubs', region: 'United States', status: 'Major Corridor Rollout' },
      { name: 'Aral pulse Network', region: 'Germany & Benelux', status: 'Leading Operator' }
    ],
    imageUrl: '/images/bp_pulse_hub.jpg'
  },
  {
    id: 'renewables',
    number: '03',
    title: 'Low Carbon Energy, Wind & Hydrogen',
    tagline: 'Building a multi-gigawatt renewable and clean molecules portfolio',
    icon: <Wind className="w-6 h-6 text-emerald-300" />,
    accentColor: 'from-emerald-400/20 to-teal-700/10',
    summary: 'Transforming industrial clusters through green hydrogen, carbon capture and storage (CCUS), and multi-gigawatt offshore wind farms in the UK, Europe, and US East Coast.',
    highlights: [
      '14+ GW renewable pipeline across offshore wind, onshore wind, and utility solar',
      'Anchor partner in the UK Northern Endurance Partnership & Net Zero Teesside',
      'HyGreen and H2Teesside green and blue hydrogen production plants',
      'Biofuels expansion: Sustainable Aviation Fuel (SAF) and renewable diesel'
    ],
    metrics: [
      { label: 'Renewable Power Pipeline', val: '14.2 GW' },
      { label: 'Annual CO₂ Storage Goal', val: '10+ Mt/yr' },
      { label: 'Hydrogen Target 2030', val: '0.7 Mt/yr' }
    ],
    projects: [
      { name: 'Dogger Bank Offshore Wind Array', region: 'North Sea, UK', status: '3.6 GW Mega-Project' },
      { name: 'Net Zero Teesside CCUS', region: 'Teesside, UK', status: 'Construction Phase' },
      { name: 'Lightsource bp Solar Portfolio', region: 'Global (19 Countries)', status: 'Active Expansion' }
    ],
    imageUrl: '/images/bp_offshore_wind.jpg'
  }
];

export function EnergyTransitionRoadmap() {
  const [activePillarId, setActivePillarId] = useState('hydrocarbons');
  const activePillar = PILLARS.find((p) => p.id === activePillarId) || PILLARS[0];

  return (
    <section id="strategy" className="py-24 bg-[#070D12] relative overflow-hidden">
      {/* Background radial accent */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-emerald-950/20 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2.5 text-xs font-mono-tech uppercase tracking-widest text-emerald-400 mb-2 font-bold">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span>Strategy 2026 & Beyond</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display tracking-tight text-white">
              An Integrated Energy Company
            </h2>
          </div>
          <p className="max-w-xl text-slate-300 text-sm sm:text-base leading-relaxed">
            bp is delivering the energy the world needs today while scaling the low-carbon energy systems of tomorrow through three distinct and synergistic strategic pillars.
          </p>
        </div>

        {/* 3 Pillar Selector Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          {PILLARS.map((pillar) => {
            const isSelected = pillar.id === activePillarId;
            return (
              <button
                key={pillar.id}
                onClick={() => setActivePillarId(pillar.id)}
                className={`text-left p-6 rounded-2xl transition-all duration-300 relative overflow-hidden ${
                  isSelected
                    ? 'bg-slate-900/90 border border-emerald-500/60 shadow-2xl shadow-emerald-950/40'
                    : 'bg-slate-900/40 hover:bg-slate-900/60 border border-slate-800 text-slate-400'
                }`}
              >
                {isSelected && (
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-400 via-yellow-400 to-emerald-600" />
                )}
                
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-mono-tech font-bold text-slate-500 tracking-wider">
                    {pillar.number}
                  </span>
                  <div className={`p-2 rounded-xl ${isSelected ? 'bg-emerald-950/80 border border-emerald-500/40' : 'bg-slate-800/40'}`}>
                    {pillar.icon}
                  </div>
                </div>

                <h3 className={`text-lg font-bold font-display mb-1 ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                  {pillar.title}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2">
                  {pillar.tagline}
                </p>
              </button>
            );
          })}
        </div>

        {/* Active Pillar Detailed Showcase Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activePillar.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="bp-glass rounded-3xl p-6 sm:p-10 border border-slate-700/60 overflow-hidden"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* Left Column: Context, Highlights & Real-world Projects */}
              <div className="lg:col-span-7 space-y-6">
                <div>
                  <div className="text-xs font-mono-tech uppercase tracking-widest text-emerald-400 font-bold mb-1">
                    Pillar {activePillar.number} Focus
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-bold font-display text-white mb-3">
                    {activePillar.title}
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {activePillar.summary}
                  </p>
                </div>

                {/* Key Highlights Checklist */}
                <div className="space-y-2.5">
                  <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">
                    Strategic Execution Capabilities:
                  </div>
                  {activePillar.highlights.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-200">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                {/* Real-world Projects Grid */}
                <div>
                  <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-2.5">
                    Flagship Assets & Initiatives:
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {activePillar.projects.map((proj, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-black/40 border border-slate-800">
                        <div className="font-bold text-xs text-white mb-0.5 truncate">{proj.name}</div>
                        <div className="text-[11px] text-slate-400 truncate">{proj.region}</div>
                        <div className="mt-1.5 inline-block text-[10px] font-mono-tech px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-900/50">
                          {proj.status}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Visual Preview & Numerical Metrics */}
              <div className="lg:col-span-5 flex flex-col gap-5">
                {/* Visual Imagery Box */}
                <div className="relative h-64 sm:h-72 rounded-2xl overflow-hidden border border-emerald-900/40 group">
                  <img
                    src={activePillar.imageUrl}
                    alt={activePillar.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs font-mono-tech text-slate-200">
                    <span className="px-2.5 py-1 rounded bg-black/60 backdrop-blur-md border border-white/10 text-emerald-400 font-bold">
                      {activePillar.title.split('&')[0]}
                    </span>
                    <span className="text-[11px] text-slate-300">Late 2026 Asset View</span>
                  </div>
                </div>

                {/* Metrics 3-Col Bar */}
                <div className="grid grid-cols-3 gap-3 bg-black/50 p-4 rounded-2xl border border-slate-800">
                  {activePillar.metrics.map((m, idx) => (
                    <div key={idx} className="text-center">
                      <div className="text-lg sm:text-xl font-bold font-mono-tech text-emerald-400">
                        {m.val}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5 leading-tight">
                        {m.label}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </motion.div>
        </AnimatePresence>

      </div>
    </section>
  );
}
