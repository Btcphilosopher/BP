'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HeliosLogo } from './HeliosLogo';
import { bpAmbience } from '../lib/audioAmbience';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Compass, 
  Radio, 
  Maximize2, 
  Minimize2, 
  Wind, 
  Zap, 
  Flame, 
  Ship, 
  Layers, 
  Activity, 
  Eye, 
  Info, 
  ShieldCheck, 
  ArrowRight,
  ChevronRight,
  Sliders,
  Sparkles
} from 'lucide-react';

interface Hotspot {
  id: string;
  x: number; // percentage
  y: number; // percentage
  title: string;
  tag: string;
  description: string;
  metric: string;
  metricLabel: string;
}

interface HeroScene {
  id: string;
  title: string;
  subtitle: string;
  tagline: string;
  category: string;
  image: string;
  coordinates: string;
  speed: string;
  powerOutput: string;
  efficiency: string;
  carbonOffset: string;
  status: string;
  hotspots: Hotspot[];
}

const HERO_SCENES: HeroScene[] = [
  {
    id: 'ocean-titan',
    title: 'OCEAN TITAN',
    subtitle: 'ATLANTIC TRANSIT   /   BP FLEET',
    tagline: 'ENERGY TODAY. A BRIGHTER TOMORROW.',
    category: 'Marine Logistics & LNG Transit',
    image: '/images/bp_ocean_tanker.jpg',
    coordinates: "24° 18' N  •  068° 54' W",
    speed: '18.4 kts',
    powerOutput: '72,400 DWT Cargo Cap',
    efficiency: '96.4% Dual-Fuel Eff.',
    carbonOffset: '-34% Maritime CO₂e',
    status: 'OPTIMAL TRANSIT • ROTTERDAM BOUND',
    hotspots: [
      {
        id: 'propulsion',
        x: 82,
        y: 68,
        title: 'Dual-Fuel LNG & Bio-Blend Propulsion',
        tag: 'PROPULSION MATRIX',
        description: 'Next-gen dual-fuel low-pressure marine engine capable of transitioning seamlessly between Bio-LNG and ultra-low sulfur distillates.',
        metric: '34% Lower GHG',
        metricLabel: 'Emissions Delta vs 2020 Baseline'
      },
      {
        id: 'hull',
        x: 34,
        y: 62,
        title: 'Micro-Air Lubrication Hull System',
        tag: 'HYDRODYNAMICS',
        description: 'Generates a continuous micro-bubble layer along the ship bottom, slashing skin friction resistance and fuel consumption during trans-oceanic passage.',
        metric: '7.8% Fuel Cut',
        metricLabel: 'Drag Reduction Efficiency'
      },
      {
        id: 'telemetry',
        x: 48,
        y: 45,
        title: 'AI Smart Voyage Routing Radar',
        tag: 'AVENIR SATELLITE HUD',
        description: 'Real-time oceanic weather routing predicting wave resistance, sea state swells, and thermal ocean currents for minimal carbon intensity.',
        metric: '18.4 Kts',
        metricLabel: 'Optimal Cruise Velocity'
      },
      {
        id: 'bridge',
        x: 77,
        y: 28,
        title: 'Automated Emission Monitoring Bridge',
        tag: 'DIGITAL OPERATIONS',
        description: 'Continuous optical and sensor-driven stack emissions reporting directly tied to BP global carbon accounting ledgers.',
        metric: '99.9% Real-time',
        metricLabel: 'Compliance Telemetry'
      }
    ]
  },
  {
    id: 'dogger-bank',
    title: 'DOGGER BANK MATRIX',
    subtitle: 'NORTH SEA ARRAY   /   BP OFFSHORE WIND',
    tagline: 'ENERGY TODAY. A BRIGHTER TOMORROW.',
    category: 'Offshore Renewable Power',
    image: '/images/bp_offshore_wind.jpg',
    coordinates: "54° 45' N  •  001° 55' E",
    speed: '12.8 m/s Wind',
    powerOutput: '3.6 GW Rated Array',
    efficiency: '98.2% Grid Availability',
    carbonOffset: '-4.8M T/Yr CO₂e',
    status: 'ACTIVE GENERATION • UK NATIONAL GRID',
    hotspots: [
      {
        id: 'turbine',
        x: 42,
        y: 35,
        title: '260m Direct-Drive Rotor Nacelle',
        tag: 'TURBINE ARCHITECTURE',
        description: 'Ultra-high efficiency permanent magnet generator converting cold North Sea gales directly into high-voltage direct current (HVDC).',
        metric: '15 MW / unit',
        metricLabel: 'Peak Generator Output'
      },
      {
        id: 'grid',
        x: 65,
        y: 60,
        title: 'Offshore HVDC Converter Platform',
        tag: 'TRANSMISSION',
        description: 'Step-up substation with ultra-low transmission loss connecting power directly to 6 million UK households.',
        metric: '525 kV HVDC',
        metricLabel: 'Transmission Voltage'
      },
      {
        id: 'vessel',
        x: 80,
        y: 75,
        title: 'Hybrid-Electric Service Operation Vessel',
        tag: 'ZERO-EMISSION LOGISTICS',
        description: 'Offshore maintenance vessel equipped with high-capacity battery bank for 100% electric zero-emission dynamic positioning.',
        metric: '0 Direct CO₂',
        metricLabel: 'In-Field Station Keeping'
      }
    ]
  },
  {
    id: 'bp-pulse-hub',
    title: 'BP PULSE ULTRAHUB',
    subtitle: 'EUROPEAN CORRIDOR   /   350KW FAST MOBILITY',
    tagline: 'ENERGY TODAY. A BRIGHTER TOMORROW.',
    category: 'EV Charging & Modern Forecourts',
    image: '/images/bp_pulse_hub.jpg',
    coordinates: "51° 30' N  •  000° 07' W",
    speed: '350 kW Dispenser',
    powerOutput: '100% Certified Green Power',
    efficiency: '10-Min 100mi Range',
    carbonOffset: '38,000+ Global Sockets',
    status: 'ALL 16 BAYS OPERATIONAL • FAST CHARGE',
    hotspots: [
      {
        id: 'charger',
        x: 55,
        y: 52,
        title: 'Liquid-Cooled 350kW Ultra-Fast Dispenser',
        tag: 'PULSE INFRASTRUCTURE',
        description: 'Next-gen dual CCS2 dispensers capable of adding 100 miles of vehicle range in under 10 minutes.',
        metric: '350 kW Peak',
        metricLabel: 'Ultra-Fast Charging Rate'
      },
      {
        id: 'canopy',
        x: 40,
        y: 30,
        title: 'Bifacial Solar Photovoltaic Canopy',
        tag: 'LOCAL GENERATION',
        description: 'Architectural solar array providing on-site clean electrons paired with 1.2 MWh battery energy storage for grid buffering.',
        metric: '1.2 MWh',
        metricLabel: 'On-Site BESS Storage'
      },
      {
        id: 'retail',
        x: 75,
        y: 50,
        title: 'Wild Bean Cafe & Seamless Digital Checkout',
        tag: 'CONVENIENCE EXPERIENCE',
        description: 'Integrated premium food and coffee lounge with automated billing and high-speed Wi-Fi while charging.',
        metric: '4.9 ★ Rating',
        metricLabel: 'Driver Satisfaction Index'
      }
    ]
  }
];

export function HeroExperience() {
  const [currentSceneIdx, setCurrentSceneIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [audioActive, setAudioActive] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<Hotspot | null>(null);
  const [filterMode, setFilterMode] = useState<'normal' | 'thermal' | 'radar' | 'eco'>('normal');
  const [showTelemetry, setShowTelemetry] = useState(true);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [progress, setProgress] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const scene = HERO_SCENES[currentSceneIdx];

  // Auto-advance scene timer
  useEffect(() => {
    if (!isPlaying) return;
    const interval = 80;
    const totalDuration = 8000;
    const step = (interval / totalDuration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setCurrentSceneIdx((curr) => (curr + 1) % HERO_SCENES.length);
          setActiveHotspot(null);
          return 0;
        }
        return prev + step;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [isPlaying, currentSceneIdx]);

  // Handle Mouse Parallax
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePos({ x, y });
  };

  const handleToggleAudio = () => {
    if (bpAmbience) {
      const active = bpAmbience.toggle();
      setAudioActive(active);
    }
  };

  return (
    <div
      id="hero"
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative w-full h-screen min-h-[720px] max-h-[1120px] bg-[#050B10] overflow-hidden select-none flex flex-col justify-between"
    >
      {/* Dynamic Background Photo Layer with Ken Burns and 3D Parallax */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={scene.id}
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{
              opacity: 1,
              scale: 1,
              x: mousePos.x * -25,
              y: mousePos.y * -18,
            }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{
              opacity: { duration: 1.2, ease: [0.22, 1, 0.36, 1] },
              scale: { duration: 9, ease: 'linear' },
              x: { type: 'spring', damping: 40, stiffness: 60 },
              y: { type: 'spring', damping: 40, stiffness: 60 },
            }}
            className="relative w-full h-full"
          >
            {/* Main Photography */}
            <img
              src={scene.image}
              alt={scene.title}
              referrerPolicy="no-referrer"
              className={`w-full h-full object-cover object-center transition-all duration-700 ${
                filterMode === 'thermal'
                  ? 'contrast-150 saturate-200 hue-rotate-90 filter invert-20'
                  : filterMode === 'radar'
                  ? 'grayscale brightness-75 contrast-125 sepia hue-rotate-130'
                  : filterMode === 'eco'
                  ? 'saturate-150 hue-rotate-30 brightness-95'
                  : ''
              }`}
            />

            {/* Aesthetic Vignette & Atmospheric Contrast Gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#060D13] via-black/20 to-black/60 pointer-events-none" />
            <div className="absolute inset-0 bg-radial-at-c from-transparent via-transparent to-black/70 pointer-events-none" />

            {/* Optional Radar Scan Line Effect */}
            {filterMode === 'radar' && (
              <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(0,135,81,0.1)_1px,transparent_1px)] bg-[size:100%_4px] opacity-40 animate-pulse" />
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* TOP HEADER OVERLAYS (Exact Reference Design) */}
      <div className="relative z-20 pt-20 sm:pt-24 px-6 sm:px-10 lg:px-16 flex items-start justify-between">
        {/* Top Left: Logo + "Powering the world's energy" */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-col"
        >
          <div className="flex items-center gap-4">
            <HeliosLogo size={52} showText={true} textColor="text-white" glow={true} />
            <div className="hidden sm:block pl-4 border-l border-white/20">
              <span className="text-sm font-medium tracking-wide text-slate-200 drop-shadow-md">
                Powering <br />the world&apos;s <br />energy
              </span>
            </div>
          </div>
        </motion.div>

        {/* Top Right: "SAFER / CLEANER / STRONGER" Tagline */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-right"
        >
          <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 text-[11px] sm:text-xs font-mono-tech tracking-[0.25em] text-slate-300 uppercase shadow-lg">
            <span className="text-emerald-400 font-semibold">SAFER</span>
            <span className="opacity-40">/</span>
            <span className="text-yellow-300 font-semibold">CLEANER</span>
            <span className="opacity-40">/</span>
            <span className="text-slate-100 font-semibold">STRONGER</span>
          </div>
        </motion.div>
      </div>

      {/* INTERACTIVE HOTSPOTS ON THE PHOTOGRAPHY */}
      <div className="absolute inset-0 z-10 pointer-events-none">
        {scene.hotspots.map((hotspot) => {
          const isSelected = activeHotspot?.id === hotspot.id;
          return (
            <div
              key={hotspot.id}
              style={{ left: `${hotspot.x}%`, top: `${hotspot.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-auto group"
            >
              {/* Pulsing Target Dot */}
              <button
                onClick={() => setActiveHotspot(isSelected ? null : hotspot)}
                className={`relative flex items-center justify-center p-2 rounded-full transition-transform duration-300 ${
                  isSelected ? 'scale-125' : 'hover:scale-110'
                }`}
              >
                <span className="absolute w-8 h-8 rounded-full bg-emerald-500/30 animate-ping" />
                <span className="absolute w-6 h-6 rounded-full bg-emerald-400/50" />
                <span className={`relative w-3.5 h-3.5 rounded-full border-2 border-white shadow-lg transition-colors ${
                  isSelected ? 'bg-yellow-400' : 'bg-emerald-500'
                }`} />
              </button>

              {/* Hover Badge */}
              <div className="absolute top-10 left-1/2 -translate-x-1/2 hidden group-hover:flex items-center gap-1.5 px-2.5 py-1 rounded bg-black/80 backdrop-blur-md border border-emerald-500/40 text-[10px] font-mono-tech text-emerald-300 uppercase whitespace-nowrap shadow-xl">
                <span>{hotspot.tag}</span>
                <ChevronRight className="w-3 h-3 text-yellow-400" />
              </div>
            </div>
          );
        })}
      </div>

      {/* SELECTED HOTSPOT SLIDE-IN CARD */}
      <AnimatePresence>
        {activeHotspot && (
          <motion.div
            initial={{ opacity: 0, x: 40, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 40, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute right-6 sm:right-12 top-1/3 z-30 w-80 sm:w-96 bp-glass-glow rounded-2xl p-5 text-left text-slate-100 shadow-2xl"
          >
            <div className="flex items-center justify-between pb-3 border-b border-emerald-900/50 mb-3">
              <span className="text-[10px] font-mono-tech uppercase tracking-widest text-emerald-400 font-bold flex items-center gap-1.5">
                <Radio className="w-3 h-3 animate-pulse text-yellow-400" />
                {activeHotspot.tag}
              </span>
              <button
                onClick={() => setActiveHotspot(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-0.5 rounded bg-slate-800/60"
              >
                ✕ Close
              </button>
            </div>

            <h4 className="text-base font-bold font-display text-white mb-1.5">
              {activeHotspot.title}
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              {activeHotspot.description}
            </p>

            <div className="bg-black/50 rounded-xl p-3 border border-emerald-900/30 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                  {activeHotspot.metricLabel}
                </div>
                <div className="text-lg font-bold font-mono-tech text-emerald-400">
                  {activeHotspot.metric}
                </div>
              </div>
              <div className="w-8 h-8 rounded-lg bg-emerald-950/80 flex items-center justify-center border border-emerald-500/30">
                <Sparkles className="w-4 h-4 text-yellow-300" />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* BOTTOM HERO SECTION: ASSET METADATA & EDITORIAL ACCENTS */}
      <div className="relative z-20 pb-8 sm:pb-12 px-6 sm:px-10 lg:px-16 flex flex-col md:flex-row md:items-end justify-between gap-6">
        
        {/* Bottom Left: Asset Identity (OCEAN TITAN / ATLANTIC TRANSIT / BP FLEET) */}
        <motion.div
          key={`title-${scene.id}`}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="flex flex-col"
        >
          <div className="flex items-center gap-3 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-[11px] font-mono-tech tracking-wider text-emerald-400 uppercase">
              {scene.status}
            </span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-display tracking-tight text-white drop-shadow-2xl">
            {scene.title}
          </h1>

          <div className="mt-2 text-xs sm:text-sm font-mono-tech tracking-[0.25em] text-slate-300 uppercase flex items-center gap-3">
            <span>{scene.subtitle}</span>
          </div>

          {/* Quick HUD Telemetry Bar */}
          {showTelemetry && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-4 flex flex-wrap items-center gap-2 sm:gap-4 text-[11px] font-mono-tech text-slate-300"
            >
              <div className="px-2.5 py-1 rounded bg-black/50 backdrop-blur-md border border-white/10 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-emerald-400" />
                <span>{scene.coordinates}</span>
              </div>
              <div className="px-2.5 py-1 rounded bg-black/50 backdrop-blur-md border border-white/10 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-yellow-400" />
                <span>{scene.speed}</span>
              </div>
              <div className="px-2.5 py-1 rounded bg-black/50 backdrop-blur-md border border-white/10 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>{scene.efficiency}</span>
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Bottom Right: Tagline with Green Accent Line (ENERGY TODAY. A BRIGHTER TOMORROW.) */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex items-center gap-4 text-right self-end md:self-auto"
        >
          <div className="w-1 h-14 bg-gradient-to-b from-emerald-400 to-[#008751] rounded-full shadow-lg shadow-emerald-500/50" />
          <div className="flex flex-col text-left">
            <span className="text-xs sm:text-sm font-bold font-display tracking-[0.2em] text-slate-100 uppercase">
              ENERGY TODAY.
            </span>
            <span className="text-xs sm:text-sm font-bold font-display tracking-[0.2em] text-emerald-400 uppercase">
              A BRIGHTER TOMORROW.
            </span>
          </div>
        </motion.div>
      </div>

      {/* FLOATING CONTROLS BAR: Scene Switcher, Filter Modes & Audio */}
      <div className="relative z-30 pb-4 px-6 sm:px-10 lg:px-16 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-3 bg-black/40 backdrop-blur-md">
        
        {/* Scene Thumbnails & Progress */}
        <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto py-1">
          {HERO_SCENES.map((item, idx) => {
            const isActive = currentSceneIdx === idx;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentSceneIdx(idx);
                  setProgress(0);
                  setActiveHotspot(null);
                }}
                className={`relative px-3 py-1.5 rounded-lg text-xs font-mono-tech transition-all flex items-center gap-2 ${
                  isActive
                    ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/60 shadow-lg'
                    : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-white/5'
                }`}
              >
                <span className="font-bold">{`0${idx + 1}`}</span>
                <span className="hidden sm:inline font-sans font-medium">{item.title}</span>
                {isActive && (
                  <div className="absolute bottom-0 left-0 h-0.5 bg-yellow-400 transition-all" style={{ width: `${progress}%` }} />
                )}
              </button>
            );
          })}
        </div>

        {/* Interactive Tools: Play/Pause, Audio, Telemetry, FLIR/Radar Filters */}
        <div className="flex items-center gap-2 text-xs font-mono-tech">
          {/* Play/Pause */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2 rounded-lg bg-slate-900/70 hover:bg-slate-800 border border-white/10 text-slate-200 hover:text-white transition-colors"
            title={isPlaying ? 'Pause Auto-Pan' : 'Play Auto-Pan'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          {/* Sound Ambience Toggle */}
          <button
            onClick={handleToggleAudio}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all ${
              audioActive
                ? 'bg-emerald-950 border-emerald-500/60 text-emerald-300 shadow-sm'
                : 'bg-slate-900/70 border-white/10 text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle Oceanic & Turbine Soundscape"
          >
            {audioActive ? <Volume2 className="w-3.5 h-3.5 text-yellow-300 animate-pulse" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">{audioActive ? 'Audio ON' : 'Audio OFF'}</span>
          </button>

          {/* Filter Preset Buttons */}
          <div className="hidden lg:flex items-center bg-slate-900/80 p-0.5 rounded-lg border border-white/10">
            {(['normal', 'thermal', 'radar', 'eco'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setFilterMode(mode)}
                className={`px-2 py-1 rounded text-[11px] capitalize transition-colors ${
                  filterMode === mode
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {mode === 'normal' ? '8K HD' : mode === 'thermal' ? 'FLIR Heat' : mode === 'radar' ? 'Radar HUD' : 'Eco-Flux'}
              </button>
            ))}
          </div>

          {/* Telemetry Toggle */}
          <button
            onClick={() => setShowTelemetry(!showTelemetry)}
            className={`p-2 rounded-lg border transition-colors ${
              showTelemetry ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-400' : 'bg-slate-900/70 border-white/10 text-slate-400'
            }`}
            title="Toggle HUD Telemetry"
          >
            <Activity className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
