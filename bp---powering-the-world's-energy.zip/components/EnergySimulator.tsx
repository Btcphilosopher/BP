'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart3, 
  TrendingUp, 
  Leaf, 
  Wind, 
  Flame, 
  Zap, 
  Compass, 
  Layers, 
  Sliders, 
  Info,
  CheckCircle2
} from 'lucide-react';

interface ScenarioData {
  id: string;
  name: string;
  tagline: string;
  renewablesShare2030: number;
  renewablesShare2050: number;
  oilDemand2030: number; // Mboe/d
  oilDemand2050: number;
  hydrogenMt2050: number;
  carbonReduction2030: number; // %
  carbonReduction2050: number;
  bpRenewableCapGW: number;
  description: string;
  keyDrivers: string[];
}

const SCENARIOS: ScenarioData[] = [
  {
    id: 'net-zero',
    name: 'Net Zero Pathway (1.5°C)',
    tagline: 'Aggressive worldwide decarbonization with massive renewable electrification & green hydrogen',
    renewablesShare2030: 42,
    renewablesShare2050: 78,
    oilDemand2030: 75,
    oilDemand2050: 22,
    hydrogenMt2050: 620,
    carbonReduction2030: 50,
    carbonReduction2050: 95,
    bpRenewableCapGW: 50,
    description: 'Aligned with global temperature increases capped at 1.5°C. Accelerated carbon pricing ($150+/t), mandatory SAF mandates for aviation, and rapid industrial CCUS deployment.',
    keyDrivers: [
      'Rapid Phase-in of 800V+ EV corridors across North America and Europe',
      'Global carbon pricing mechanisms covering >70% of worldwide emissions',
      'Massive scale-up of green hydrogen for steel and maritime shipping'
    ]
  },
  {
    id: 'accelerated',
    name: 'Accelerated Transition',
    tagline: 'Balanced rapid deployment of low-carbon power alongside energy security resilience',
    renewablesShare2030: 36,
    renewablesShare2050: 64,
    oilDemand2030: 88,
    oilDemand2050: 45,
    hydrogenMt2050: 380,
    carbonReduction2030: 38,
    carbonReduction2050: 75,
    bpRenewableCapGW: 35,
    description: 'Represents strong policy implementation with steady renewable grid expansion, dual-fuel maritime carriers, and rapid EV adoption in key OECD markets.',
    keyDrivers: [
      'Dual-fuel shipping adoption and bio-LNG blending mandates',
      'Expanded offshore wind capacity in the North Sea and East Coast USA',
      'Targeted CCUS hubs in major industrial manufacturing basins'
    ]
  },
  {
    id: 'current-trajectory',
    name: 'Current Trajectory',
    tagline: 'Evolutionary transition constrained by localized infrastructure and grid bottlenecks',
    renewablesShare2030: 28,
    renewablesShare2050: 48,
    oilDemand2030: 96,
    oilDemand2050: 68,
    hydrogenMt2050: 190,
    carbonReduction2030: 22,
    carbonReduction2050: 45,
    bpRenewableCapGW: 20,
    description: 'Reflects existing declared policies without dramatic global escalation in carbon pricing or grid interconnect capacity.',
    keyDrivers: [
      'Steady EV adoption primarily in passenger vehicles',
      'Continued reliance on resilient conventional hydrocarbons for heavy industry',
      'Moderate growth in decentralized rooftop and utility solar'
    ]
  }
];

export function EnergySimulator() {
  const [selectedScenarioId, setSelectedScenarioId] = useState('net-zero');
  const [activeYear, setActiveYear] = useState<2030 | 2050>(2030);

  const scenario = SCENARIOS.find((s) => s.id === selectedScenarioId) || SCENARIOS[0];

  const renewablesShare = activeYear === 2030 ? scenario.renewablesShare2030 : scenario.renewablesShare2050;
  const oilDemand = activeYear === 2030 ? scenario.oilDemand2030 : scenario.oilDemand2050;
  const carbonCut = activeYear === 2030 ? scenario.carbonReduction2030 : scenario.carbonReduction2050;

  return (
    <section id="simulator" className="py-24 bg-[#070E14] relative border-t border-emerald-950/60 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-tech uppercase tracking-widest text-emerald-400 font-bold mb-2">
              <BarChart3 className="w-4 h-4 text-emerald-400" />
              <span>bp Energy Outlook Interactive Modeler</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white">
              Global Energy Transition Scenarios
            </h2>
          </div>
          <p className="max-w-md text-slate-300 text-sm leading-relaxed">
            Explore how different policy, technology, and societal trajectories reshape global energy mix, emissions, and bp capital deployment.
          </p>
        </div>

        {/* Scenario Selectors & Year Toggle */}
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4 mb-8">
          
          {/* Scenario Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 w-full lg:w-auto">
            {SCENARIOS.map((s) => {
              const isSel = s.id === selectedScenarioId;
              return (
                <button
                  key={s.id}
                  onClick={() => setSelectedScenarioId(s.id)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-mono-tech text-left transition-all border ${
                    isSel
                      ? 'bg-emerald-950/90 border-emerald-500 text-white font-bold shadow-lg shadow-emerald-950/50'
                      : 'bg-slate-900/50 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    {isSel && <span className="w-2 h-2 rounded-full bg-yellow-400" />}
                    <span>{s.name}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* 2030 vs 2050 Time Horizon Toggle */}
          <div className="flex items-center bg-black/60 p-1 rounded-xl border border-slate-800 self-end sm:self-auto">
            <span className="text-xs text-slate-400 font-mono-tech px-3 hidden sm:inline">Time Horizon:</span>
            <button
              onClick={() => setActiveYear(2030)}
              className={`px-4 py-1.5 rounded-lg text-xs font-mono-tech font-bold transition-colors ${
                activeYear === 2030
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Horizon 2030
            </button>
            <button
              onClick={() => setActiveYear(2050)}
              className={`px-4 py-1.5 rounded-lg text-xs font-mono-tech font-bold transition-colors ${
                activeYear === 2050
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Horizon 2050 (Target)
            </button>
          </div>
        </div>

        {/* Dynamic Interactive Metrics & Graph Box */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`${scenario.id}-${activeYear}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.35 }}
            className="bp-glass-glow rounded-3xl p-6 sm:p-10 border border-emerald-900/50 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center"
          >
            
            {/* Left Col: Scenario Narrative */}
            <div className="lg:col-span-5 space-y-4">
              <div className="inline-block text-[11px] font-mono-tech px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                SCENARIO OUTLOOK • YEAR {activeYear}
              </div>
              <h3 className="text-2xl font-bold font-display text-white">
                {scenario.name}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {scenario.description}
              </p>

              <div className="pt-2 space-y-2">
                <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">
                  Key Transformation Levers:
                </div>
                {scenario.keyDrivers.map((driver, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{driver}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Col: Reactive Visual Indicator Bars */}
            <div className="lg:col-span-7 space-y-5 bg-black/40 p-6 rounded-2xl border border-slate-800">
              
              {/* Metric 1: Renewable Power Share */}
              <div>
                <div className="flex justify-between text-xs font-mono-tech mb-1.5">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Wind className="w-3.5 h-3.5 text-emerald-400" />
                    Renewables Share in Primary Power
                  </span>
                  <span className="text-emerald-400 font-bold">{renewablesShare}%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${renewablesShare}%` }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                    className="h-full bg-gradient-to-r from-emerald-500 to-yellow-400 rounded-full"
                  />
                </div>
              </div>

              {/* Metric 2: Global Oil & Liquids Demand */}
              <div>
                <div className="flex justify-between text-xs font-mono-tech mb-1.5">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-yellow-400" />
                    Global Liquid Hydrocarbon Demand
                  </span>
                  <span className="text-yellow-400 font-bold">{oilDemand} Mboe/d</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(oilDemand / 100) * 100}%` }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                    className="h-full bg-gradient-to-r from-yellow-500 to-amber-600 rounded-full"
                  />
                </div>
              </div>

              {/* Metric 3: Carbon Reduction vs Baseline */}
              <div>
                <div className="flex justify-between text-xs font-mono-tech mb-1.5">
                  <span className="text-slate-300 flex items-center gap-1.5">
                    <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                    Global CO₂e Emissions Reduction
                  </span>
                  <span className="text-emerald-300 font-bold">-{carbonCut}%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${carbonCut}%` }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                    className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 rounded-full"
                  />
                </div>
              </div>

              {/* Summary Cards Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800">
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-400 font-mono-tech uppercase">bp Renewable Target</div>
                  <div className="text-base font-bold font-mono-tech text-emerald-400 mt-0.5">{scenario.bpRenewableCapGW} GW</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                  <div className="text-[10px] text-slate-400 font-mono-tech uppercase">Clean H₂ by 2050</div>
                  <div className="text-base font-bold font-mono-tech text-cyan-400 mt-0.5">{scenario.hydrogenMt2050} Mt</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center col-span-2 sm:col-span-1">
                  <div className="text-[10px] text-slate-400 font-mono-tech uppercase">Capital Reinvestment</div>
                  <div className="text-base font-bold font-mono-tech text-yellow-300 mt-0.5">&gt;40% Low Carbon</div>
                </div>
              </div>

            </div>

          </motion.div>
        </AnimatePresence>

      </div>
    </section>
  );
}
