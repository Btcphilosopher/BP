'use client';

import React, { useState } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  FileText, 
  Download, 
  ArrowUpRight, 
  Calendar, 
  Building2, 
  ShieldCheck, 
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface NewsItem {
  id: string;
  category: string;
  date: string;
  title: string;
  excerpt: string;
  readTime: string;
}

const NEWS_RELEASES: NewsItem[] = [
  {
    id: 'news-1',
    category: 'Marine & Operations',
    date: 'Sep 12, 2026',
    title: 'Ocean Titan Completes 10,000 NM Bio-LNG Low-Carbon Trans-Atlantic Voyage',
    excerpt: 'BP’s flagship dual-fuel tanker validates 34% maritime greenhouse gas reduction in commercial transit between US Gulf Coast and Rotterdam gateway.',
    readTime: '3 min read'
  },
  {
    id: 'news-2',
    category: 'bp pulse EV Mobility',
    date: 'Sep 08, 2026',
    title: 'bp pulse Surpasses 39,000 Global Ultra-Fast Charging Sockets in Europe & US',
    excerpt: 'Accelerating EV infrastructure with new 350kW liquid-cooled dispensers and seamless automatic plug-and-charge interoperability.',
    readTime: '4 min read'
  },
  {
    id: 'news-3',
    category: 'Offshore Wind & Renewables',
    date: 'Aug 29, 2026',
    title: 'Dogger Bank Offshore Wind Matrix Transmits Record 3.2 GW to UK Grid',
    excerpt: 'High-voltage direct current (HVDC) subsea links deliver clean power to over 5 million homes during peak autumn wind generation.',
    readTime: '2 min read'
  },
  {
    id: 'news-4',
    category: 'Hydrogen & Industrial Decarbonization',
    date: 'Aug 17, 2026',
    title: 'HyGreen Teesside Phase 2 Achieves Key Regulatory Environmental Clearance',
    excerpt: 'Expanding green hydrogen electrolysis capacity to supply heavy industrial manufacturing and zero-emission transit fleets across the UK.',
    readTime: '3 min read'
  }
];

export function NewsAndInvestors() {
  const [selectedFilter, setSelectedFilter] = useState('all');

  return (
    <section id="investors" className="py-24 bg-[#050A0E] relative border-t border-emerald-950/60 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-tech uppercase tracking-widest text-emerald-400 font-bold mb-2">
              <Building2 className="w-4 h-4 text-emerald-400" />
              <span>Financial Discipline & Transparency</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-white">
              Investors & Newsroom
            </h2>
          </div>
          <p className="max-w-md text-slate-300 text-sm leading-relaxed">
            Delivering compelling shareholder returns through resilient hydrocarbons while disciplined capital drives our low-carbon growth engines.
          </p>
        </div>

        {/* Financial Scorecards Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-1">
              Operating Cash Flow (LTM)
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono-tech text-emerald-400">
              $31.8B
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-emerald-400" />
              <span>Disciplined cost structure</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-1">
              Share Buybacks 2026
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono-tech text-white">
              $7.0B
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Surplus cash commitment
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-1">
              Transition Capex Share
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono-tech text-yellow-400">
              35-40%
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Targeting high-return renewables
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider mb-1">
              Credit Rating (S&P / Moody&apos;s)
            </div>
            <div className="text-2xl sm:text-3xl font-black font-mono-tech text-emerald-400">
              A+ / A1
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Stable balance sheet rating
            </div>
          </div>
        </div>

        {/* Latest News & Press Releases Grid */}
        <div>
          <div className="flex items-center justify-between mb-8 pb-3 border-b border-slate-800">
            <h3 className="text-xl font-bold font-display text-white">
              Latest Press Releases & Disclosures
            </h3>
            <span className="text-xs font-mono-tech text-emerald-400">
              Updated Live • London HQ
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {NEWS_RELEASES.map((news) => (
              <div
                key={news.id}
                className="bp-glass rounded-2xl p-6 border border-slate-800 hover:border-emerald-500/50 transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-mono-tech mb-3">
                    <span className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-900/40">
                      {news.category}
                    </span>
                    <span className="text-slate-400">{news.date}</span>
                  </div>

                  <h4 className="text-base sm:text-lg font-bold font-display text-white group-hover:text-emerald-400 transition-colors mb-2">
                    {news.title}
                  </h4>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                    {news.excerpt}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs font-mono-tech pt-4 border-t border-slate-800/80 text-slate-400">
                  <span>{news.readTime}</span>
                  <span className="text-emerald-400 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-1">
                    Read Release <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
