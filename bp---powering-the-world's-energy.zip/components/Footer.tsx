'use client';

import React from 'react';
import { HeliosLogo } from './HeliosLogo';
import { 
  Globe, 
  ShieldCheck, 
  FileText, 
  Building2, 
  MapPin, 
  ExternalLink,
  ChevronRight,
  Anchor,
  Zap,
  Wind
} from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#04080C] text-slate-400 border-t border-emerald-950/80 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-14 border-b border-slate-900">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <HeliosLogo size={46} showText={true} tagline="Powering the world's energy" glow={true} />
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              bp is an integrated energy company with operations across Europe, North America, South America, Asia, Australia, and Africa. Delivering safer, cleaner, and stronger energy today and for future generations.
            </p>
            <div className="flex items-center gap-2 text-xs font-mono-tech text-emerald-400">
              <MapPin className="w-3.5 h-3.5" />
              <span>1 St James&apos;s Square, London SW1Y 4PD, UK</span>
            </div>
          </div>

          {/* Column 1: Strategy & Operations */}
          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-wider text-white font-bold">
              Energy & Operations
            </div>
            <ul className="space-y-2 text-xs">
              <li><a href="#strategy" className="hover:text-emerald-400 transition-colors">Resilient Hydrocarbons</a></li>
              <li><a href="#fleet" className="hover:text-emerald-400 transition-colors">Ocean Titan & Global Fleet</a></li>
              <li><a href="#pulse" className="hover:text-emerald-400 transition-colors">bp pulse EV Fast Charging</a></li>
              <li><a href="#strategy" className="hover:text-emerald-400 transition-colors">Offshore Wind & Solar</a></li>
              <li><a href="#strategy" className="hover:text-emerald-400 transition-colors">Hydrogen & CCUS</a></li>
            </ul>
          </div>

          {/* Column 2: Investors & Governance */}
          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-wider text-white font-bold">
              Investors & ESG
            </div>
            <ul className="space-y-2 text-xs">
              <li><a href="#investors" className="hover:text-emerald-400 transition-colors">Quarterly Results & Webcasts</a></li>
              <li><a href="#investors" className="hover:text-emerald-400 transition-colors">Sustainability Disclosures</a></li>
              <li><a href="#investors" className="hover:text-emerald-400 transition-colors">Shareholder Distributions</a></li>
              <li><a href="#simulator" className="hover:text-emerald-400 transition-colors">Energy Outlook 2026-2050</a></li>
              <li><a href="#investors" className="hover:text-emerald-400 transition-colors">Executive Board & Governance</a></li>
            </ul>
          </div>

          {/* Column 3: Corporate & Global */}
          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-wider text-white font-bold">
              Global Presence
            </div>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center gap-1.5 hover:text-emerald-400 cursor-pointer">
                <span>United Kingdom</span>
              </li>
              <li className="flex items-center gap-1.5 hover:text-emerald-400 cursor-pointer">
                <span>United States (bp America)</span>
              </li>
              <li className="flex items-center gap-1.5 hover:text-emerald-400 cursor-pointer">
                <span>Germany (bp & Aral)</span>
              </li>
              <li className="flex items-center gap-1.5 hover:text-emerald-400 cursor-pointer">
                <span>Australia & New Zealand</span>
              </li>
              <li className="flex items-center gap-1.5 hover:text-emerald-400 cursor-pointer">
                <span>Singapore & Asia-Pacific</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Copyright & Compliance */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono-tech text-slate-500">
          <div>
            © 2026 BP p.l.c. All rights reserved. Safer, Cleaner, Stronger.
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <span className="hover:text-slate-300 cursor-pointer">Privacy Statement</span>
            <span>•</span>
            <span className="hover:text-slate-300 cursor-pointer">Legal Notice</span>
            <span>•</span>
            <span className="hover:text-slate-300 cursor-pointer">Modern Slavery Act</span>
            <span>•</span>
            <span className="hover:text-slate-300 cursor-pointer">GHG Protocol Scope 1, 2, 3</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
