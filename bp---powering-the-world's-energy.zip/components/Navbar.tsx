'use client';

import React, { useState, useEffect } from 'react';
import { HeliosLogo } from './HeliosLogo';
import { 
  Globe, 
  Search, 
  Menu, 
  X, 
  ChevronDown, 
  Sparkles, 
  Activity, 
  ShieldCheck, 
  Zap, 
  Compass, 
  BarChart3,
  ExternalLink
} from 'lucide-react';

interface NavbarProps {
  onOpenAI?: () => void;
  activeSection?: string;
}

export function Navbar({ onOpenAI }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [regionOpen, setRegionOpen] = useState(false);
  const [currentRegion, setCurrentRegion] = useState('Global (EN)');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const regions = [
    { code: 'Global (EN)', flag: '🌐' },
    { code: 'United Kingdom', flag: '🇬🇧' },
    { code: 'United States', flag: '🇺🇸' },
    { code: 'Germany (bp / Aral)', flag: '🇩🇪' },
    { code: 'Australia', flag: '🇦🇺' },
    { code: 'Singapore (Asia Trading)', flag: '🇸🇬' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#060D13]/90 backdrop-blur-xl border-b border-emerald-900/30 shadow-2xl shadow-black/50 py-3'
          : 'bg-gradient-to-b from-black/85 via-black/40 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Logo and Tagline matching the reference aesthetic */}
        <a href="#hero" className="flex items-center group">
          <HeliosLogo
            size={scrolled ? 42 : 46}
            showText={true}
            tagline="Powering the world's energy"
            glow={true}
          />
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
          <a
            href="#strategy"
            className="px-3.5 py-2 text-sm font-medium text-slate-200 hover:text-emerald-400 hover:bg-emerald-950/30 rounded-lg transition-colors"
          >
            Strategy & Transition
          </a>
          <a
            href="#fleet"
            className="px-3.5 py-2 text-sm font-medium text-slate-200 hover:text-emerald-400 hover:bg-emerald-950/30 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            Global Fleet & Radar
          </a>
          <a
            href="#pulse"
            className="px-3.5 py-2 text-sm font-medium text-slate-200 hover:text-emerald-400 hover:bg-emerald-950/30 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5 text-yellow-400" />
            bp pulse
          </a>
          <a
            href="#simulator"
            className="px-3.5 py-2 text-sm font-medium text-slate-200 hover:text-emerald-400 hover:bg-emerald-950/30 rounded-lg transition-colors"
          >
            Scenario Modeler
          </a>
          <a
            href="#investors"
            className="px-3.5 py-2 text-sm font-medium text-slate-200 hover:text-emerald-400 hover:bg-emerald-950/30 rounded-lg transition-colors"
          >
            Investors & News
          </a>
        </nav>

        {/* Action Controls & AI Strategy Assistant */}
        <div className="hidden md:flex items-center space-x-3">
          {/* AI Intelligence Trigger */}
          <button
            onClick={onOpenAI}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-emerald-600/30 via-emerald-500/20 to-yellow-500/20 hover:from-emerald-600/50 hover:to-yellow-500/40 border border-emerald-500/40 text-xs font-medium text-emerald-300 hover:text-white transition-all shadow-sm hover:shadow-emerald-900/40 group"
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 group-hover:rotate-12 transition-transform" />
            <span>bp Energy Intelligence</span>
          </button>

          {/* Region Dropdown */}
          <div className="relative">
            <button
              onClick={() => setRegionOpen(!regionOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-900/60 hover:bg-slate-800/80 border border-slate-700/60 transition-all"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden xl:inline">{currentRegion}</span>
              <ChevronDown className="w-3 h-3 opacity-70" />
            </button>

            {regionOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-[#0c1822] border border-emerald-900/50 rounded-xl shadow-2xl py-2 z-50 backdrop-blur-2xl">
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  Select Regional Portal
                </div>
                {regions.map((reg) => (
                  <button
                    key={reg.code}
                    onClick={() => {
                      setCurrentRegion(reg.code);
                      setRegionOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-emerald-950/40 transition-colors ${
                      currentRegion === reg.code ? 'text-emerald-400 font-semibold bg-emerald-950/30' : 'text-slate-200'
                    }`}
                  >
                    <span>{reg.flag} {reg.code}</span>
                    {currentRegion === reg.code && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="lg:hidden flex items-center gap-2">
          <button
            onClick={onOpenAI}
            className="p-2 rounded-lg bg-emerald-950/50 border border-emerald-500/40 text-emerald-400"
            title="Ask bp Intelligence"
          >
            <Sparkles className="w-4 h-4 text-yellow-300" />
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-slate-900/70 border border-slate-700/60 text-slate-200 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#07111a] border-b border-emerald-900/40 px-5 pt-4 pb-6 space-y-3 mt-2 shadow-2xl">
          <div className="text-xs uppercase tracking-widest text-emerald-400 font-bold mb-1">
            Navigation
          </div>
          <a
            href="#strategy"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-base font-medium text-slate-200 hover:text-emerald-400"
          >
            Strategy & Energy Transition
          </a>
          <a
            href="#fleet"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-base font-medium text-slate-200 hover:text-emerald-400"
          >
            Global Fleet & Radar
          </a>
          <a
            href="#pulse"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-base font-medium text-slate-200 hover:text-emerald-400"
          >
            bp pulse EV Network
          </a>
          <a
            href="#simulator"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-base font-medium text-slate-200 hover:text-emerald-400"
          >
            Scenario Modeler
          </a>
          <a
            href="#investors"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 text-base font-medium text-slate-200 hover:text-emerald-400"
          >
            Investors & Sustainability
          </a>

          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                if (onOpenAI) onOpenAI();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-lg shadow-emerald-900/40"
            >
              <Sparkles className="w-4 h-4 text-yellow-300" />
              Open bp Energy Intelligence
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
