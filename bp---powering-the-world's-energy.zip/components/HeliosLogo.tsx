'use client';

import React from 'react';

interface HeliosLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  textColor?: string;
  tagline?: string;
  glow?: boolean;
}

export function HeliosLogo({
  className = '',
  size = 48,
  showText = true,
  textColor = 'text-white',
  tagline,
  glow = true,
}: HeliosLogoProps) {
  // Helios flower has 4 layers of multi-pointed radiant petals (green outer, lime middle, yellow inner, white center)
  const outerPetals = Array.from({ length: 18 });
  const midPetals = Array.from({ length: 18 });
  const innerPetals = Array.from({ length: 14 });

  return (
    <div className={`flex items-center gap-3.5 select-none ${className}`}>
      {/* Helios Flower Emblem */}
      <div 
        className={`relative flex items-center justify-center shrink-0 ${glow ? 'bp-helios-glow' : ''}`}
        style={{ width: size, height: size }}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <radialGradient id="heliosCenterGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="35%" stopColor="#FFF100" />
              <stop offset="70%" stopColor="#97D700" />
              <stop offset="100%" stopColor="#008751" />
            </radialGradient>
            <filter id="flowerGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="1.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Layer 1: Dark Forest Green Outer Star */}
          <g transform="translate(50,50)">
            {outerPetals.map((_, i) => (
              <path
                key={`outer-${i}`}
                d="M 0 -48 L 4.5 -26 L 0 -18 L -4.5 -26 Z"
                fill="#005A36"
                transform={`rotate(${i * 20})`}
              />
            ))}
          </g>

          {/* Layer 2: Emerald Green Middle Petals */}
          <g transform="translate(50,50)">
            {midPetals.map((_, i) => (
              <path
                key={`mid1-${i}`}
                d="M 0 -40 L 4 -22 L 0 -15 L -4 -22 Z"
                fill="#008751"
                transform={`rotate(${i * 20 + 10})`}
              />
            ))}
          </g>

          {/* Layer 3: Vibrant Lime Green Petals */}
          <g transform="translate(50,50)">
            {midPetals.map((_, i) => (
              <path
                key={`mid2-${i}`}
                d="M 0 -32 L 3.5 -17 L 0 -12 L -3.5 -17 Z"
                fill="#78BE20"
                transform={`rotate(${i * 20})`}
              />
            ))}
          </g>

          {/* Layer 4: Radiant Yellow Inner Petals */}
          <g transform="translate(50,50)">
            {innerPetals.map((_, i) => (
              <path
                key={`inner-${i}`}
                d="M 0 -22 L 3 -11 L 0 -7 L -3 -11 Z"
                fill="#FFDE00"
                transform={`rotate(${i * (360 / 14) + 12})`}
              />
            ))}
          </g>

          {/* Center White Core */}
          <circle cx="50" cy="50" r="7.5" fill="#FFFFFF" />
          <circle cx="50" cy="50" r="4" fill="#FFF888" opacity="0.9" />
        </svg>
      </div>

      {/* Wordmark and Tagline */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-baseline gap-2.5">
            <span className={`text-[1.85rem] font-bold tracking-tight leading-none lowercase ${textColor} font-sans drop-shadow-sm`}>
              bp
            </span>
            {tagline && (
              <div className="hidden sm:flex flex-col">
                <span className="text-[0.82rem] font-medium tracking-normal text-slate-200 leading-tight">
                  {tagline}
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
