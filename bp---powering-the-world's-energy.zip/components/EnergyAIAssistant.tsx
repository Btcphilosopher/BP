'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HeliosLogo } from './HeliosLogo';
import { 
  Sparkles, 
  Send, 
  X, 
  Bot, 
  User, 
  Ship, 
  Zap, 
  Wind, 
  Leaf, 
  Loader2, 
  ChevronRight,
  HelpCircle
} from 'lucide-react';

interface EnergyAIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const PRESET_QUERIES = [
  {
    icon: <Ship className="w-3.5 h-3.5 text-cyan-400" />,
    text: 'What is the Ocean Titan and how does dual-fuel shipping reduce emissions?'
  },
  {
    icon: <Zap className="w-3.5 h-3.5 text-yellow-400" />,
    text: 'How fast is bp pulse 350kW charging and where is it expanding in 2026?'
  },
  {
    icon: <Wind className="w-3.5 h-3.5 text-emerald-400" />,
    text: 'What are bp’s major offshore wind arrays and renewable targets?'
  },
  {
    icon: <Leaf className="w-3.5 h-3.5 text-emerald-300" />,
    text: 'Explain bp’s 2030 emissions goals and Net Zero 2050 transition roadmap.'
  }
];

export function EnergyAIAssistant({ isOpen, onClose }: EnergyAIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Welcome to bp Energy Intelligence. I can answer inquiries regarding our global fleet (including the Ocean Titan), bp pulse ultra-fast EV charging network, offshore wind projects, or our 2030/2050 Net Zero transition strategy. How can I assist you today?"
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async (userQuery?: string) => {
    const queryToSend = userQuery || input.trim();
    if (!queryToSend || loading) return;

    const newMessages: Message[] = [...messages, { role: 'user', content: queryToSend }];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: queryToSend }),
      });
      const data = await res.json();
      setMessages([...newMessages, { role: 'assistant', content: data.text || 'Unable to generate response.' }]);
    } catch {
      setMessages([
        ...newMessages,
        {
          role: 'assistant',
          content: 'bp is actively executing its integrated energy transition across Resilient Hydrocarbons, bp pulse EV charging, and Low Carbon Renewables & Hydrogen.'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="w-full max-w-2xl bg-[#09141D] border border-emerald-800/60 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
          >
            {/* Header */}
            <div className="p-5 bg-[#060D13] border-b border-emerald-950/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <HeliosLogo size={36} showText={false} glow={true} />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold font-display text-white text-base">
                      bp Energy Intelligence
                    </h3>
                    <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                      AI Powered
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Direct executive insights into bp operations & strategy
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Conversation Stream */}
            <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs sm:text-sm">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {m.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-full bg-emerald-950 border border-emerald-600/40 flex items-center justify-center shrink-0 mt-0.5">
                      <Sparkles className="w-4 h-4 text-yellow-400" />
                    </div>
                  )}
                  <div
                    className={`p-4 rounded-2xl max-w-[82%] leading-relaxed ${
                      m.role === 'user'
                        ? 'bg-emerald-600 text-white rounded-br-sm'
                        : 'bg-black/60 border border-slate-800 text-slate-200 rounded-bl-sm'
                    }`}
                  >
                    <div className="whitespace-pre-line">{m.content}</div>
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex items-center gap-2 text-xs font-mono-tech text-emerald-400 p-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Synthesizing bp intelligence...</span>
                </div>
              )}
            </div>

            {/* Preset Query Chips */}
            <div className="p-3 bg-[#060D13]/80 border-t border-slate-800/80">
              <div className="text-[10px] font-mono-tech uppercase tracking-wider text-slate-400 mb-2 px-1">
                Suggested Topics:
              </div>
              <div className="flex flex-wrap gap-1.5">
                {PRESET_QUERIES.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(q.text)}
                    disabled={loading}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 hover:text-white transition-colors text-left"
                  >
                    {q.icon}
                    <span className="truncate max-w-[240px]">{q.text}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Input Bar */}
            <div className="p-4 bg-[#060D13] border-t border-emerald-950/80 flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about Ocean Titan, bp pulse, wind, or Net Zero 2050..."
                className="flex-1 bg-black/60 border border-slate-700/80 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors"
              />
              <button
                onClick={() => handleSend()}
                disabled={loading || !input.trim()}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-40 transition-colors shadow-lg shadow-emerald-950/50"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
