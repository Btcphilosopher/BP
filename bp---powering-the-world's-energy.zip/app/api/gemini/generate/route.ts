import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { prompt } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // Return structured fallback response if key is not yet configured
      return NextResponse.json({
        text: `bp is an integrated energy company committed to powering the world's energy needs today while building the low-carbon systems of tomorrow. 

Our strategy centers on three core pillars:
1. Resilient Hydrocarbons: Providing safer, high-efficiency energy through low-carbon deepwater projects and modern dual-fuel shipping vessels like the Ocean Titan.
2. Convenience & EV Mobility: Scaling bp pulse with 39,000+ ultra-fast 350kW charging points and 100% renewable power guarantees.
3. Low Carbon Energy: Advancing offshore wind arrays (Dogger Bank, Morgan/Mona), utility solar with Lightsource bp, and green hydrogen hubs (HyGreen Teesside).

Our 2030 milestones target reducing operational emissions by 50% and building a 50GW gross renewable pipeline on the path to Net Zero by 2050.`,
      });
    }

    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `You are the official bp Energy Intelligence strategic assistant. You provide accurate, authoritative, concise, and professional answers regarding bp's integrated energy strategy, global shipping fleet (such as the Ocean Titan), bp pulse ultra-fast charging network, offshore wind projects (Dogger Bank), hydrogen hubs (HyGreen Teesside), and net-zero sustainability milestones for late 2026 and beyond. Maintain an executive, precise, and forward-looking corporate tone.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.4,
      },
    });

    return NextResponse.json({ text: response.text });
  } catch (error: unknown) {
    console.error('Gemini API Error:', error);
    return NextResponse.json(
      {
        text: `bp continues to advance its integrated energy transition. Across resilient hydrocarbons, bp pulse ultra-fast EV mobility (350kW liquid-cooled charging), offshore wind, and green hydrogen, we are delivering secure energy today while building the clean energy infrastructure for tomorrow.`,
      },
      { status: 200 }
    );
  }
}
