import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: "bp - Powering the world's energy",
  description: "Official digital experience of bp. Exploring our integrated energy strategy, global shipping fleet, low-carbon solutions, and bp pulse charging network for late 2026 and beyond.",
  openGraph: {
    title: "bp - Powering the world's energy",
    description: "Official digital experience of bp. Exploring our integrated energy strategy, global shipping fleet, low-carbon solutions, and bp pulse charging network for late 2026 and beyond.",
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: "bp - Powering the world's energy",
    description: "Official digital experience of bp. Exploring our integrated energy strategy, global shipping fleet, low-carbon solutions, and bp pulse charging network.",
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-[#070D12] text-slate-100 font-sans antialiased selection:bg-[#008751] selection:text-white min-h-screen overflow-x-hidden" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}

