'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { HeroExperience } from '@/components/HeroExperience';
import { LiveTelemetryTicker } from '@/components/LiveTelemetryTicker';
import { EnergyTransitionRoadmap } from '@/components/EnergyTransitionRoadmap';
import { GlobalAssetMap } from '@/components/GlobalAssetMap';
import { BPPulseExperience } from '@/components/BPPulseExperience';
import { EnergySimulator } from '@/components/EnergySimulator';
import { NewsAndInvestors } from '@/components/NewsAndInvestors';
import { EnergyAIAssistant } from '@/components/EnergyAIAssistant';
import { Footer } from '@/components/Footer';

export default function HomePage() {
  const [isAIOpen, setIsAIOpen] = useState(false);

  return (
    <main className="min-h-screen bg-[#070D12] text-slate-100 flex flex-col">
      {/* Sleek BP Global Header */}
      <Navbar onOpenAI={() => setIsAIOpen(true)} />

      {/* Cinematic Hero with Late-2026 BP Photo Animations */}
      <HeroExperience />

      {/* Live Global Operations & Market Ticker */}
      <LiveTelemetryTicker />

      {/* Three Pillars Strategy: Hydrocarbons, EV Mobility, Low Carbon */}
      <EnergyTransitionRoadmap />

      {/* Interactive Global Fleet Radar & SCADA Telemetry */}
      <GlobalAssetMap />

      {/* bp pulse 350kW Ultra-Fast Charging Network & Simulator */}
      <BPPulseExperience />

      {/* 2026-2050 Energy Outlook Scenario Modeler */}
      <EnergySimulator />

      {/* Financial Disciplines, Q3 2026 Results & Press Releases */}
      <NewsAndInvestors />

      {/* Global Corporate Footer */}
      <Footer />

      {/* bp Energy Intelligence AI Modal */}
      <EnergyAIAssistant isOpen={isAIOpen} onClose={() => setIsAIOpen(false)} />
    </main>
  );
}
