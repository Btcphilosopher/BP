/**
 * THERMAL OPTIMISATION OS - MAIN APPLICATION ENTRY COMPONENT
 */

import React, { useState, useEffect } from 'react';
import { BoilerState, OptimisationRun, RootCauseHypothesis, WorkOrder } from './types';
import { Header } from './components/Header';
import { BoilerHouseView } from './components/BoilerHouseView';
import { BoilerDetailView } from './components/BoilerDetailView';
import { HeatTransferView } from './components/HeatTransferView';
import { DiagnosticsView } from './components/DiagnosticsView';
import { OptimiserView } from './components/OptimiserView';
import { ScenariosView } from './components/ScenariosView';
import { KotlinOperatorView } from './components/KotlinOperatorView';
import { AiAssistantView } from './components/AiAssistantView';
import { ReportsView } from './components/ReportsView';
import { globalSimulation } from './lib/simulationEngine';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('control-centre');
  const [boilers, setBoilers] = useState<BoilerState[]>(globalSimulation.getBoilers());
  const [selectedBoilerId, setSelectedBoilerId] = useState<string>('BOILER-03');
  const [masterDemoStep, setMasterDemoStep] = useState<number>(1);
  const [activeDemoId, setActiveDemoId] = useState<number>(0);
  const [optimisationRun, setOptimisationRun] = useState<OptimisationRun>(
    globalSimulation.runOptimisation('COST_MINIMUM')
  );
  const [hypotheses, setHypotheses] = useState<RootCauseHypothesis[]>(
    globalSimulation.getDiagnosticsForBoiler('BOILER-03')
  );
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(globalSimulation.getWorkOrders());

  // Periodically fetch live state
  useEffect(() => {
    const interval = setInterval(() => {
      setBoilers([...globalSimulation.getBoilers()]);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Update diagnostics when selected boiler changes
  useEffect(() => {
    setHypotheses(globalSimulation.getDiagnosticsForBoiler(selectedBoilerId));
  }, [selectedBoilerId, boilers]);

  const handleRunMasterDemo = (demoId: number, step?: number) => {
    setActiveDemoId(demoId);
    const result = globalSimulation.runMasterDemo(demoId, step);
    setMasterDemoStep(result.masterDemo.step);
    setBoilers([...result.boilers]);
    if (result.optimisationRun) {
      setOptimisationRun(result.optimisationRun);
    }
  };

  const handleRunOptimisation = (objective: string) => {
    const res = globalSimulation.runOptimisation(objective as any);
    setOptimisationRun(res);
  };

  const selectedBoiler = boilers.find((b) => b.id === selectedBoilerId) || boilers[0];

  // Plant stats calculation
  const activeCount = boilers.filter((b) => b.status === 'ONLINE').length;
  const totalSteam = boilers.reduce((sum, b) => sum + b.steam_flow_th, 0);
  const totalFuelMw = boilers.reduce((sum, b) => sum + b.fuel_flow_kg_s * 47.1, 0);
  const avgEff = activeCount > 0 ? boilers.reduce((sum, b) => sum + b.boiler_efficiency_pct, 0) / boilers.length : 0;
  const totalCo2 = boilers.reduce((sum, b) => sum + b.co2_emission_rate_th, 0);
  const totalCostH = boilers.reduce((sum, b) => sum + b.fuel_cost_per_hour, 0);

  const plantData = {
    plantName: 'North Sea Process Plant & Refinery',
    status: 'OPERATIONAL',
    activeBoilers: `${activeCount} / ${boilers.length}`,
    totalSteam_th: Number(totalSteam.toFixed(1)),
    totalFuel_MW: Number(totalFuelMw.toFixed(1)),
    overallEfficiency_pct: Number(avgEff.toFixed(2)),
    co2EmissionRate_th: Number(totalCo2.toFixed(2)),
    fuelCostPerHour_gbp: Number(totalCostH.toFixed(2)),
    steamHeaderPressure_bar: 62.5,
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-amber-500 selection:text-slate-950 flex flex-col justify-between">
      <div>
        {/* Top Navigation & KPI Header */}
        <Header
          plantData={plantData}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          masterDemoStep={masterDemoStep}
          onRunMasterDemo={handleRunMasterDemo}
          activeDemoId={activeDemoId}
        />

        {/* Active Tab View Body */}
        <main className="max-w-7xl mx-auto px-4 py-6">
          {activeTab === 'control-centre' && (
            <BoilerHouseView
              boilers={boilers}
              selectedBoilerId={selectedBoilerId}
              setSelectedBoilerId={setSelectedBoilerId}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'boiler-detail' && <BoilerDetailView boiler={selectedBoiler} />}

          {activeTab === 'heat-recovery' && <HeatTransferView boiler={selectedBoiler} />}

          {activeTab === 'diagnostics' && <DiagnosticsView boiler={selectedBoiler} hypotheses={hypotheses} />}

          {activeTab === 'optimiser' && (
            <OptimiserView
              optimisationRun={optimisationRun}
              onRunOptimisation={handleRunOptimisation}
            />
          )}

          {activeTab === 'scenarios' && <ScenariosView />}

          {activeTab === 'operator-app' && <KotlinOperatorView workOrders={workOrders} />}

          {activeTab === 'ai-assistant' && <AiAssistantView />}

          {activeTab === 'reports' && <ReportsView boilers={boilers} />}
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-3 bg-slate-950 text-center text-xs font-mono text-slate-500">
        THERMAL OPTIMISATION OS • Industrial Scale Thermal Efficiency, Combustion Control & Digital Twin Platform
      </footer>
    </div>
  );
}

export default App;
