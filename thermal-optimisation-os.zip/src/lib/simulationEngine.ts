/**
 * THERMAL OPTIMISATION OS - INDUSTRIAL PLANT SIMULATION & DIGITAL TWIN ENGINE
 * Synthetic plant simulation representing the North Sea Process Plant (Boilers 01-05).
 */

import {
  BoilerConfig,
  BoilerState,
  BoilerRecommendation,
  OptimisationRun,
  RootCauseHypothesis,
  WorkOrder,
  AlarmItem,
  PriceConfig,
  MasterDemoState,
} from '../types';
import { calculateBoilerEfficiency, calculateStoichiometricAir, SYNTHETIC_FUELS } from './thermodynamics';

export const INITIAL_BOILERS: BoilerConfig[] = [
  {
    id: 'BOILER-01',
    name: 'Boiler 01 (Babcock High Pressure)',
    boilerHouseId: 'BH-01',
    manufacturer: 'Babcock & Wilcox',
    model: 'B&W FM-120',
    capacity_t_h: 220,
    designPressure_bar: 64,
    designTemperature_C: 450,
    designEfficiency: 92.8,
    fuelTypes: ['NATURAL_GAS', 'REFINERY_FUEL_GAS'],
    primaryFuel: 'NATURAL_GAS',
    burnerType: 'Low-NOx Dual Fuel Swirl Burner',
    minLoad_t_h: 40,
    maxLoad_t_h: 220,
    minO2Target: 1.8,
    maxO2Target: 3.5,
    maxNOxLimit_ppm: 80,
    maxCOLimit_ppm: 50,
    commissioningYear: 2018,
  },
  {
    id: 'BOILER-02',
    name: 'Boiler 02 (Foster Wheeler Utility)',
    boilerHouseId: 'BH-01',
    manufacturer: 'Foster Wheeler',
    model: 'FW-D-180',
    capacity_t_h: 200,
    designPressure_bar: 64,
    designTemperature_C: 440,
    designEfficiency: 93.5,
    fuelTypes: ['NATURAL_GAS', 'HYDROGEN_BLEND'],
    primaryFuel: 'NATURAL_GAS',
    burnerType: 'Low-NOx Staged Air Burner',
    minLoad_t_h: 35,
    maxLoad_t_h: 200,
    minO2Target: 1.6,
    maxO2Target: 3.2,
    maxNOxLimit_ppm: 75,
    maxCOLimit_ppm: 40,
    commissioningYear: 2020,
  },
  {
    id: 'BOILER-03',
    name: 'Boiler 03 (Mitsui Heavy Industrial)',
    boilerHouseId: 'BH-01',
    manufacturer: 'Mitsui-B&W',
    model: 'MBW-150',
    capacity_t_h: 180,
    designPressure_bar: 60,
    designTemperature_C: 430,
    designEfficiency: 91.2,
    fuelTypes: ['REFINERY_FUEL_GAS', 'NATURAL_GAS'],
    primaryFuel: 'REFINERY_FUEL_GAS',
    burnerType: 'Multi-nozzle Process Gas Burner',
    minLoad_t_h: 30,
    maxLoad_t_h: 180,
    minO2Target: 2.0,
    maxO2Target: 4.0,
    maxNOxLimit_ppm: 95,
    maxCOLimit_ppm: 60,
    commissioningYear: 2014,
  },
  {
    id: 'BOILER-04',
    name: 'Boiler 04 (Combustion Engineering High Eff)',
    boilerHouseId: 'BH-01',
    manufacturer: 'Combustion Engineering',
    model: 'CE-VU60',
    capacity_t_h: 250,
    designPressure_bar: 68,
    designTemperature_C: 460,
    designEfficiency: 94.2,
    fuelTypes: ['NATURAL_GAS', 'HYDROGEN_BLEND'],
    primaryFuel: 'HYDROGEN_BLEND',
    burnerType: 'Ultra-Low NOx Radiant Burner',
    minLoad_t_h: 50,
    maxLoad_t_h: 250,
    minO2Target: 1.5,
    maxO2Target: 2.8,
    maxNOxLimit_ppm: 50,
    maxCOLimit_ppm: 30,
    commissioningYear: 2022,
  },
  {
    id: 'BOILER-05',
    name: 'Boiler 05 (Aalborg Process Heat)',
    boilerHouseId: 'BH-01',
    manufacturer: 'Aalborg Industries',
    model: 'ALB-160',
    capacity_t_h: 160,
    designPressure_bar: 58,
    designTemperature_C: 420,
    designEfficiency: 91.8,
    fuelTypes: ['NATURAL_GAS', 'MIXED_FUEL_GAS'],
    primaryFuel: 'NATURAL_GAS',
    burnerType: 'Corner Fired Low-NOx Assembly',
    minLoad_t_h: 30,
    maxLoad_t_h: 160,
    minO2Target: 1.9,
    maxO2Target: 3.6,
    maxNOxLimit_ppm: 85,
    maxCOLimit_ppm: 45,
    commissioningYear: 2016,
  },
];

export const DEFAULT_PRICES: PriceConfig = {
  natural_gas_gbp_mwh: 48.5,
  refinery_gas_gbp_mwh: 38.0,
  electricity_gbp_mwh: 125.0,
  carbon_gbp_tonne: 75.0,
  water_gbp_m3: 2.8,
};

export class SimulationEngine {
  private boilers: BoilerState[] = [];
  private prices: PriceConfig = { ...DEFAULT_PRICES };
  private totalSteamDemand_th: number = 850;
  private masterDemo: MasterDemoState = {
    id: 0,
    title: 'Normal Steady State Operation',
    subtitle: 'North Sea Process Plant - 5 Boilers Online',
    description: 'All boilers operating within standard envelope with live digital twin synchronization.',
    step: 0,
    maxSteps: 5,
    active: false,
  };
  private workOrders: WorkOrder[] = [];
  private alarms: AlarmItem[] = [];

  constructor() {
    this.initBoilerStates();
    this.initDefaultAlarms();
  }

  private initBoilerStates() {
    const baseLoads = [180, 190, 150, 210, 120]; // Total = 850 t/h
    const baseEffs = [88.7, 91.2, 87.9, 93.1, 90.4];

    this.boilers = INITIAL_BOILERS.map((cfg, idx) => {
      const steamFlow = baseLoads[idx];
      const loadPct = (steamFlow / cfg.capacity_t_h) * 100;
      const fuelType = cfg.primaryFuel;
      const fuel = SYNTHETIC_FUELS[fuelType];

      // Steam & Fuel Flows
      const fuelEnergyMW = (steamFlow * 2.8) / (baseEffs[idx] / 100.0); // approx 2.8 GJ/tonne steam
      const fuelFlowKgS = fuelEnergyMW / fuel.lhv_mj_kg;
      const stoichAir = calculateStoichiometricAir(fuel);
      const excessAirPct = idx === 2 ? 28.5 : 18.2; // Boiler 3 higher excess air initially
      const airFlowKgS = fuelFlowKgS * stoichAir * (1 + excessAirPct / 100.0);
      const o2_pct = idx === 2 ? 4.8 : 2.4;

      const calcResult = calculateBoilerEfficiency(
        {
          id: cfg.id,
          load_pct: loadPct,
          stack_temperature_C: idx === 2 ? 185 : 142,
          ambient_temperature_C: 18,
          o2_pct: o2_pct,
          co_ppm: idx === 2 ? 65 : 22,
          fuel_flow_kg_s: fuelFlowKgS,
          blowdown_rate_pct: idx === 2 ? 3.2 : 1.8,
        },
        fuelType
      );

      return {
        id: cfg.id,
        name: cfg.name,
        status: 'ONLINE',
        load_pct: Number(loadPct.toFixed(1)),
        steam_flow_th: steamFlow,
        steam_pressure_bar: cfg.designPressure_bar - 1.5,
        steam_temperature_C: cfg.designTemperature_C - 5,
        fuel_flow_kg_s: Number(fuelFlowKgS.toFixed(2)),
        fuel_flow_m3_h: Number((fuelFlowKgS * 3600 / fuel.density_kg_m3).toFixed(1)),
        air_flow_kg_s: Number(airFlowKgS.toFixed(2)),
        air_fuel_ratio: Number((airFlowKgS / fuelFlowKgS).toFixed(2)),
        stoichiometric_air_ratio: Number(stoichAir.toFixed(2)),
        excess_air_pct: Number(excessAirPct.toFixed(1)),
        equivalence_ratio: Number((1.0 / (1 + excessAirPct / 100.0)).toFixed(2)),
        o2_pct: o2_pct,
        co_ppm: idx === 2 ? 65 : 22,
        co2_pct: Number((11.8 * (1 - o2_pct / 21)).toFixed(1)),
        nox_ppm: idx === 3 ? 38 : 62,
        stack_temperature_C: idx === 2 ? 185 : 142,
        ambient_temperature_C: 18,
        feedwater_flow_th: Number((steamFlow * 1.02).toFixed(1)),
        feedwater_temperature_C: idx === 2 ? 112 : 138,
        feedwater_pressure_bar: cfg.designPressure_bar + 12,
        drum_level_mm: 5.0,
        furnace_draft_mbar: -1.2,
        fan_speed_pct: Number((loadPct * 0.95).toFixed(1)),
        damper_position_pct: Number((loadPct * 0.92).toFixed(1)),
        flame_intensity_pct: Number((85 + Math.random() * 5).toFixed(1)),
        economiser_fw_in_C: 105,
        economiser_fw_out_C: idx === 2 ? 112 : 138,
        economiser_gas_in_C: idx === 2 ? 340 : 290,
        economiser_gas_out_C: idx === 2 ? 185 : 142,
        economiser_duty_MW: idx === 2 ? 3.1 : 5.8,
        economiser_effectiveness: idx === 2 ? 0.42 : 0.78,
        fouling_factor: idx === 2 ? 0.0038 : 0.0008,
        blowdown_rate_pct: idx === 2 ? 3.2 : 1.8,
        blowdown_flow_th: Number((steamFlow * 0.02).toFixed(2)),
        condensate_return_pct: 68.0,
        condensate_temp_C: 85,
        boiler_efficiency_pct: calcResult.boiler_efficiency_pct,
        combustion_efficiency_pct: calcResult.combustion_efficiency_pct,
        thermal_efficiency_pct: calcResult.thermal_efficiency_pct,
        stack_loss_pct: calcResult.stack_loss_pct,
        radiation_loss_pct: calcResult.radiation_loss_pct,
        blowdown_loss_pct: calcResult.blowdown_loss_pct,
        incomplete_combustion_loss_pct: calcResult.incomplete_combustion_loss_pct,
        auxiliary_power_kW: Number((fuelEnergyMW * 18).toFixed(1)),
        co2_emission_rate_th: Number((fuelFlowKgS * 3.6 * fuel.carbon_content_fraction * (44 / 12)).toFixed(2)),
        fuel_cost_per_hour: Number((fuelEnergyMW * this.prices.natural_gas_gbp_mwh).toFixed(2)),
        steam_cost_per_tonne: Number(((fuelEnergyMW * this.prices.natural_gas_gbp_mwh) / steamFlow).toFixed(2)),
        o2_quality: 'GOOD',
        stack_temp_quality: 'GOOD',
        economiser_fouled: idx === 2,
        burner_unstable: false,
        fan_degraded: false,
        lastUpdated: new Date().toISOString(),
      };
    });
  }

  private initDefaultAlarms() {
    this.alarms = [
      {
        id: 'ALM-101',
        boilerId: 'BOILER-03',
        boilerName: 'Boiler 03 (Mitsui Heavy)',
        title: 'HIGH STACK TEMPERATURE & ECONOMISER DEGRADATION',
        priority: 'HIGH',
        timestamp: new Date().toISOString(),
        acknowledged: false,
        category: 'HEAT_TRANSFER',
        value: '185°C (Target: <150°C)',
      },
      {
        id: 'ALM-102',
        boilerId: 'BOILER-03',
        boilerName: 'Boiler 03 (Mitsui Heavy)',
        title: 'EXCESS O2 HIGH PENALTY REGION',
        priority: 'MEDIUM',
        timestamp: new Date().toISOString(),
        acknowledged: false,
        category: 'COMBUSTION',
        value: '4.8% O2 (Target: 2.0%)',
      },
    ];
  }

  /**
   * Main Simulation Tick (Called every 500ms to simulate live process dynamics)
   */
  public tick() {
    this.boilers = this.boilers.map((b) => {
      if (b.status !== 'ONLINE') return b;

      // Small process noise
      const noiseTemp = (Math.random() - 0.5) * 0.4;
      const noiseO2 = (Math.random() - 0.5) * 0.04;
      const newStackTemp = Math.max(120, b.stack_temperature_C + noiseTemp);
      const newO2 = Math.max(1.2, b.o2_pct + noiseO2);

      const cfg = INITIAL_BOILERS.find((c) => c.id === b.id)!;
      const calc = calculateBoilerEfficiency(
        {
          id: b.id,
          load_pct: b.load_pct,
          stack_temperature_C: newStackTemp,
          ambient_temperature_C: b.ambient_temperature_C,
          o2_pct: newO2,
          co_ppm: b.co_ppm,
          fuel_flow_kg_s: b.fuel_flow_kg_s,
          blowdown_rate_pct: b.blowdown_rate_pct,
        },
        cfg.primaryFuel
      );

      return {
        ...b,
        stack_temperature_C: Number(newStackTemp.toFixed(1)),
        o2_pct: Number(newO2.toFixed(2)),
        boiler_efficiency_pct: calc.boiler_efficiency_pct,
        combustion_efficiency_pct: calc.combustion_efficiency_pct,
        stack_loss_pct: calc.stack_loss_pct,
        lastUpdated: new Date().toISOString(),
      };
    });
  }

  /**
   * Run Master Demonstrations (1 through 5)
   */
  public runMasterDemo(demoId: number, step?: number): {
    masterDemo: MasterDemoState;
    boilers: BoilerState[];
    optimisationRun?: OptimisationRun;
    diagnosticHypotheses?: RootCauseHypothesis[];
  } {
    this.masterDemo.id = demoId;
    this.masterDemo.active = true;
    const currentStep = step !== undefined ? step : (this.masterDemo.step % 5) + 1;
    this.masterDemo.step = currentStep;

    switch (demoId) {
      case 1: {
        // Master Demo 1: Steam Demand Spike & Economiser Recovery
        this.masterDemo.title = 'DEMO 1: Steam Demand Spike & Economiser Fouling Recovery';
        this.masterDemo.subtitle = 'Demand jumps to 1,000 t/h -> Boiler 03 overload -> Optimization & Maintenance';

        if (currentStep === 1) {
          this.masterDemo.description = 'Initial state: Steam demand at 850 t/h across 5 boilers.';
          this.totalSteamDemand_th = 850;
        } else if (currentStep === 2) {
          this.masterDemo.description = 'Step 2: Steam demand rises to 1,000 t/h. Boiler 03 takes extra load. O2 rises to 5.2%, stack temp to 192°C, efficiency drops.';
          this.totalSteamDemand_th = 1000;
          this.boilers[2].steam_flow_th = 175; // Boiler 3 forced load
          this.boilers[2].o2_pct = 5.2;
          this.boilers[2].stack_temperature_C = 192;
          this.boilers[2].boiler_efficiency_pct = 85.4;
          this.boilers[2].economiser_fouled = true;
        } else if (currentStep === 3) {
          this.masterDemo.description = 'Step 3: Root-cause engine identifies Economiser Fouling (+0.8pp) and High Excess Air (+0.6pp).';
        } else if (currentStep === 4) {
          this.masterDemo.description = 'Step 4: Multi-objective optimiser re-allocates load to high-efficiency Boiler 04 (CE 94.2%) and Boiler 02. Reduces Boiler 03 load.';
          this.boilers[2].steam_flow_th = 130;
          this.boilers[3].steam_flow_th = 245; // CE high eff takes load
          this.boilers[1].steam_flow_th = 195;
          this.boilers[2].o2_pct = 2.4;
          this.boilers[2].boiler_efficiency_pct = 89.2;
        } else if (currentStep === 5) {
          this.masterDemo.description = 'Step 5: Simulated economiser sootblowing/cleaning executed. Boiler 03 stack temp drops to 142°C, efficiency recovers to 91.8%. Total fuel cost saved: £450,000/yr.';
          this.boilers[2].stack_temperature_C = 142;
          this.boilers[2].economiser_effectiveness = 0.82;
          this.boilers[2].fouling_factor = 0.0006;
          this.boilers[2].boiler_efficiency_pct = 91.8;
          this.boilers[2].economiser_fouled = false;
        }
        break;
      }

      case 2: {
        // Master Demo 2: Boiler Trip Event & Emergency Re-dispatch
        this.masterDemo.title = 'DEMO 2: Boiler 02 Trip & Emergency Capacity Re-dispatch';
        this.masterDemo.subtitle = 'Boiler 02 experiences flame loss trip -> 190 t/h steam deficit -> Automated emergency reallocation';

        if (currentStep <= 2) {
          this.masterDemo.description = 'CRITICAL ALARM: BOILER-02 FLAME TRIP DETECTED. Steam capacity lost: 190 t/h.';
          this.boilers[1].status = 'TRIPPED';
          this.boilers[1].steam_flow_th = 0;
          this.boilers[1].fuel_flow_kg_s = 0;
          this.boilers[1].boiler_efficiency_pct = 0;
        } else {
          this.masterDemo.description = 'Optimiser calculates emergency dispatch: Ramping Boiler 01, 04, and 05 within spinning reserve limits to restore 1,000 t/h header pressure.';
          this.boilers[0].steam_flow_th = 215;
          this.boilers[3].steam_flow_th = 248;
          this.boilers[4].steam_flow_th = 155;
          this.boilers[2].steam_flow_th = 160;
        }
        break;
      }

      case 3: {
        // Master Demo 3: High Fuel Price Shift (+35% Natural Gas)
        this.masterDemo.title = 'DEMO 3: Fuel Price Spike (+35% Natural Gas)';
        this.masterDemo.subtitle = 'Natural gas rises from £48.5 to £65.5/MWh -> Dispatch shifts towards Refinery Fuel Gas & H2 Blend';

        if (currentStep <= 2) {
          this.prices.natural_gas_gbp_mwh = 65.5;
          this.masterDemo.description = 'Natural gas price increased by 35% to £65.50/MWh. Calculating marginal cost of steam per unit.';
        } else {
          this.masterDemo.description = 'Optimiser shifts base load to Boiler 03 (Refinery Fuel Gas @ £38/MWh) and Boiler 04 (Hydrogen blend), saving £1,840/hour in fuel costs.';
          this.boilers[2].steam_flow_th = 175; // Refinery gas unit maxed out
          this.boilers[0].steam_flow_th = 140; // Reduced NG unit
        }
        break;
      }

      case 4: {
        // Master Demo 4: Oxygen Sensor Failure & Anomaly Detection
        this.masterDemo.title = 'DEMO 4: O2 Analyser Drift Anomaly & Safety Lock';
        this.masterDemo.subtitle = 'Boiler 01 O2 sensor drifts to 6.2% -> Sensor marked UNCERTAIN -> Alternate state estimator deployed';

        if (currentStep <= 2) {
          this.masterDemo.description = 'Boiler 01 O2 analyser reads 6.2% O2. Diagnostic engine detects discrepancy with fan speed & CO2 balance.';
          this.boilers[0].o2_pct = 6.2;
          this.boilers[0].o2_quality = 'SENSOR_FAULT';
        } else {
          this.masterDemo.description = 'System isolates faulty sensor, estimates true O2 (2.1%) from stoichiometric air/fuel model, alerts maintenance, and prevents dangerous air over-trimming.';
          this.boilers[0].o2_quality = 'ESTIMATED';
        }
        break;
      }

      case 5: {
        // Master Demo 5: Economiser Fouling Economics & Work Order ROI
        this.masterDemo.title = 'DEMO 5: Predictive Maintenance & Economiser Fouling ROI';
        this.masterDemo.subtitle = 'Fouling factor increases -> Stack temperature +28°C -> Work order ROI calculated at 64 days payback';

        this.masterDemo.description = 'Work order WO-2026-88 generated: Cleaning Boiler 03 economiser costs £80,000, yields £450,000 annual fuel saving with 64-day payback.';
        this.boilers[2].economiser_fouled = true;
        this.boilers[2].fouling_factor = 0.0042;
        break;
      }
    }

    const optRun = this.runOptimisation('COST_MINIMUM');
    const diagHyp = this.getDiagnosticsForBoiler('BOILER-03');

    return {
      masterDemo: this.masterDemo,
      boilers: this.getBoilers(),
      optimisationRun: optRun,
      diagnosticHypotheses: diagHyp,
    };
  }

  /**
   * Run Multi-Objective Optimisation Engine
   */
  public runOptimisation(objective: 'FUEL_MINIMUM' | 'COST_MINIMUM' | 'CO2_MINIMUM' | 'EMISSIONS_CONSTRAINED' | 'EQUIPMENT_LIFE' | 'BALANCED' = 'COST_MINIMUM'): OptimisationRun {
    const totalSteam = this.totalSteamDemand_th;
    const activeBoilers = this.boilers.filter((b) => b.status === 'ONLINE');

    let currentCostH = 0;
    this.boilers.forEach((b) => {
      currentCostH += b.fuel_cost_per_hour;
    });

    // Compute optimal load distribution based on design efficiency curves
    const recommendations: BoilerRecommendation[] = activeBoilers.map((b) => {
      const cfg = INITIAL_BOILERS.find((c) => c.id === b.id)!;
      // High efficiency boilers (CE VU60 & Foster Wheeler) get higher load fraction
      let targetLoadTh = totalSteam / activeBoilers.length;

      if (objective === 'COST_MINIMUM' || objective === 'FUEL_MINIMUM') {
        if (cfg.designEfficiency > 93.0) {
          targetLoadTh = Math.min(cfg.capacity_t_h * 0.92, totalSteam * 0.28);
        } else if (cfg.designEfficiency < 92.0) {
          targetLoadTh = Math.max(cfg.minLoad_t_h, totalSteam * 0.15);
        }
      }

      const currentO2 = b.o2_pct;
      const targetO2 = cfg.minO2Target + 0.3; // Safe target with +0.3% margin
      const o2Diff = Math.max(0, currentO2 - targetO2);
      const effGainPP = o2Diff * 0.45 + (b.economiser_fouled ? 1.2 : 0.0);
      const hourlySavingGbp = (b.fuel_cost_per_hour * effGainPP) / 100.0;

      return {
        boilerId: b.id,
        boilerName: b.name,
        current_load_th: b.steam_flow_th,
        recommended_load_th: Number(targetLoadTh.toFixed(1)),
        current_o2_pct: b.o2_pct,
        recommended_o2_pct: Number(targetO2.toFixed(2)),
        current_air_fuel_ratio: b.air_fuel_ratio,
        recommended_air_fuel_ratio: Number((b.air_fuel_ratio * (1 - o2Diff / 21)).toFixed(2)),
        expected_efficiency_gain_pp: Number(effGainPP.toFixed(2)),
        expected_cost_saving_gbp_h: Number(hourlySavingGbp.toFixed(2)),
        explanation: `Reduce excess air from ${b.o2_pct}% to ${targetO2.toFixed(1)}% O2 and adjust load dispatch to max-efficiency operating point.`,
        status: 'PENDING',
      };
    });

    const totalHourlySavings = recommendations.reduce((sum, r) => sum + r.expected_cost_saving_gbp_h, 0);
    const annualSavings = totalHourlySavings * 8760;
    const co2ReductionTy = (annualSavings / 220).toFixed(1);

    return {
      id: `OPT-${Date.now()}`,
      timestamp: new Date().toISOString(),
      objective,
      total_steam_demand_th: totalSteam,
      current_total_fuel_cost_gbp_h: Number(currentCostH.toFixed(2)),
      optimised_total_fuel_cost_gbp_h: Number((currentCostH - totalHourlySavings).toFixed(2)),
      expected_hourly_savings_gbp: Number(totalHourlySavings.toFixed(2)),
      expected_annual_savings_gbp: Number(annualSavings.toFixed(2)),
      expected_co2_reduction_t_y: Number(co2ReductionTy),
      constraints_checked: {
        combustion_stability: true,
        emissions_limits: true,
        minimum_safe_air: true,
        burner_turndown: true,
        steam_header_pressure: true,
      },
      recommendations,
    };
  }

  /**
   * Diagnostic Engine for Root Cause Analysis
   */
  public getDiagnosticsForBoiler(boilerId: string): RootCauseHypothesis[] {
    const b = this.boilers.find((item) => item.id === boilerId);
    if (!b) return [];

    const hypotheses: RootCauseHypothesis[] = [];

    if (b.stack_temperature_C > 160 || b.economiser_fouled) {
      hypotheses.push({
        id: 'HYP-01',
        boilerId,
        title: 'Economiser Tube Gas-Side Fouling',
        description: 'Soot/ash accumulation on economiser external fins reducing heat transfer coefficient U by 38%.',
        probability: 0.88,
        confidence: 0.92,
        efficiency_impact_pp: -1.2,
        economic_impact_gbp_day: 1240,
        evidence: [
          `Stack gas temperature elevated at ${b.stack_temperature_C}°C (Design: 140°C)`,
          `Feedwater temperature rise across economiser only ${b.economiser_fw_out_C - b.economiser_fw_in_C}°C (Design: +35°C)`,
          `Flue gas pressure drop across economiser bank increased by 2.8 mbar`,
        ],
        recommended_action: 'Schedule online acoustic sootblowing or manual tube washing during upcoming outage.',
        category: 'HEAT_TRANSFER',
      });
    }

    if (b.o2_pct > 3.8) {
      hypotheses.push({
        id: 'HYP-02',
        boilerId,
        title: 'Excess Air Damper Calibration Drift',
        description: 'Forced draft fan damper position misalignment introducing +35% excess air above stoichiometric requirement.',
        probability: 0.76,
        confidence: 0.85,
        efficiency_impact_pp: -0.7,
        economic_impact_gbp_day: 780,
        evidence: [
          `Measured flue gas O2 at ${b.o2_pct}% (Configured target: 2.0%)`,
          `Fan speed at ${b.fan_speed_pct}% out of proportion with fuel demand`,
          `Calculated adiabatic flame temperature suppressed by 120°C`,
        ],
        recommended_action: 'Perform O2 trim curve recalibration and inspect damper linkage stiction.',
        category: 'COMBUSTION',
      });
    }

    if (b.blowdown_rate_pct > 2.5) {
      hypotheses.push({
        id: 'HYP-03',
        boilerId,
        title: 'Continuous Blowdown Valve Over-Blow',
        description: 'Blowdown rate set to 3.2% vs target 1.5%, dumping high-enthalpy boiler water to flash vessel.',
        probability: 0.65,
        confidence: 0.78,
        efficiency_impact_pp: -0.3,
        economic_impact_gbp_day: 310,
        evidence: [
          `Blowdown mass flow at ${b.blowdown_flow_th} t/h`,
          `Boiler water TDS at 1,800 ppm (Upper limit: 2,500 ppm)`,
        ],
        recommended_action: 'Throttle blowdown control valve to maintain TDS at 2,200 ppm.',
        category: 'BLOWDOWN',
      });
    }

    return hypotheses;
  }

  /**
   * Getters
   */
  public getBoilers(): BoilerState[] {
    return this.boilers;
  }

  public getMasterDemo(): MasterDemoState {
    return this.masterDemo;
  }

  public getPrices(): PriceConfig {
    return this.prices;
  }

  public setPrices(newPrices: Partial<PriceConfig>) {
    this.prices = { ...this.prices, ...newPrices };
  }

  public getAlarms(): AlarmItem[] {
    return this.alarms;
  }

  public getWorkOrders(): WorkOrder[] {
    if (this.workOrders.length === 0) {
      this.workOrders = [
        {
          id: 'WO-2026-88',
          boilerId: 'BOILER-03',
          title: 'Economiser Tube Cleaning & Sootblowing Inspection',
          component: 'Economiser Fin Bank 02',
          priority: 'HIGH',
          status: 'IN_PROGRESS',
          created_at: '2026-09-14T10:30:00Z',
          assigned_to: 'J. Miller (Lead Maintenance Engineer)',
          description: 'Perform gas-side sootblowing and fin washing on Boiler 03 economiser to recover 1.2pp efficiency loss.',
          checklist: [
            { task: 'Isolate gas-side bypass dampers and log LOTO', completed: true },
            { task: 'Inspect economiser tube fins for fly-ash fouling', completed: true },
            { task: 'Execute high-pressure water wash / acoustic sootblowing', completed: false },
            { task: 'Verify pressure drop restored to <3.5 mbar', completed: false },
            { task: 'Perform post-maintenance Digital Twin thermal verification', completed: false },
          ],
          expected_payback_days: 64,
          before_efficiency_pct: 87.9,
          after_efficiency_pct: 91.8,
        },
      ];
    }
    return this.workOrders;
  }
}

export const globalSimulation = new SimulationEngine();
