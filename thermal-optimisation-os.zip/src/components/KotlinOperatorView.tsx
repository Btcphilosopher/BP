/**
 * THERMAL OPTIMISATION OS - SIMULATED KOTLIN / JETPACK COMPOSE FIELD OPERATOR APP
 * Industrial Tablet Interface for Field Engineers & Maintenance Crews
 */

import React, { useState } from 'react';
import { WorkOrder } from '../types';
import { Tablet, CheckSquare, Square, Wrench, ShieldCheck, Wifi, HardDrive, ArrowRight } from 'lucide-react';

interface KotlinOperatorViewProps {
  workOrders: WorkOrder[];
}

export const KotlinOperatorView: React.FC<KotlinOperatorViewProps> = ({ workOrders }) => {
  const [activeWo, setActiveWo] = useState<WorkOrder>(workOrders[0]);
  const [checklist, setChecklist] = useState(activeWo.checklist);

  const toggleTask = (index: number) => {
    const updated = [...checklist];
    updated[index].completed = !updated[index].completed;
    setChecklist(updated);
  };

  const completedCount = checklist.filter((item) => item.completed).length;

  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Tablet className="w-5 h-5 text-sky-400" /> KOTLIN / JETPACK COMPOSE FIELD OPERATOR TABLET APP
          </h2>
          <p className="text-xs text-slate-400">
            Simulated Android Material 3 Industrial App running Jetpack Compose & Room DB Offline Cache
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 flex items-center gap-1">
            <Wifi className="w-3 h-3 text-emerald-400" /> LOCAL MESH WI-FI
          </span>
          <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 flex items-center gap-1">
            <HardDrive className="w-3 h-3 text-sky-400" /> ROOM DB SYNCED
          </span>
        </div>
      </div>

      {/* Simulated Industrial Tablet Frame */}
      <div className="max-w-4xl mx-auto bg-slate-950 border-4 border-slate-800 rounded-2xl p-6 shadow-2xl font-mono text-xs">
        
        {/* Android Status Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4 text-slate-400">
          <span className="font-bold text-sky-400">NORTH SEA REFINE OPERATOR v3.6</span>
          <span>WO-2026-88 • BOILER-03</span>
          <span>10:42 AM</span>
        </div>

        {/* Work Order Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800 font-bold mr-2">
                PRIORITY: {activeWo.priority}
              </span>
              <h3 className="text-sm font-bold text-slate-100 inline">{activeWo.title}</h3>
            </div>
            <div className="text-slate-400 text-[11px]">Assigned: {activeWo.assigned_to}</div>
          </div>

          <p className="text-slate-300 text-xs font-sans">{activeWo.description}</p>

          {/* Checklist Execution */}
          <div className="space-y-2 pt-2">
            <div className="flex justify-between items-center text-slate-400 mb-1">
              <span className="font-bold text-amber-400">FIELD MAINTENANCE CHECKLIST ({completedCount}/{checklist.length})</span>
              <span>{Math.round((completedCount / checklist.length) * 100)}% COMPLETE</span>
            </div>

            <div className="space-y-1.5">
              {checklist.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => toggleTask(idx)}
                  className={`p-3 rounded-lg border cursor-pointer transition flex items-center justify-between ${
                    item.completed
                      ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5 font-sans">
                    {item.completed ? (
                      <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500 shrink-0" />
                    )}
                    <span className={item.completed ? 'line-through text-slate-400' : ''}>{item.task}</span>
                  </div>

                  <span className="text-[10px] text-slate-500">{item.completed ? 'DONE' : 'PENDING'}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Before / After Thermal Performance Verification */}
          <div className="pt-4 border-t border-slate-800 grid grid-cols-2 gap-4">
            <div className="p-3 bg-slate-950 rounded border border-slate-800">
              <div className="text-slate-400 text-[10px]">BEFORE CLEANING EFFICIENCY:</div>
              <div className="text-sm font-bold text-red-400">{activeWo.before_efficiency_pct}%</div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-emerald-800">
              <div className="text-slate-400 text-[10px]">EXPECTED AFTER CLEANING:</div>
              <div className="text-sm font-bold text-emerald-400">{activeWo.after_efficiency_pct}% (+3.9pp)</div>
            </div>
          </div>

          <div className="p-3 bg-amber-950/40 border border-amber-800 rounded text-amber-300 text-xs font-sans flex items-center justify-between">
            <span>Payback Period: <strong>{activeWo.expected_payback_days} Days</strong></span>
            <span className="font-bold flex items-center gap-1">VERIFY ON DIGITAL TWIN <ArrowRight className="w-3.5 h-3.5" /></span>
          </div>
        </div>

      </div>
    </div>
  );
};
