/**
 * THERMAL OPTIMISATION OS - BOILER HOUSE FLEET OVERVIEW
 */

import React from 'react';
import { BoilerState } from '../types';
import { SankeyDiagram } from './SankeyDiagram';
import { ProcessDiagram } from './ProcessDiagram';
import { calculateBoilerEfficiency } from '../lib/thermodynamics';
import { Flame, Gauge, AlertTriangle, ArrowUpRight, ShieldCheck, Thermometer } from 'lucide-react';

interface BoilerHouseViewProps {
  boilers: BoilerState[];
  selectedBoilerId: string;
  setSelectedBoilerId: (id: string) => void;
  onNavigateTab: (tab: string) => void;
}

export const BoilerHouseView: React.FC<BoilerHouseViewProps> = ({
  boilers,
  selectedBoilerId,
  setSelectedBoilerId,
  onNavigateTab,
}) => {
  const selectedBoiler = boilers.find((b) => b.id === selectedBoilerId) || boilers[0];
  const heatBalanceResult = calculateBoilerEfficiency(selectedBoiler, 'NATURAL_GAS').heatBalance;

  return (
    <div className="space-y-6 font-sans">
      {/* Fleet Grid */}
      <div>
        <h2 className="text-xs font-bold text-slate-400 tracking-wider uppercase mb-3 flex items-center justify-between">
          <span>NORTH SEA PROCESS PLANT - BOILER HOUSE 01 FLEET (5 UNITS)</span>
          <span className="text-slate-500 font-mono">SELECT A BOILER FOR DIGITAL TWIN INSPECTION</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {boilers.map((b) => {
            const isSelected = b.id === selectedBoilerId;
            return (
              <div
                key={b.id}
                onClick={() => setSelectedBoilerId(b.id)}
                className={`cursor-pointer rounded-xl p-3.5 border transition relative overflow-hidden font-mono text-xs ${
                  isSelected
                    ? 'bg-slate-850 border-amber-500 shadow-lg shadow-amber-950/40 ring-1 ring-amber-500/50'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
                }`}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-slate-100">{b.id}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      b.status === 'ONLINE'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-red-950 text-red-400 border border-red-800'
                    }`}
                  >
                    {b.status}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 font-sans truncate mb-3">{b.name}</div>

                {/* Steam Load Progress */}
                <div className="space-y-1 mb-3">
                  <div className="flex justify-between text-slate-300">
                    <span>Steam Load:</span>
                    <span className="font-bold text-cyan-400">{b.steam_flow_th} t/h</span>
                  </div>
                  <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(b.load_pct, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Metrics */}
                <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                  <div className="flex justify-between text-slate-300">
                    <span>Efficiency:</span>
                    <span className="font-bold text-emerald-400">{b.boiler_efficiency_pct}%</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>O₂ Analyser:</span>
                    <span className="font-bold text-cyan-300">{b.o2_pct}%</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Stack Temp:</span>
                    <span className={`font-bold ${b.stack_temperature_C > 160 ? 'text-red-400' : 'text-amber-300'}`}>
                      {b.stack_temperature_C}°C
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Cost / Hour:</span>
                    <span className="font-bold text-amber-400">£{b.fuel_cost_per_hour.toLocaleString()}</span>
                  </div>
                </div>

                {b.economiser_fouled && (
                  <div className="mt-2 text-[10px] bg-red-950/80 text-red-300 border border-red-800 px-1.5 py-0.5 rounded flex items-center gap-1 font-sans">
                    <AlertTriangle className="w-3 h-3 text-red-400" /> Fouling Alert
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Boiler Detail Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <ProcessDiagram boiler={selectedBoiler} />
        </div>

        <div>
          <SankeyDiagram heatBalance={heatBalanceResult} />

          {/* Quick Action Box */}
          <div className="mt-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2 text-xs font-mono">
            <h4 className="font-bold text-amber-400 mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> BOILER ACTIONS & DIAGNOSTICS
            </h4>
            <button
              onClick={() => onNavigateTab('boiler-detail')}
              className="w-full text-left px-3 py-2 rounded bg-slate-800 hover:bg-slate-750 text-slate-200 flex items-center justify-between transition border border-slate-700"
            >
              <span>View Combustion & Cross-Limiting</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
            <button
              onClick={() => onNavigateTab('diagnostics')}
              className="w-full text-left px-3 py-2 rounded bg-slate-800 hover:bg-slate-750 text-slate-200 flex items-center justify-between transition border border-slate-700"
            >
              <span>View Root-Cause Diagnostics</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
            <button
              onClick={() => onNavigateTab('heat-recovery')}
              className="w-full text-left px-3 py-2 rounded bg-slate-800 hover:bg-slate-750 text-slate-200 flex items-center justify-between transition border border-slate-700"
            >
              <span>View Economiser & Heat Recovery</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
