/**
 * THERMAL OPTIMISATION OS - HEADER & PLANT KPI BAR
 */

import React from 'react';
import {
  Flame,
  Activity,
  Gauge,
  TrendingDown,
  DollarSign,
  AlertTriangle,
  Layers,
  Play,
  RotateCcw,
  Zap,
} from 'lucide-react';

interface HeaderProps {
  plantData: {
    plantName: string;
    status: string;
    activeBoilers: string;
    totalSteam_th: number;
    totalFuel_MW: number;
    overallEfficiency_pct: number;
    co2EmissionRate_th: number;
    fuelCostPerHour_gbp: number;
    steamHeaderPressure_bar: number;
  };
  activeTab: string;
  setActiveTab: (tab: string) => void;
  masterDemoStep: number;
  onRunMasterDemo: (demoId: number, step?: number) => void;
  activeDemoId: number;
}

export const Header: React.FC<HeaderProps> = ({
  plantData,
  activeTab,
  setActiveTab,
  masterDemoStep,
  onRunMasterDemo,
  activeDemoId,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 font-bold shadow-md shadow-orange-900/30">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight text-slate-100 flex items-center gap-2">
              THERMAL OPTIMISATION OS
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800 font-mono">
                {plantData.status}
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Industrial Boiler Efficiency & Digital Twin Platform • North Sea Process Plant
            </p>
          </div>
        </div>

        {/* Master Demo Selector Bar */}
        <div className="flex items-center gap-2 bg-slate-950/70 p-1.5 rounded-lg border border-slate-800 text-xs">
          <span className="text-amber-400 font-semibold px-2 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5" /> MASTER DEMOS:
          </span>
          <select
            value={activeDemoId}
            onChange={(e) => onRunMasterDemo(Number(e.target.value), 1)}
            className="bg-slate-900 border border-slate-700 text-slate-200 rounded px-2 py-1 focus:outline-none focus:border-amber-500 text-xs font-mono"
          >
            <option value={0}>0: Normal Steady State</option>
            <option value={1}>1: Steam Demand Spike & Economiser Recovery</option>
            <option value={2}>2: Boiler 02 Flame Trip Emergency</option>
            <option value={3}>3: Natural Gas Price Spike (+35%)</option>
            <option value={4}>4: O2 Sensor Drift Anomaly Lock</option>
            <option value={5}>5: Economiser Fouling & Work Order ROI</option>
          </select>

          <button
            onClick={() => onRunMasterDemo(activeDemoId || 1, masterDemoStep + 1)}
            className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-slate-950 font-semibold rounded transition flex items-center gap-1 shadow-sm"
          >
            <Play className="w-3 h-3" /> Step {masterDemoStep}/5
          </button>
        </div>
      </div>

      {/* High-Density Plant KPI Bar */}
      <div className="bg-slate-950 border-t border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 py-2 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-xs font-mono">
          <div className="p-1.5 rounded bg-slate-900/60 border border-slate-800/50">
            <div className="text-slate-400 flex items-center gap-1">
              <Layers className="w-3 h-3 text-sky-400" /> BOILER FLEET
            </div>
            <div className="text-sm font-bold text-slate-100">{plantData.activeBoilers}</div>
          </div>

          <div className="p-1.5 rounded bg-slate-900/60 border border-slate-800/50">
            <div className="text-slate-400 flex items-center gap-1">
              <Gauge className="w-3 h-3 text-cyan-400" /> TOTAL STEAM
            </div>
            <div className="text-sm font-bold text-cyan-400">{plantData.totalSteam_th} t/h</div>
          </div>

          <div className="p-1.5 rounded bg-slate-900/60 border border-slate-800/50">
            <div className="text-slate-400 flex items-center gap-1">
              <Flame className="w-3 h-3 text-orange-400" /> FUEL INPUT
            </div>
            <div className="text-sm font-bold text-orange-400">{plantData.totalFuel_MW} MW</div>
          </div>

          <div className="p-1.5 rounded bg-slate-900/60 border border-slate-800/50">
            <div className="text-slate-400 flex items-center gap-1">
              <Activity className="w-3 h-3 text-emerald-400" /> EFFICIENCY
            </div>
            <div className="text-sm font-bold text-emerald-400">{plantData.overallEfficiency_pct}%</div>
          </div>

          <div className="p-1.5 rounded bg-slate-900/60 border border-slate-800/50">
            <div className="text-slate-400 flex items-center gap-1">
              <TrendingDown className="w-3 h-3 text-purple-400" /> CO₂ RATE
            </div>
            <div className="text-sm font-bold text-purple-300">{plantData.co2EmissionRate_th} t/h</div>
          </div>

          <div className="p-1.5 rounded bg-slate-900/60 border border-slate-800/50">
            <div className="text-slate-400 flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-amber-400" /> FUEL COST/HR
            </div>
            <div className="text-sm font-bold text-amber-400">£{plantData.fuelCostPerHour_gbp.toLocaleString()}</div>
          </div>

          <div className="p-1.5 rounded bg-slate-900/60 border border-slate-800/50">
            <div className="text-slate-400 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3 text-blue-400" /> HEADER PRESS.
            </div>
            <div className="text-sm font-bold text-slate-100">{plantData.steamHeaderPressure_bar} bar</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <nav className="max-w-7xl mx-auto px-4 flex items-center gap-1 overflow-x-auto text-xs py-1 scrollbar-none">
        {[
          { id: 'control-centre', label: '📊 Control Centre Digital Twin' },
          { id: 'boiler-detail', label: '⚡ Combustion & Cross-Limiting' },
          { id: 'heat-recovery', label: '🌡️ Economiser & Heat Recovery' },
          { id: 'diagnostics', label: '🔍 Root-Cause Diagnostics' },
          { id: 'optimiser', label: '🎯 Multi-Objective Dispatch' },
          { id: 'scenarios', label: '🧪 Scenarios & Monte Carlo' },
          { id: 'operator-app', label: '🛠️ Kotlin Field Operator App' },
          { id: 'ai-assistant', label: '🤖 Thermal AI Assistant' },
          { id: 'reports', label: '📑 Reports & OpenAPI Spec' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-1.5 rounded-t font-medium whitespace-nowrap transition border-t-2 ${
              activeTab === tab.id
                ? 'bg-slate-800 text-amber-400 border-amber-500 font-semibold'
                : 'text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </nav>
    </header>
  );
};
