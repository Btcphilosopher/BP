/**
 * THERMAL OPTIMISATION OS - SANKEY HEAT ENERGY BALANCE
 * Live energy balance visualization: Fuel Input -> Useful Steam + Stack Loss + Radiation + Blowdown + CO
 */

import React, { useState } from 'react';
import { HeatBalance } from '../types';
import { convertUnits } from '../lib/thermodynamics';
import { Flame, ArrowRight, Zap, RefreshCw } from 'lucide-react';

interface SankeyDiagramProps {
  heatBalance: HeatBalance;
}

export const SankeyDiagram: React.FC<SankeyDiagramProps> = ({ heatBalance }) => {
  const [unit, setUnit] = useState<'MW' | 'MMBtu_h' | 'GJ_h' | 'PCT'>('MW');

  const totalFuel = heatBalance.total_fuel_energy_MW;

  const formatVal = (mwVal: number) => {
    if (unit === 'PCT') {
      return `${((mwVal / totalFuel) * 100).toFixed(1)}%`;
    }
    const val = convertUnits(mwVal, 'MW', unit);
    const unitLabel = unit === 'MMBtu_h' ? 'MMBtu/h' : unit === 'GJ_h' ? 'GJ/h' : 'MW';
    return `${val.toFixed(1)} ${unitLabel}`;
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl text-slate-100 font-sans">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" /> SANKEY HEAT ENERGY BALANCE
          </h3>
          <p className="text-xs text-slate-400">
            Calculated ASME loss method heat cascade for {heatBalance.boilerId}.
          </p>
        </div>

        {/* Unit Selector */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded border border-slate-800 text-xs font-mono">
          {(['MW', 'MMBtu_h', 'GJ_h', 'PCT'] as const).map((u) => (
            <button
              key={u}
              onClick={() => setUnit(u)}
              className={`px-2 py-0.5 rounded transition ${
                unit === u ? 'bg-amber-600 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {u === 'MMBtu_h' ? 'MMBtu/h' : u === 'GJ_h' ? 'GJ/h' : u === 'PCT' ? '%' : 'MW'}
            </button>
          ))}
        </div>
      </div>

      {/* Visual Sankey Energy Cascade */}
      <div className="space-y-3 font-mono text-xs">
        {/* Total Fuel Input */}
        <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-lg flex items-center justify-between">
          <span className="font-bold text-amber-300 flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400" /> TOTAL FUEL HEAT INPUT
          </span>
          <span className="text-sm font-bold text-amber-400">{formatVal(heatBalance.total_fuel_energy_MW)}</span>
        </div>

        {/* Flow Division Bars */}
        <div className="pl-4 border-l-2 border-amber-500/40 space-y-2 py-1">
          {/* Useful Steam Output */}
          <div className="p-2.5 bg-emerald-950/40 border border-emerald-800/60 rounded flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowRight className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-300 font-semibold">Useful Steam Energy Output</span>
            </div>
            <span className="font-bold text-emerald-400">{formatVal(heatBalance.useful_steam_energy_MW)}</span>
          </div>

          {/* Stack Loss */}
          <div className="p-2.5 bg-red-950/30 border border-red-800/40 rounded flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowRight className="w-3.5 h-3.5 text-red-400" />
              <span className="text-red-300">Flue Gas Stack Loss</span>
            </div>
            <span className="font-bold text-red-400">{formatVal(heatBalance.stack_loss_MW)}</span>
          </div>

          {/* Radiation & Convection */}
          <div className="p-2.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-300">Radiation & Convection Casing Loss</span>
            </div>
            <span className="font-bold text-slate-300">{formatVal(heatBalance.radiation_convection_loss_MW)}</span>
          </div>

          {/* Blowdown Heat Loss */}
          <div className="p-2.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowRight className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-slate-300">Continuous Blowdown Water Heat Loss</span>
            </div>
            <span className="font-bold text-blue-400">{formatVal(heatBalance.blowdown_loss_MW)}</span>
          </div>

          {/* Incomplete Combustion */}
          <div className="p-2.5 bg-slate-950 border border-slate-800 rounded flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowRight className="w-3.5 h-3.5 text-purple-400" />
              <span className="text-slate-300">Incomplete Combustion (CO) Loss</span>
            </div>
            <span className="font-bold text-purple-400">{formatVal(heatBalance.incomplete_combustion_loss_MW)}</span>
          </div>
        </div>

        {/* Overall Thermal Efficiency */}
        <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between pt-2">
          <span className="text-slate-400">Net Thermal Efficiency:</span>
          <span className="text-base font-bold text-emerald-400">{heatBalance.efficiency_pct}%</span>
        </div>
      </div>
    </div>
  );
};
