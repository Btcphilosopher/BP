/**
 * THERMAL OPTIMISATION OS - INTERACTIVE DIGITAL TWIN PROCESS FLOW DIAGRAM
 * Physical thermal animated schematic: Fuel -> Burner -> Furnace -> Boiler Tubes -> Steam Drum;
 * Flue Gas -> Economiser -> Air Preheater -> Stack.
 */

import React, { useState } from 'react';
import { BoilerState } from '../types';
import { Flame, Wind, Droplets, Thermometer, Gauge, AlertCircle, CheckCircle2 } from 'lucide-react';

interface ProcessDiagramProps {
  boiler: BoilerState;
}

export const ProcessDiagram: React.FC<ProcessDiagramProps> = ({ boiler }) => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);

  const isFouled = boiler.economiser_fouled;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl text-slate-100 font-sans relative overflow-hidden">
      {/* Title Bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div>
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            DIGITAL TWIN ANIMATED SCHEMATIC: {boiler.name}
            <span className="text-xs px-2 py-0.5 rounded bg-sky-950 text-sky-400 border border-sky-800 font-mono">
              REAL-TIME SIMULATION TICK
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Physical combustion thermal path, heat transfer surfaces, steam drum & flue gas stack.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="text-slate-400">Load:</span>
          <span className="font-bold text-cyan-400">{boiler.load_pct}%</span>
          <span className="text-slate-400">({boiler.steam_flow_th} t/h)</span>
        </div>
      </div>

      {/* Process Flow Canvas SVG/HTML Layer */}
      <div className="relative bg-slate-950 rounded-lg p-6 border border-slate-800 min-h-[380px] flex flex-col justify-between">
        
        {/* Animated Particle Stream Lines */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative z-10">
          
          {/* 1. FUEL & AIR INLET / BURNER */}
          <div
            onClick={() => setSelectedNode('BURNER')}
            className={`cursor-pointer rounded-lg p-3 bg-slate-900/90 border transition hover:border-amber-500 ${
              selectedNode === 'BURNER' ? 'border-amber-400 shadow-md shadow-amber-950' : 'border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-amber-400 font-bold mb-2">
              <span className="flex items-center gap-1"><Flame className="w-4 h-4" /> BURNER ASSEMBLY</span>
              <span className="text-[10px] bg-amber-950 text-amber-300 px-1.5 py-0.5 rounded">SWIRL</span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-slate-300">
                <span>Fuel Flow:</span>
                <span className="font-bold">{boiler.fuel_flow_kg_s} kg/s</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Air Flow:</span>
                <span className="font-bold text-cyan-400">{boiler.air_flow_kg_s} kg/s</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Air/Fuel Ratio:</span>
                <span className="font-bold text-amber-400">{boiler.air_fuel_ratio}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Fan Speed:</span>
                <span className="font-bold">{boiler.fan_speed_pct}%</span>
              </div>
            </div>
          </div>

          {/* 2. FURNACE CHAMBER */}
          <div
            onClick={() => setSelectedNode('FURNACE')}
            className={`cursor-pointer rounded-lg p-3 bg-slate-900/90 border transition hover:border-orange-500 ${
              selectedNode === 'FURNACE' ? 'border-orange-400 shadow-md shadow-orange-950' : 'border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-orange-400 font-bold mb-2">
              <span className="flex items-center gap-1"><Flame className="w-4 h-4 text-orange-500 animate-pulse" /> FURNACE CHAMBER</span>
              <span className="text-[10px] bg-orange-950 text-orange-300 px-1.5 py-0.5 rounded">RADIANT</span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-slate-300">
                <span>Flame Intensity:</span>
                <span className="font-bold text-orange-400">{boiler.flame_intensity_pct}%</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Furnace Draft:</span>
                <span className="font-bold">{boiler.furnace_draft_mbar} mbar</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Excess Air:</span>
                <span className="font-bold text-cyan-300">{boiler.excess_air_pct}%</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>CO Concentration:</span>
                <span className={`font-bold ${boiler.co_ppm > 50 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {boiler.co_ppm} ppm
                </span>
              </div>
            </div>
          </div>

          {/* 3. STEAM DRUM & TUBES */}
          <div
            onClick={() => setSelectedNode('DRUM')}
            className={`cursor-pointer rounded-lg p-3 bg-slate-900/90 border transition hover:border-cyan-500 ${
              selectedNode === 'DRUM' ? 'border-cyan-400 shadow-md shadow-cyan-950' : 'border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-cyan-400 font-bold mb-2">
              <span className="flex items-center gap-1"><Droplets className="w-4 h-4" /> STEAM DRUM</span>
              <span className="text-[10px] bg-cyan-950 text-cyan-300 px-1.5 py-0.5 rounded">60 BAR</span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-slate-300">
                <span>Steam Flow:</span>
                <span className="font-bold text-cyan-400">{boiler.steam_flow_th} t/h</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Pressure:</span>
                <span className="font-bold">{boiler.steam_pressure_bar} bar</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Temperature:</span>
                <span className="font-bold text-amber-300">{boiler.steam_temperature_C}°C</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Drum Level:</span>
                <span className="font-bold">{boiler.drum_level_mm} mm</span>
              </div>
            </div>
          </div>

          {/* 4. ECONOMISER FIN BANK */}
          <div
            onClick={() => setSelectedNode('ECONOMISER')}
            className={`cursor-pointer rounded-lg p-3 bg-slate-900/90 border transition hover:border-emerald-500 ${
              isFouled
                ? 'border-red-500/80 bg-red-950/20'
                : selectedNode === 'ECONOMISER'
                ? 'border-emerald-400 shadow-md shadow-emerald-950'
                : 'border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between text-xs font-bold mb-2">
              <span className={`flex items-center gap-1 ${isFouled ? 'text-red-400' : 'text-emerald-400'}`}>
                <Thermometer className="w-4 h-4" /> ECONOMISER
              </span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                  isFouled ? 'bg-red-900 text-red-200' : 'bg-emerald-950 text-emerald-300'
                }`}
              >
                {isFouled ? 'FOULED' : 'CLEAN'}
              </span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-slate-300">
                <span>FW Gas Out:</span>
                <span className="font-bold text-amber-300">{boiler.economiser_gas_out_C}°C</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Effectiveness:</span>
                <span className={`font-bold ${isFouled ? 'text-red-400' : 'text-emerald-400'}`}>
                  {(boiler.economiser_effectiveness * 100).toFixed(0)}%
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Fouling R_f:</span>
                <span className="font-bold">{boiler.fouling_factor}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Duty:</span>
                <span className="font-bold text-emerald-400">{boiler.economiser_duty_MW} MW</span>
              </div>
            </div>
          </div>

          {/* 5. STACK & FLUE GAS */}
          <div
            onClick={() => setSelectedNode('STACK')}
            className={`cursor-pointer rounded-lg p-3 bg-slate-900/90 border transition hover:border-purple-500 ${
              selectedNode === 'STACK' ? 'border-purple-400 shadow-md shadow-purple-950' : 'border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between text-xs text-purple-400 font-bold mb-2">
              <span className="flex items-center gap-1"><Wind className="w-4 h-4" /> STACK & GAS</span>
              <span className="text-[10px] bg-purple-950 text-purple-300 px-1.5 py-0.5 rounded">EMISSIONS</span>
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-slate-300">
                <span>Stack Temp:</span>
                <span className={`font-bold ${boiler.stack_temperature_C > 160 ? 'text-red-400' : 'text-amber-300'}`}>
                  {boiler.stack_temperature_C}°C
                </span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>O2 Analyser:</span>
                <span className="font-bold text-cyan-300">{boiler.o2_pct}%</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>CO2 Content:</span>
                <span className="font-bold text-purple-300">{boiler.co2_pct}%</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>NOx Level:</span>
                <span className="font-bold text-blue-400">{boiler.nox_ppm} ppm</span>
              </div>
            </div>
          </div>

        </div>

        {/* Process Vector Connections & Flow Arrows */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
          <div className="p-2.5 rounded bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">ASME Boiler Efficiency:</span>
            <span className="font-bold text-emerald-400 text-sm">{boiler.boiler_efficiency_pct}%</span>
          </div>

          <div className="p-2.5 rounded bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Stack Heat Loss:</span>
            <span className={`font-bold text-sm ${boiler.stack_loss_pct > 8.0 ? 'text-red-400' : 'text-amber-400'}`}>
              {boiler.stack_loss_pct}%
            </span>
          </div>

          <div className="p-2.5 rounded bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Hourly Fuel Cost:</span>
            <span className="font-bold text-amber-400 text-sm">£{boiler.fuel_cost_per_hour.toLocaleString()}</span>
          </div>
        </div>

      </div>

      {/* Selected Node Detailed Modal Inspector */}
      {selectedNode && (
        <div className="mt-4 bg-slate-950 p-4 rounded-xl border border-amber-500/40 text-xs font-mono relative">
          <button
            onClick={() => setSelectedNode(null)}
            className="absolute top-3 right-3 text-slate-400 hover:text-slate-100 font-bold text-sm"
          >
            ✕
          </button>
          <h3 className="text-amber-400 font-bold mb-2 text-sm flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" /> COMPONENT INSPECTOR: {selectedNode}
          </h3>
          {selectedNode === 'ECONOMISER' && (
            <div className="space-y-1 text-slate-300">
              <p>Economiser Heat Duty: <strong className="text-emerald-400">{boiler.economiser_duty_MW} MW</strong></p>
              <p>Gas Inlet: {boiler.economiser_gas_in_C}°C → Gas Outlet: {boiler.economiser_gas_out_C}°C</p>
              <p>Feedwater Inlet: {boiler.economiser_fw_in_C}°C → Feedwater Outlet: {boiler.economiser_fw_out_C}°C</p>
              <p>Fouling Factor R_f: <strong className={isFouled ? 'text-red-400' : 'text-emerald-400'}>{boiler.fouling_factor} m²K/W</strong></p>
              {isFouled && (
                <p className="text-red-400 font-bold mt-1">
                  ⚠ Gas-side soot accumulation detected. Recommend sootblowing wash cycle to recover 1.2pp lost thermal efficiency.
                </p>
              )}
            </div>
          )}
          {selectedNode === 'BURNER' && (
            <div className="space-y-1 text-slate-300">
              <p>Burner Swirl Type: Low-NOx Dual Fuel Assembly</p>
              <p>Cross-Limiting Control Status: <strong className="text-emerald-400">ACTIVE & SECURE</strong></p>
              <p>Oxygen Trim Status: Targeting 2.0% O2 safe lower limit</p>
            </div>
          )}
          {selectedNode === 'FURNACE' && (
            <div className="space-y-1 text-slate-300">
              <p>Adiabatic Flame Temp Approx: 1,850°C</p>
              <p>Furnace Radiation Heat Flux: 18.5 MW/m²</p>
            </div>
          )}
          {selectedNode === 'DRUM' && (
            <div className="space-y-1 text-slate-300">
              <p>Steam Output Enthalpy: 2,780 kJ/kg</p>
              <p>Continuous Blowdown Loss: {boiler.blowdown_loss_pct}%</p>
            </div>
          )}
          {selectedNode === 'STACK' && (
            <div className="space-y-1 text-slate-300">
              <p>Siegert Stack Loss: {boiler.stack_loss_pct}%</p>
              <p>CO2 Emission Intensity: {boiler.co2_emission_rate_th} tonnes/hour</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
