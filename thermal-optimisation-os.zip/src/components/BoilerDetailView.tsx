/**
 * THERMAL OPTIMISATION OS - COMBUSTION CONTROL & CROSS-LIMITING HIERARCHY
 */

import React from 'react';
import { BoilerState } from '../types';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ScatterChart,
  Scatter,
  ZAxis,
} from 'recharts';
import { ShieldAlert, Flame, Gauge, CheckCircle, Sliders, AlertTriangle } from 'lucide-react';

interface BoilerDetailViewProps {
  boiler: BoilerState;
}

export const BoilerDetailView: React.FC<BoilerDetailViewProps> = ({ boiler }) => {
  // O2 vs Load Curve Data
  const o2CurveData = [
    { load: 20, targetO2: 3.8, actualO2: boiler.o2_pct + 0.5, safeMin: 2.0 },
    { load: 40, targetO2: 3.0, actualO2: boiler.o2_pct + 0.3, safeMin: 1.8 },
    { load: 60, targetO2: 2.4, actualO2: boiler.o2_pct + 0.1, safeMin: 1.6 },
    { load: 80, targetO2: 2.0, actualO2: boiler.o2_pct, safeMin: 1.5 },
    { load: 100, targetO2: 1.8, actualO2: boiler.o2_pct - 0.1, safeMin: 1.5 },
  ];

  // Control Levels 1-8
  const controlLevels = [
    { level: 1, name: 'Fuel Demand Controller', status: 'ACTIVE', desc: 'Master pressure loop generates firing demand' },
    { level: 2, name: 'Air Demand Controller', status: 'ACTIVE', desc: 'FD Fan VFD speed & damper positioning' },
    { level: 3, name: 'Fuel / Air Ratio Characteriser', status: 'ACTIVE', desc: 'Combustion air curve matching fuel LHV' },
    { level: 4, name: 'Cross-Limiting Safety Interlock', status: 'ENFORCED', desc: 'Air leads fuel on load rise; fuel leads air on load drop' },
    { level: 5, name: 'O₂ Trim Feedback Loop', status: boiler.o2_quality === 'SENSOR_FAULT' ? 'FALLBACK' : 'ACTIVE', desc: 'Trim oxygen target within safe bounds' },
    { level: 6, name: 'CO Constraint Override', status: 'MONITORING', desc: 'Overrides air reduction if CO exceeds 50 ppm' },
    { level: 7, name: 'NOx Emission Limiter', status: 'ACTIVE', desc: 'Flue gas recirculation & flame temp trim' },
    { level: 8, name: 'Load Optimisation Layer', status: 'ADVISORY', desc: 'Multi-objective fleet dispatch solver' },
  ];

  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-500" /> COMBUSTION CONTROL & CROSS-LIMITING HIERARCHY
          </h2>
          <p className="text-xs text-slate-400">
            8-Level Control Stack for {boiler.name} ({boiler.id})
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="p-2 rounded bg-slate-900 border border-slate-800">
            <span className="text-slate-400">Actual O₂: </span>
            <span className="font-bold text-cyan-400">{boiler.o2_pct}%</span>
          </div>
          <div className="p-2 rounded bg-slate-900 border border-slate-800">
            <span className="text-slate-400">Air/Fuel Ratio: </span>
            <span className="font-bold text-amber-400">{boiler.air_fuel_ratio}</span>
          </div>
        </div>
      </div>

      {/* Grid: Control Stack & Curve Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Control Hierarchy Status Stack */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
          <h3 className="text-xs font-bold text-amber-400 tracking-wider uppercase mb-3 flex items-center gap-1.5">
            <Sliders className="w-4 h-4" /> 8-LEVEL CONTROL STACK STATE
          </h3>

          <div className="space-y-2">
            {controlLevels.map((lvl) => (
              <div
                key={lvl.level}
                className="p-2.5 rounded bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center font-bold text-[10px]">
                    L{lvl.level}
                  </span>
                  <div>
                    <div className="font-bold text-slate-200">{lvl.name}</div>
                    <div className="text-[10px] text-slate-400">{lvl.desc}</div>
                  </div>
                </div>

                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    lvl.status === 'ENFORCED'
                      ? 'bg-blue-950 text-blue-300 border border-blue-800'
                      : lvl.status === 'FALLBACK'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  }`}
                >
                  {lvl.status}
                </span>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-950 border border-amber-500/30 rounded text-[11px] text-slate-300 font-sans flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              <strong>Cross-Limiting Safety Guarantee:</strong> Optimization algorithms cannot command fuel flow above available combustion air. Hardwired BMS interlocks prevent sub-stoichiometric rich flame conditions.
            </span>
          </div>
        </div>

        {/* 2. O2 vs Load Curve Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-100 tracking-wider uppercase mb-1 flex items-center gap-1.5">
              <Gauge className="w-4 h-4 text-cyan-400" /> O₂ TRIM TARGET VS ACTUAL LOAD CURVE
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Optimal excess O2 target decreases as load rises to maintain flame stability and minimise stack loss.
            </p>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={o2CurveData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="load" stroke="#94a3b8" label={{ value: 'Steam Load %', position: 'bottom', fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis stroke="#94a3b8" domain={[1.0, 5.0]} label={{ value: 'O2 %', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                  <Legend />
                  <Line type="monotone" dataKey="targetO2" name="Target O2 %" stroke="#10b981" strokeWidth={2} />
                  <Line type="monotone" dataKey="actualO2" name="Actual Measured O2 %" stroke="#38bdf8" strokeWidth={2} strokeDasharray="4 4" />
                  <Line type="monotone" dataKey="safeMin" name="Safe Min Boundary" stroke="#ef4444" strokeWidth={1.5} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded border border-slate-800 text-xs font-mono space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Current Operating Excess O2:</span>
              <span className="font-bold text-cyan-400">{boiler.o2_pct}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Optimum Model Target O2:</span>
              <span className="font-bold text-emerald-400">2.1%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Avoidable Dry Gas Stack Loss:</span>
              <span className="font-bold text-amber-400">+0.6 percentage points</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
