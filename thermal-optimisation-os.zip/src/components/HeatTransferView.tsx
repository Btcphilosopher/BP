/**
 * THERMAL OPTIMISATION OS - ECONOMISER & HEAT RECOVERY DEGRADATION MONITOR
 */

import React from 'react';
import { BoilerState } from '../types';
import { Thermometer, AlertCircle, Wrench, DollarSign, Activity, CheckCircle2 } from 'lucide-react';

interface HeatTransferViewProps {
  boiler: BoilerState;
}

export const HeatTransferView: React.FC<HeatTransferViewProps> = ({ boiler }) => {
  const isFouled = boiler.economiser_fouled;
  const foulingRf = boiler.fouling_factor;
  const gasIn = boiler.economiser_gas_in_C;
  const gasOut = boiler.economiser_gas_out_C;
  const fwIn = boiler.economiser_fw_in_C;
  const fwOut = boiler.economiser_fw_out_C;

  const costCleaning = 80000; // £80k
  const annualSavings = 450000; // £450k/yr
  const paybackDays = Math.round((costCleaning / annualSavings) * 365);
  const npv5yr = Math.round(annualSavings * 3.8 - costCleaning);

  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Thermometer className="w-5 h-5 text-emerald-400" /> ECONOMISER & AIR PREHEATER HEAT RECOVERY
        </h2>
        <p className="text-xs text-slate-400">
          Thermal degradation, approach temperatures, fouling factor $R_f$ & sootblowing ROI for {boiler.name} ({boiler.id})
        </p>
      </div>

      {/* Grid: Temperature Profile & Degradation Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* 1. Economiser Temperature Profile */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
          <h3 className="text-xs font-bold text-emerald-400 tracking-wider uppercase mb-3 flex items-center gap-1.5">
            <Activity className="w-4 h-4" /> TEMPERATURE PROFILE
          </h3>

          <div className="space-y-2">
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Flue Gas Inlet:</span>
              <span className="font-bold text-orange-400">{gasIn}°C</span>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Flue Gas Outlet:</span>
              <span className={`font-bold ${gasOut > 160 ? 'text-red-400' : 'text-amber-300'}`}>{gasOut}°C</span>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Feedwater Inlet:</span>
              <span className="font-bold text-cyan-400">{fwIn}°C</span>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Feedwater Outlet:</span>
              <span className="font-bold text-emerald-400">{fwOut}°C</span>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Approach Temperature ΔT:</span>
              <span className="font-bold text-slate-200">{(gasIn - fwOut).toFixed(1)}°C</span>
            </div>
          </div>
        </div>

        {/* 2. Heat Transfer Coefficient & Fouling Factor */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
          <h3 className="text-xs font-bold text-cyan-400 tracking-wider uppercase mb-3 flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4" /> FOULING FACTOR & EFFECTIVENESS
          </h3>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Heat Duty:</span>
              <span className="text-sm font-bold text-emerald-400">{boiler.economiser_duty_MW} MW</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Thermal Effectiveness ε:</span>
              <span className={`text-sm font-bold ${isFouled ? 'text-red-400' : 'text-emerald-400'}`}>
                {(boiler.economiser_effectiveness * 100).toFixed(0)}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Fouling Factor R_f:</span>
              <span className={`text-sm font-bold ${isFouled ? 'text-red-400' : 'text-emerald-400'}`}>
                {foulingRf} m²K/W
              </span>
            </div>
          </div>

          <div className={`p-3 rounded border text-xs font-sans ${isFouled ? 'bg-red-950/40 border-red-800 text-red-200' : 'bg-emerald-950/40 border-emerald-800 text-emerald-200'}`}>
            <div className="font-bold mb-1 flex items-center gap-1">
              {isFouled ? <AlertCircle className="w-4 h-4 text-red-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              {isFouled ? 'FOULING DEGRADATION DETECTED' : 'HEAT TRANSFER OPTIMAL'}
            </div>
            <p>
              {isFouled
                ? 'Gas-side soot accumulation on finned tubes has reduced heat transfer coefficient U by ~38%. Stack loss increased by +1.2pp.'
                : 'Fouling factor within clean design tolerance. Heat recovery operating at peak effectiveness.'}
            </p>
          </div>
        </div>

        {/* 3. Sootblowing & Cleaning ROI Calculator */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
          <h3 className="text-xs font-bold text-amber-400 tracking-wider uppercase mb-3 flex items-center gap-1.5">
            <DollarSign className="w-4 h-4" /> MAINTENANCE ECONOMICS & ROI
          </h3>

          <div className="space-y-2">
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Cleaning Cost:</span>
              <span className="font-bold text-slate-200">£{costCleaning.toLocaleString()}</span>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Expected Efficiency Gain:</span>
              <span className="font-bold text-emerald-400">+1.2 percentage points</span>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">Annual Fuel Savings:</span>
              <span className="font-bold text-amber-400">£{annualSavings.toLocaleString()} / year</span>
            </div>
            <div className="p-2.5 rounded bg-amber-950/40 border border-amber-800 flex justify-between">
              <span className="text-amber-300 font-bold">Simple Payback Period:</span>
              <span className="font-bold text-amber-400 text-sm">{paybackDays} Days</span>
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400">5-Year Net Present Value (NPV):</span>
              <span className="font-bold text-emerald-400">£{npv5yr.toLocaleString()}</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
