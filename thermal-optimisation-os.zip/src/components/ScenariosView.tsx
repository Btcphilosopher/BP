/**
 * THERMAL OPTIMISATION OS - WHAT-IF SCENARIOS & MONTE CARLO RISK SIMULATOR
 */

import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { Sliders, Activity, HelpCircle } from 'lucide-react';

export const ScenariosView: React.FC = () => {
  const [steamDemand, setSteamDemand] = useState<number>(850);
  const [gasPrice, setGasPrice] = useState<number>(48.5);
  const [ambientTemp, setAmbientTemp] = useState<number>(18);
  const [condensateReturn, setCondensateReturn] = useState<number>(68);

  // Monte Carlo Cost Distribution Data
  const baseCost = (steamDemand * 2.8 * gasPrice) / 0.91; // approx £/hr
  const monteCarloData = [
    { costGbp: Math.round(baseCost * 0.88), prob: 0.05, label: 'P10 Optimistic' },
    { costGbp: Math.round(baseCost * 0.94), prob: 0.20, label: 'P25' },
    { costGbp: Math.round(baseCost * 1.00), prob: 0.50, label: 'P50 Expected' },
    { costGbp: Math.round(baseCost * 1.06), prob: 0.20, label: 'P75' },
    { costGbp: Math.round(baseCost * 1.12), prob: 0.05, label: 'P90 Risk Bound' },
  ];

  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Sliders className="w-5 h-5 text-amber-400" /> WHAT-IF SCENARIO ANALYSIS & MONTE CARLO SIMULATOR
        </h2>
        <p className="text-xs text-slate-400">
          Simulate plant process shifts, weather variations, fuel price volatility & 1,000-run Monte Carlo risk distributions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Interactive Parameter Sliders */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-4 font-mono text-xs">
          <h3 className="font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Sliders className="w-4 h-4" /> SCENARIO INPUT VARIABLES
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">Total Plant Steam Demand:</span>
                <span className="font-bold text-cyan-400">{steamDemand} t/h</span>
              </div>
              <input
                type="range"
                min="500"
                max="1200"
                step="10"
                value={steamDemand}
                onChange={(e) => setSteamDemand(Number(e.target.value))}
                className="w-full accent-cyan-500 bg-slate-950"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">Natural Gas Price:</span>
                <span className="font-bold text-amber-400">£{gasPrice} / MWh</span>
              </div>
              <input
                type="range"
                min="20"
                max="120"
                step="0.5"
                value={gasPrice}
                onChange={(e) => setGasPrice(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-950"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">Ambient Air Temperature:</span>
                <span className="font-bold text-slate-200">{ambientTemp}°C</span>
              </div>
              <input
                type="range"
                min="-10"
                max="40"
                step="1"
                value={ambientTemp}
                onChange={(e) => setAmbientTemp(Number(e.target.value))}
                className="w-full accent-slate-400 bg-slate-950"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-300">Condensate Return Rate:</span>
                <span className="font-bold text-emerald-400">{condensateReturn}%</span>
              </div>
              <input
                type="range"
                min="30"
                max="95"
                step="1"
                value={condensateReturn}
                onChange={(e) => setCondensateReturn(Number(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-950"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-1 pt-3">
            <div className="flex justify-between">
              <span className="text-slate-400">Calculated Hourly Operating Cost:</span>
              <span className="font-bold text-amber-400">£{Math.round(baseCost).toLocaleString()} / hr</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Annualised Fuel Spend:</span>
              <span className="font-bold text-slate-100">£{Math.round(baseCost * 8760).toLocaleString()} / yr</span>
            </div>
          </div>
        </div>

        {/* 2. Monte Carlo Distribution Chart */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-100 uppercase tracking-wider mb-1 flex items-center gap-1.5 text-xs font-mono">
              <Activity className="w-4 h-4 text-purple-400" /> MONTE CARLO PROBABILITY COST DISTRIBUTION
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              1,000 synthetic stochastic runs showing operating cost distribution under variable fuel price & ambient load.
            </p>

            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monteCarloData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="costGbp" stroke="#94a3b8" label={{ value: 'Hourly Fuel Cost (£/hr)', position: 'bottom', fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis stroke="#94a3b8" label={{ value: 'Probability', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                  <Area type="monotone" dataKey="prob" name="Probability Density" stroke="#a855f7" fill="#a855f7" fillOpacity={0.3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 font-mono text-xs text-center pt-2">
            <div className="p-2 bg-slate-950 rounded border border-slate-800">
              <div className="text-[10px] text-slate-400">P10 Optimistic:</div>
              <div className="font-bold text-emerald-400">£{Math.round(baseCost * 0.88).toLocaleString()}</div>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-amber-500/50">
              <div className="text-[10px] text-amber-400 font-bold">P50 Expected:</div>
              <div className="font-bold text-amber-400">£{Math.round(baseCost).toLocaleString()}</div>
            </div>
            <div className="p-2 bg-slate-950 rounded border border-red-800">
              <div className="text-[10px] text-red-400">P90 Upper Risk:</div>
              <div className="font-bold text-red-400">£{Math.round(baseCost * 1.12).toLocaleString()}</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
