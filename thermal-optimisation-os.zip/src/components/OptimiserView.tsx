/**
 * THERMAL OPTIMISATION OS - MULTI-OBJECTIVE DISPATCH SOLVER
 */

import React, { useState } from 'react';
import { OptimisationRun } from '../types';
import { Target, CheckCircle2, ShieldCheck, Play, Zap, ArrowRight } from 'lucide-react';

interface OptimiserViewProps {
  optimisationRun: OptimisationRun;
  onRunOptimisation: (objective: string) => void;
}

export const OptimiserView: React.FC<OptimiserViewProps> = ({
  optimisationRun,
  onRunOptimisation,
}) => {
  const [selectedObjective, setSelectedObjective] = useState<string>('COST_MINIMUM');
  const [executed, setExecuted] = useState<boolean>(false);

  const handleObjectiveChange = (obj: string) => {
    setSelectedObjective(obj);
    onRunOptimisation(obj);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="border-b border-slate-800 pb-3 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Target className="w-5 h-5 text-amber-400" /> MULTI-OBJECTIVE THERMAL DISPATCH SOLVER
          </h2>
          <p className="text-xs text-slate-400">
            Real-time Mixed-Integer Non-Linear Programming (MINLP) fleet load allocation & O2 trim optimiser
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setExecuted(true)}
            disabled={executed}
            className={`px-4 py-2 rounded font-bold text-xs flex items-center gap-2 transition ${
              executed
                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                : 'bg-amber-600 hover:bg-amber-500 text-slate-950 shadow-md shadow-amber-950'
            }`}
          >
            {executed ? <CheckCircle2 className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {executed ? 'DISPATCH EXECUTED' : 'APPROVE & ACTUATE DISPATCH'}
          </button>
        </div>
      </div>

      {/* Objective Mode Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-3 font-mono text-xs">
        <div className="text-xs font-bold text-slate-400 tracking-wider uppercase mb-2">
          SELECT SOLVER OPTIMISATION OBJECTIVE:
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {[
            { id: 'COST_MINIMUM', label: '💰 Minimum Fuel Cost', desc: 'Minimise £/hour total fuel bill' },
            { id: 'FUEL_MINIMUM', label: '🔥 Minimum Fuel Mass', desc: 'Minimise total kg/s fuel flow' },
            { id: 'CO2_MINIMUM', label: '🌱 Minimum CO₂', desc: 'Minimise carbon emissions t/y' },
            { id: 'EMISSIONS_CONSTRAINED', label: '🛡️ Low NOx Limit', desc: 'Strict NOx & CO boundary' },
            { id: 'EQUIPMENT_LIFE', label: '⏳ Thermal Stress Min', desc: 'Minimise burner wear & cycling' },
            { id: 'BALANCED', label: '⚖️ Balanced Multi-Obj', desc: 'Pareto optimal cost/CO2' },
          ].map((obj) => (
            <button
              key={obj.id}
              onClick={() => handleObjectiveChange(obj.id)}
              className={`p-3 rounded-lg border text-left transition flex flex-col justify-between ${
                selectedObjective === obj.id
                  ? 'bg-amber-950/60 border-amber-500 text-amber-300 ring-1 ring-amber-500/50'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <div className="font-bold text-xs mb-1">{obj.label}</div>
              <div className="text-[10px] text-slate-400 font-sans">{obj.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Expected Savings & Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
          <div className="text-slate-400 mb-1">Current Fleet Fuel Cost:</div>
          <div className="text-base font-bold text-slate-100">
            £{optimisationRun.current_total_fuel_cost_gbp_h.toLocaleString()} / hr
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
          <div className="text-slate-400 mb-1">Optimised Fleet Fuel Cost:</div>
          <div className="text-base font-bold text-emerald-400">
            £{optimisationRun.optimised_total_fuel_cost_gbp_h.toLocaleString()} / hr
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-amber-500/50 rounded-xl bg-amber-950/20">
          <div className="text-amber-400 font-bold mb-1">Annual Cost Savings:</div>
          <div className="text-lg font-bold text-amber-400">
            £{optimisationRun.expected_annual_savings_gbp.toLocaleString()} / yr
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-purple-500/50 rounded-xl bg-purple-950/20">
          <div className="text-purple-300 font-bold mb-1">Annual CO₂ Reduction:</div>
          <div className="text-lg font-bold text-purple-300">
            {optimisationRun.expected_co2_reduction_t_y} tonnes / yr
          </div>
        </div>
      </div>

      {/* Constraint Check Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-2 font-mono text-xs">
        <h3 className="font-bold text-slate-200 mb-2 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" /> HARD SAFETY & PROCESS CONSTRAINTS VERIFICATION
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[11px]">
          <div className="p-2 bg-slate-950 border border-slate-800 rounded flex items-center gap-1.5 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> Flame Stability
          </div>
          <div className="p-2 bg-slate-950 border border-slate-800 rounded flex items-center gap-1.5 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> Min Air / CO Limit
          </div>
          <div className="p-2 bg-slate-950 border border-slate-800 rounded flex items-center gap-1.5 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> Burner Turndown
          </div>
          <div className="p-2 bg-slate-950 border border-slate-800 rounded flex items-center gap-1.5 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> Header Pressure
          </div>
          <div className="p-2 bg-slate-950 border border-slate-800 rounded flex items-center gap-1.5 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> NOx Limit (80ppm)
          </div>
        </div>
      </div>

      {/* Recommendations Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl overflow-x-auto font-mono text-xs">
        <h3 className="font-bold text-amber-400 mb-3 flex items-center gap-1.5">
          <Zap className="w-4 h-4" /> RECOMMENDED BOILER LOAD & O₂ DISPATCH
        </h3>

        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400">
              <th className="py-2 px-3">Boiler Unit</th>
              <th className="py-2 px-3">Current Load</th>
              <th className="py-2 px-3">Target Load</th>
              <th className="py-2 px-3">Current O₂</th>
              <th className="py-2 px-3">Target O₂</th>
              <th className="py-2 px-3">Eff. Gain</th>
              <th className="py-2 px-3">Hourly Savings</th>
              <th className="py-2 px-3">Explanation</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80">
            {optimisationRun.recommendations.map((rec) => (
              <tr key={rec.boilerId} className="hover:bg-slate-850">
                <td className="py-2.5 px-3 font-bold text-slate-200">{rec.boilerName}</td>
                <td className="py-2.5 px-3 text-slate-300">{rec.current_load_th} t/h</td>
                <td className="py-2.5 px-3 font-bold text-cyan-400">{rec.recommended_load_th} t/h</td>
                <td className="py-2.5 px-3 text-slate-300">{rec.current_o2_pct}%</td>
                <td className="py-2.5 px-3 font-bold text-emerald-400">{rec.recommended_o2_pct}%</td>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">+{rec.expected_efficiency_gain_pp}pp</td>
                <td className="py-2.5 px-3 text-amber-400 font-bold">£{rec.expected_cost_saving_gbp_h}/hr</td>
                <td className="py-2.5 px-3 text-[11px] text-slate-400 font-sans max-w-xs">{rec.explanation}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
