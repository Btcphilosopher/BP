/**
 * THERMAL OPTIMISATION OS - AI THERMAL ASSISTANT
 * Server-side Gemini API (gemini-3.8-flash) grounded on live plant telemetry.
 */

import React, { useState } from 'react';
import { Bot, Send, Sparkles, User, Flame, AlertCircle } from 'lucide-react';

export const AiAssistantView: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: 'Greetings. I am Thermal AI Assistant, grounded in real-time thermodynamic equations, ASME PTC 4.1 heat balance models, and live plant telemetry. How can I assist with your combustion efficiency, stack loss, or fleet dispatch today?',
    },
  ]);
  const [loading, setLoading] = useState<boolean>(false);

  const handleSend = async (customPrompt?: string) => {
    const q = customPrompt || prompt;
    if (!q.trim() || loading) return;

    const userMsg = { role: 'user' as const, text: q };
    setMessages((prev) => [...prev, userMsg]);
    setPrompt('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: q, boilerId: 'BOILER-03' }),
      });
      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: data.answer || 'No response returned from model.' },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: 'Error contacting AI assistant server route.' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Bot className="w-5 h-5 text-amber-400" /> THERMAL AI ASSISTANT (GEMINI 3.8 FLASH GROUNDED)
        </h2>
        <p className="text-xs text-slate-400">
          Server-side AI assistant querying live thermodynamic state, flue gas composition & ASME heat balance loss equations
        </p>
      </div>

      {/* Main Chat Box */}
      <div className="max-w-4xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col h-[520px] font-mono text-xs">
        
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="w-7 h-7 rounded bg-amber-600 flex items-center justify-center text-slate-950 font-bold shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-2xl p-3.5 rounded-xl text-xs whitespace-pre-wrap font-sans leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-amber-600 text-slate-950 font-semibold rounded-tr-none'
                    : 'bg-slate-950 text-slate-200 border border-slate-800 rounded-tl-none font-mono'
                }`}
              >
                {m.text}
              </div>

              {m.role === 'user' && (
                <div className="w-7 h-7 rounded bg-slate-700 flex items-center justify-center text-slate-100 font-bold shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-slate-400 font-mono text-xs p-2">
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
              <span>Evaluating thermodynamic models & generating response...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Questions */}
        <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 flex flex-wrap gap-2 text-[11px] font-sans">
          {[
            'Why has Boiler 03 efficiency fallen?',
            'Which boiler should carry extra load?',
            'What is the economic value of reducing excess O2?',
          ].map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 transition"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask AI Assistant about boiler thermodynamics, stack losses or dispatch..."
            className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono text-xs"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold rounded-lg transition flex items-center gap-1.5 shrink-0"
          >
            <Send className="w-3.5 h-3.5" /> Send
          </button>
        </div>

      </div>
    </div>
  );
};
