/**
 * THERMAL OPTIMISATION OS - ROOT CAUSE DIAGNOSTICS & EFFICIENCY LOSS TREE
 */

import React from 'react';
import { BoilerState, RootCauseHypothesis } from '../types';
import { Search, AlertTriangle, ArrowRight, ShieldAlert, CheckCircle } from 'lucide-react';

interface DiagnosticsViewProps {
  boiler: BoilerState;
  hypotheses: RootCauseHypothesis[];
}

export const DiagnosticsView: React.FC<DiagnosticsViewProps> = ({ boiler, hypotheses }) => {
  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Search className="w-5 h-5 text-amber-400" /> ROOT-CAUSE DIAGNOSTICS & EFFICIENCY LOSS TREE
        </h2>
        <p className="text-xs text-slate-400">
          Automated diagnostic hypotheses and ASME loss breakdown for {boiler.name} ({boiler.id})
        </p>
      </div>

      {/* Grid: Loss Tree & Ranked Hypotheses */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* 1. Loss Tree Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl font-mono text-xs space-y-3">
          <h3 className="text-xs font-bold text-slate-100 tracking-wider uppercase mb-2 flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-400" /> ASME PTC 4.1 LOSS DECOMPOSITION
          </h3>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex justify-between items-center">
            <span className="text-slate-400">Current Net Efficiency:</span>
            <span className="text-sm font-bold text-emerald-400">{boiler.boiler_efficiency_pct}%</span>
          </div>

          <div className="pl-3 border-l-2 border-red-500/50 space-y-2">
            <div className="p-2 bg-slate-950 border border-slate-800 rounded flex justify-between">
              <span className="text-slate-300">Dry Flue Gas Stack Loss:</span>
              <span className="font-bold text-red-400">-{boiler.stack_loss_pct}%</span>
            </div>

            <div className="p-2 bg-slate-950 border border-slate-800 rounded flex justify-between">
              <span className="text-slate-300">Radiation & Casing Loss:</span>
              <span className="font-bold text-amber-400">-{boiler.radiation_loss_pct}%</span>
            </div>

            <div className="p-2 bg-slate-950 border border-slate-800 rounded flex justify-between">
              <span className="text-slate-300">Continuous Blowdown Loss:</span>
              <span className="font-bold text-blue-400">-{boiler.blowdown_loss_pct}%</span>
            </div>

            <div className="p-2 bg-slate-950 border border-slate-800 rounded flex justify-between">
              <span className="text-slate-300">Incomplete Combustion (CO) Loss:</span>
              <span className="font-bold text-purple-400">-{boiler.incomplete_combustion_loss_pct}%</span>
            </div>
          </div>

          <div className="p-2.5 bg-red-950/40 border border-red-800/60 rounded text-red-200 text-[11px] font-sans">
            Total Thermal Losses: <strong>{(100 - boiler.boiler_efficiency_pct).toFixed(1)}%</strong> of fuel energy input.
          </div>
        </div>

        {/* 2. Ranked Diagnostic Hypotheses Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-4">
          <h3 className="text-xs font-bold text-amber-400 tracking-wider uppercase flex items-center gap-1.5 font-mono">
            <ShieldAlert className="w-4 h-4" /> RANKED ROOT-CAUSE DIAGNOSTIC HYPOTHESES ({hypotheses.length})
          </h3>

          {hypotheses.length === 0 ? (
            <div className="p-6 bg-slate-950 rounded-lg text-center text-slate-400 text-xs font-mono">
              ✓ No active thermal anomalies or significant losses detected on this unit.
            </div>
          ) : (
            <div className="space-y-3 font-mono text-xs">
              {hypotheses.map((hyp) => (
                <div
                  key={hyp.id}
                  className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2 hover:border-slate-700 transition"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                    <span className="font-bold text-amber-400 text-sm flex items-center gap-1.5">
                      {hyp.title}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold text-[10px]">
                        Confidence: {(hyp.confidence * 100).toFixed(0)}%
                      </span>
                      <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800 font-bold text-[10px]">
                        -{Math.abs(hyp.efficiency_impact_pp)}pp Eff.
                      </span>
                    </div>
                  </div>

                  <p className="text-slate-300 text-xs font-sans">{hyp.description}</p>

                  <div className="space-y-1 pt-1">
                    <div className="text-[11px] text-slate-400 font-bold">Physical Sensor Evidence:</div>
                    <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-300 font-sans">
                      {hyp.evidence.map((ev, idx) => (
                        <li key={idx}>{ev}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-wrap items-center justify-between pt-2 border-t border-slate-800 text-xs">
                    <div className="text-amber-400 font-bold">
                      Economic Cost: £{hyp.economic_impact_gbp_day.toLocaleString()} / day
                    </div>
                    <div className="text-emerald-400 font-semibold flex items-center gap-1">
                      <ArrowRight className="w-3.5 h-3.5" /> {hyp.recommended_action}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
