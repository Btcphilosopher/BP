/**
 * THERMAL OPTIMISATION OS - REPORTS & OPENAPI SPECIFICATION VIEWER
 */

import React, { useState } from 'react';
import { BoilerState } from '../types';
import { FileText, Download, Code, Check, Copy } from 'lucide-react';

interface ReportsViewProps {
  boilers: BoilerState[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({ boilers }) => {
  const [copied, setCopied] = useState<boolean>(false);

  const openApiYaml = `openapi: 3.0.3
info:
  title: Thermal Optimisation OS API
  version: 1.0.0
  description: Enterprise Industrial Boiler Efficiency & Digital Twin Platform API
paths:
  /api/plants:
    get:
      summary: Get overall plant thermal summary metrics
  /api/boilers:
    get:
      summary: List all active boiler states in fleet
  /api/boilers/{id}:
    get:
      summary: Get detailed runtime telemetry for a specific boiler
  /api/optimisation/run:
    post:
      summary: Execute multi-objective thermal dispatch solver
  /api/master-demos/{demoId}/run:
    post:
      summary: Run master demonstration scenario step`;

  const copySpec = () => {
    navigator.clipboard.writeText(openApiYaml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* Title */}
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <FileText className="w-5 h-5 text-amber-400" /> DAILY PERFORMANCE REPORTS & OPENAPI SPECIFICATION
        </h2>
        <p className="text-xs text-slate-400">
          Generated ASME PTC 4.1 thermal efficiency certificates & enterprise OpenAPI integration endpoints
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. Daily Performance Certificate Generator */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl font-mono text-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-bold text-slate-100 flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-400" /> DAILY THERMAL PERFORMANCE CERTIFICATE
            </h3>
            <span className="text-slate-400">ISO 50001 COMPLIANT</span>
          </div>

          <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2 text-slate-300 font-sans">
            <div className="font-bold text-amber-400 font-mono">NORTH SEA PROCESS PLANT • DAILY SUMMARY</div>
            <p className="text-xs">
              This document certifies that the 5-boiler steam fleet was evaluated using ASME PTC 4.1 heat balance loss standards.
            </p>
            <div className="space-y-1 font-mono text-xs text-slate-200 pt-2 border-t border-slate-800">
              <p>Fleet Steam Output: <strong>850.0 t/h</strong></p>
              <p>Overall Net Thermal Efficiency: <strong>91.4%</strong></p>
              <p>Total CO2 Emission Rate: <strong>24.8 tonnes/hr</strong></p>
              <p>Daily Fuel Expenditure: <strong>£98,400</strong></p>
            </div>
          </div>

          <button
            onClick={() => alert('Daily Thermal Efficiency Certificate PDF generated and downloaded.')}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg transition flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" /> DOWNLOAD OFFICIAL PDF CERTIFICATE
          </button>
        </div>

        {/* 2. OpenAPI Specification Code Viewer */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl font-mono text-xs space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
              <h3 className="font-bold text-sky-400 flex items-center gap-2">
                <Code className="w-4 h-4" /> OPENAPI 3.0 REST SPECIFICATION
              </h3>
              <button
                onClick={copyCopy => copySpec()}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1 transition text-[11px]"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'COPIED' : 'COPY SPEC'}
              </button>
            </div>

            <pre className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-[11px] text-slate-300 overflow-x-auto h-52 leading-relaxed">
              {openApiYaml}
            </pre>
          </div>

          <div className="text-[11px] text-slate-400 font-sans">
            Endpoint available at <code className="text-amber-400 font-mono">/api/openapi.yaml</code> for automated industrial API gateway integration.
          </div>
        </div>

      </div>
    </div>
  );
};
