/**
 * THERMAL OPTIMISATION OS - CANONICAL DATA TYPES
 * Industrial Boiler Efficiency & Digital Twin Platform
 */

export type FuelType = 'NATURAL_GAS' | 'REFINERY_FUEL_GAS' | 'HYDROGEN_BLEND' | 'FUEL_OIL' | 'MIXED_FUEL_GAS';

export type QualityState = 'GOOD' | 'UNCERTAIN' | 'SENSOR_FAULT' | 'BAD' | 'MISSING' | 'STALE' | 'OUT_OF_RANGE' | 'ESTIMATED';

export type AlarmPriority = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFORMATION';

export type OptimisationObjective = 'FUEL_MINIMUM' | 'COST_MINIMUM' | 'CO2_MINIMUM' | 'EMISSIONS_CONSTRAINED' | 'EQUIPMENT_LIFE' | 'BALANCED';

export type IndustrialMode = 'SIMULATION' | 'SHADOW_MODE' | 'CONTROL_INTEGRATION';

export interface FuelComposition {
  methane: number; // fraction 0..1
  ethane?: number;
  propane?: number;
  hydrogen: number; // fraction 0..1
  co: number; // fraction 0..1
  co2: number; // fraction 0..1
  nitrogen: number; // fraction 0..1
  lhv_mj_kg: number; // Lower Heating Value (MJ/kg)
  hhv_mj_kg: number; // Higher Heating Value (MJ/kg)
  density_kg_m3: number;
  wobbe_index: number;
  carbon_content_fraction: number;
}

export interface BoilerConfig {
  id: string;
  name: string;
  boilerHouseId: string;
  manufacturer: string;
  model: string;
  capacity_t_h: number; // Design steam flow t/h
  designPressure_bar: number;
  designTemperature_C: number;
  designEfficiency: number; // percentage e.g. 92.5
  fuelTypes: FuelType[];
  primaryFuel: FuelType;
  burnerType: string;
  minLoad_t_h: number;
  maxLoad_t_h: number;
  minO2Target: number; // % O2 minimum safe boundary
  maxO2Target: number;
  maxNOxLimit_ppm: number;
  maxCOLimit_ppm: number;
  commissioningYear: number;
}

export interface BoilerState {
  id: string;
  name: string;
  status: 'ONLINE' | 'OFFLINE' | 'STARTING' | 'TRIPPED' | 'MAINTENANCE';
  load_pct: number; // 0..100%
  steam_flow_th: number; // t/h
  steam_pressure_bar: number; // bar
  steam_temperature_C: number; // °C
  fuel_flow_kg_s: number; // kg/s
  fuel_flow_m3_h: number; // m3/h or kg/h
  air_flow_kg_s: number; // kg/s
  air_fuel_ratio: number;
  stoichiometric_air_ratio: number;
  excess_air_pct: number; // %
  equivalence_ratio: number;
  o2_pct: number; // Flue gas O2 %
  co_ppm: number; // Flue gas CO ppm
  co2_pct: number; // Flue gas CO2 %
  nox_ppm: number; // Flue gas NOx ppm
  stack_temperature_C: number; // °C
  ambient_temperature_C: number; // °C
  feedwater_flow_th: number; // t/h
  feedwater_temperature_C: number; // °C
  feedwater_pressure_bar: number; // bar
  drum_level_mm: number; // mm
  furnace_draft_mbar: number; // mbar
  fan_speed_pct: number;
  damper_position_pct: number;
  flame_intensity_pct: number;
  economiser_fw_in_C: number;
  economiser_fw_out_C: number;
  economiser_gas_in_C: number;
  economiser_gas_out_C: number;
  economiser_duty_MW: number;
  economiser_effectiveness: number; // 0..1
  fouling_factor: number; // m2K/W
  blowdown_rate_pct: number; // % of feedwater
  blowdown_flow_th: number;
  condensate_return_pct: number;
  condensate_temp_C: number;
  // Efficiency & Loss Metrics
  boiler_efficiency_pct: number;
  combustion_efficiency_pct: number;
  thermal_efficiency_pct: number;
  stack_loss_pct: number;
  radiation_loss_pct: number;
  blowdown_loss_pct: number;
  incomplete_combustion_loss_pct: number;
  auxiliary_power_kW: number;
  co2_emission_rate_th: number; // tonnes/hour
  fuel_cost_per_hour: number; // GBP/hour
  steam_cost_per_tonne: number; // GBP/tonne
  // Quality & Diagnostic Flags
  o2_quality: QualityState;
  stack_temp_quality: QualityState;
  economiser_fouled: boolean;
  burner_unstable: boolean;
  fan_degraded: boolean;
  lastUpdated: string;
}

export interface HeatBalance {
  boilerId: string;
  total_fuel_energy_MW: number;
  useful_steam_energy_MW: number;
  stack_loss_MW: number;
  radiation_convection_loss_MW: number;
  blowdown_loss_MW: number;
  incomplete_combustion_loss_MW: number;
  unrecovered_economiser_loss_MW: number;
  auxiliary_consumption_MW: number;
  efficiency_pct: number;
}

export interface RootCauseHypothesis {
  id: string;
  boilerId: string;
  title: string;
  description: string;
  probability: number; // 0..1
  confidence: number; // 0..1
  efficiency_impact_pp: number; // percentage points lost e.g. -0.7
  economic_impact_gbp_day: number;
  evidence: string[];
  recommended_action: string;
  category: 'COMBUSTION' | 'HEAT_TRANSFER' | 'BLOWDOWN' | 'SENSOR_FAULT' | 'MECHANICAL';
}

export interface OptimisationRun {
  id: string;
  timestamp: string;
  objective: OptimisationObjective;
  total_steam_demand_th: number;
  current_total_fuel_cost_gbp_h: number;
  optimised_total_fuel_cost_gbp_h: number;
  expected_hourly_savings_gbp: number;
  expected_annual_savings_gbp: number;
  expected_co2_reduction_t_y: number;
  constraints_checked: {
    combustion_stability: boolean;
    emissions_limits: boolean;
    minimum_safe_air: boolean;
    burner_turndown: boolean;
    steam_header_pressure: boolean;
  };
  recommendations: BoilerRecommendation[];
}

export interface BoilerRecommendation {
  boilerId: string;
  boilerName: string;
  current_load_th: number;
  recommended_load_th: number;
  current_o2_pct: number;
  recommended_o2_pct: number;
  current_air_fuel_ratio: number;
  recommended_air_fuel_ratio: number;
  expected_efficiency_gain_pp: number;
  expected_cost_saving_gbp_h: number;
  explanation: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXECUTED';
}

export interface WorkOrder {
  id: string;
  boilerId: string;
  title: string;
  component: string;
  priority: AlarmPriority;
  status: 'OPEN' | 'IN_PROGRESS' | 'COMPLETED';
  created_at: string;
  assigned_to: string;
  description: string;
  checklist: { task: string; completed: boolean }[];
  expected_payback_days: number;
  before_efficiency_pct?: number;
  after_efficiency_pct?: number;
}

export interface AlarmItem {
  id: string;
  boilerId: string;
  boilerName: string;
  title: string;
  priority: AlarmPriority;
  timestamp: string;
  acknowledged: boolean;
  category: string;
  value: string;
}

export interface PriceConfig {
  natural_gas_gbp_mwh: number;
  refinery_gas_gbp_mwh: number;
  electricity_gbp_mwh: number;
  carbon_gbp_tonne: number;
  water_gbp_m3: number;
}

export interface MasterDemoState {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  step: number;
  maxSteps: number;
  active: boolean;
}
