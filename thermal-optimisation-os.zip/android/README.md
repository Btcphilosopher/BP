# KOTLIN INDUSTRIAL OPERATOR APPLICATION

Built with Jetpack Compose, Material 3, Coroutines, StateFlow, Room DB, DataStore, and Ktor client.

Designed for field engineers and operators in dense industrial environments:
- Dark steel high-density typography UI.
- Offline-first Room database for maintenance work order checklists.
- Before/after thermal verification workflows.
- Real-time Bluetooth/Local Wi-Fi telemetry sync.
