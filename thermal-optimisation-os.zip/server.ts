/**
 * THERMAL OPTIMISATION OS - EXPRESS SERVER ENTRY POINT
 * Binds to Port 3000, Host 0.0.0.0
 * Serves Vite middleware in development or static dist in production.
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { globalSimulation } from './src/lib/simulationEngine';
import { calculateBoilerEfficiency, convertUnits } from './src/lib/thermodynamics';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI Client (Server-side only)
  let ai: GoogleGenAI | null = null;
  if (process.env.GEMINI_API_KEY) {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // Periodic simulation tick every 1 sec
  setInterval(() => {
    globalSimulation.tick();
  }, 1000);

  // --------------------------------------------------------------------------
  // REST API ENDPOINTS (/api/*)
  // --------------------------------------------------------------------------

  // 1. Plant Summary
  app.get('/api/plants', (req, res) => {
    const boilers = globalSimulation.getBoilers();
    const active = boilers.filter((b) => b.status === 'ONLINE');
    const totalSteam = boilers.reduce((sum, b) => sum + b.steam_flow_th, 0);
    const totalFuelKw = boilers.reduce((sum, b) => sum + b.fuel_flow_kg_s * 47.1 * 1000, 0); // kW
    const totalFuelMw = totalFuelKw / 1000;
    const avgEff = active.length > 0
      ? active.reduce((sum, b) => sum + b.boiler_efficiency_pct, 0) / active.length
      : 0;
    const totalCo2Th = boilers.reduce((sum, b) => sum + b.co2_emission_rate_th, 0);
    const totalCostH = boilers.reduce((sum, b) => sum + b.fuel_cost_per_hour, 0);

    res.json({
      plantName: 'North Sea Process Plant & Refinery',
      status: 'OPERATIONAL',
      activeBoilers: `${active.length} / ${boilers.length}`,
      totalSteam_th: Number(totalSteam.toFixed(1)),
      totalFuel_MW: Number(totalFuelMw.toFixed(1)),
      overallEfficiency_pct: Number(avgEff.toFixed(2)),
      co2EmissionRate_th: Number(totalCo2Th.toFixed(2)),
      fuelCostPerHour_gbp: Number(totalCostH.toFixed(2)),
      steamHeaderPressure_bar: 62.5,
      steamHeaderTemp_C: 438,
      mode: 'SIMULATION',
    });
  });

  // 2. All Boilers
  app.get('/api/boilers', (req, res) => {
    res.json(globalSimulation.getBoilers());
  });

  // 3. Single Boiler
  app.get('/api/boilers/:id', (req, res) => {
    const boiler = globalSimulation.getBoilers().find((b) => b.id === req.params.id);
    if (!boiler) {
      return res.status(404).json({ error: 'Boiler not found' });
    }
    res.json(boiler);
  });

  // 4. Boiler Efficiency & Heat Balance
  app.get('/api/boilers/:id/efficiency', (req, res) => {
    const boiler = globalSimulation.getBoilers().find((b) => b.id === req.params.id);
    if (!boiler) {
      return res.status(404).json({ error: 'Boiler not found' });
    }
    const calc = calculateBoilerEfficiency(boiler, 'NATURAL_GAS');
    res.json(calc);
  });

  // 5. Diagnostics / Root Causes
  app.get('/api/boilers/:id/diagnostics', (req, res) => {
    const hypotheses = globalSimulation.getDiagnosticsForBoiler(req.params.id);
    res.json({ boilerId: req.params.id, hypotheses });
  });

  // 6. Multi-Objective Optimisation Run
  app.post('/api/optimisation/run', (req, res) => {
    const objective = req.body.objective || 'COST_MINIMUM';
    const result = globalSimulation.runOptimisation(objective);
    res.json(result);
  });

  // 7. Master Demo Execution
  app.post('/api/master-demos/:demoId/run', (req, res) => {
    const demoId = parseInt(req.params.demoId, 10);
    const step = req.body.step !== undefined ? parseInt(req.body.step, 10) : undefined;
    const result = globalSimulation.runMasterDemo(demoId, step);
    res.json(result);
  });

  // 8. Work Orders
  app.get('/api/maintenance/work-orders', (req, res) => {
    res.json(globalSimulation.getWorkOrders());
  });

  // 9. Alarms
  app.get('/api/alarms', (req, res) => {
    res.json(globalSimulation.getAlarms());
  });

  // 10. Thermal AI Assistant (Server-side Gemini 3.8 Flash call)
  app.post('/api/ai/assistant', async (req, res) => {
    const { prompt, boilerId } = req.body;
    const boilers = globalSimulation.getBoilers();
    const plantContext = JSON.stringify(boilers.map((b) => ({
      id: b.id,
      name: b.name,
      efficiency: b.boiler_efficiency_pct,
      load_th: b.steam_flow_th,
      o2: b.o2_pct,
      co: b.co_ppm,
      stack_temp: b.stack_temperature_C,
      economiser_fouled: b.economiser_fouled,
      cost_h: b.fuel_cost_per_hour,
    })), null, 2);

    if (!ai) {
      // Fallback response if GEMINI_API_KEY is missing
      const targetB = boilers.find((b) => b.id === boilerId) || boilers[2];
      return res.json({
        answer: `[THERMAL ENGINE DIAGNOSTIC RESULT]\n\nRegarding ${targetB.name}:\n- Current Efficiency: ${targetB.boiler_efficiency_pct}%\n- Flue Gas O2: ${targetB.o2_pct}%\n- Stack Temperature: ${targetB.stack_temperature_C}°C\n\nPhysical Model Analysis: Stack temperature elevation indicates gas-side economiser fouling. Excess oxygen at ${targetB.o2_pct}% contributes +0.6pp to dry gas heat loss. Re-tuning the O2 trim curve and scheduling fin washing yields an estimated £${(targetB.fuel_cost_per_hour * 0.012 * 24 * 365).toFixed(0)} annual fuel savings with safe combustion limits preserved.`,
        citedTelemetry: {
          boilerId: targetB.id,
          efficiency_pct: targetB.boiler_efficiency_pct,
          o2_pct: targetB.o2_pct,
          stack_temp_C: targetB.stack_temperature_C,
        },
      });
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are Thermal AI Assistant, a principal thermodynamicist and combustion control engineer for Thermal Optimisation OS. Answer the operator query using exact physical principles and citing live plant telemetry.

CURRENT LIVE BOILER FLEET TELEMETRY:
${plantContext}

OPERATOR QUERY:
${prompt || 'Analyze fleet efficiency and identify primary thermal loss locations.'}`,
        config: {
          systemInstruction: 'You are an elite industrial combustion & thermodynamic engineer. Speak with professional engineering precision. Citing specific O2, stack temperature, efficiency percentages, and monetary savings. Never invent non-existent sensor values.',
        },
      });

      res.json({
        answer: response.text,
        timestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      res.status(500).json({
        error: 'Failed to generate AI thermal response',
        details: err.message,
      });
    }
  });

  // 11. OpenAPI YAML Specification Endpoint
  app.get('/api/openapi.yaml', (req, res) => {
    res.type('text/yaml').send(`
openapi: 3.0.3
info:
  title: Thermal Optimisation OS API
  version: 1.0.0
  description: Enterprise Industrial Boiler Efficiency & Digital Twin Platform API
paths:
  /api/plants:
    get:
      summary: Get overall plant thermal summary metrics
      responses:
        '200':
          description: Plant state object
  /api/boilers:
    get:
      summary: List all active boiler states in fleet
  /api/boilers/{id}:
    get:
      summary: Get detailed runtime telemetry for a specific boiler
  /api/optimisation/run:
    post:
      summary: Execute multi-objective thermal dispatch solver
  /api/master-demos/{demoId}/run:
    post:
      summary: Run master demonstration scenario step
`);
  });

  // --------------------------------------------------------------------------
  // VITE / STATIC SERVING
  // --------------------------------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Thermal Optimisation OS running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
