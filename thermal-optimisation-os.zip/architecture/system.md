# THERMAL OPTIMISATION OS - ARCHITECTURE SPECIFICATION

## System Computational Graph

```
PLANT
→ BOILER HOUSE
  → BOILER 01..05
    → BURNER
    → FUEL SYSTEM
    → COMBUSTION AIR SYSTEM
    → FLAME & FURNACE
    → HEAT TRANSFER SURFACES
    → DRUM & STEAM HEADER
    → PROCESS LOAD

FURNACE
→ FLUE GAS
→ ECONOMISER
→ AIR PREHEATER
→ STACK

STEAM
→ PROCESS
→ CONDENSATE RETURN
→ DEAERATOR
→ FEEDWATER
→ BOILER
```

## Control Safety Boundary

```
+-------------------------------------------------------------+
|                THERMAL OPTIMISATION OS                      |
| (State Estimation, Digital Twin, Multi-Objective Dispatch)  |
+-------------------------------------------------------------+
                              |
                     [ SHADOW / ADVISORY ]
                              v
+-------------------------------------------------------------+
|                INDUSTRIAL CONTROL LAYER                     |
|           DCS / SCADA / PLC / BMS / SIS / ESD               |
|    (Hardwired Interlocks, Cross-Limiting, Flame Safety)     |
+-------------------------------------------------------------+
                              |
                              v
                   PHYSICAL BOILER PLANT
```

The Thermal Optimisation OS operates strictly above the safety instrumented layer.
All recommendations must pass lower-level BMS/DCS cross-limiting safety checks before operator actuation.
