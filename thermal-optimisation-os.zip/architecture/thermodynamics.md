# THERMODYNAMIC ASSUMPTIONS & FORMULATIONS

## 1. ASME PTC 4.1 Boiler Efficiency (Loss Method)

$$\eta_{boiler} = 100 - (L_{stack} + L_{incomplete} + L_{radiation} + L_{blowdown})$$

### Stack Loss ($L_{stack}$)
Calculated via Siegert Formula:
$$L_{stack} = K \cdot \frac{T_{stack} - T_{ambient}}{CO_2\%} + L_{latent}$$

Where $K = 0.37$ for Natural Gas, $0.38$ for Refinery Fuel Gas, $0.32$ for Hydrogen Blends.

### Excess Air ($\lambda$)
$$\lambda = \frac{21.0}{21.0 - O_2\%} - 1.0$$

## 2. Steam & Feedwater Enthalpy
Superheated steam enthalpy approximation (ASME/IAPWS-IF97 formulation):
$$h_s(P, T) = 2675.0 + 1.98 \cdot T + 0.0008 \cdot T^2 - 0.85 \cdot P \quad [\text{kJ/kg}]$$

Feedwater liquid enthalpy:
$$h_{fw}(T) = 4.187 \cdot T \quad [\text{kJ/kg}]$$

## 3. Economiser Effectiveness ($\epsilon$)
$$\epsilon = \frac{T_{fw,out} - T_{fw,in}}{T_{gas,in} - T_{fw,in}}$$

Fouling factor $R_f$:
$$R_f = \frac{1}{U_{dirty}} - \frac{1}{U_{clean}} \quad [\text{m}^2\cdot\text{K/W}]$$
