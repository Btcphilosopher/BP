# RUST COMPUTATIONAL CORE (thermal-core)

The Rust module owns high-performance, deterministic operations for time-series ingestion, matrix constraint solving, and microsecond digital twin state-space execution.

## Sub-packages:
- `combustion/`: High-speed stoich chemistry solver.
- `boiler-model/`: Deterministic state machine.
- `optimiser/`: Fast MILP load allocation solver.
- `telemetry/`: High-throughput time-series validation (10,000+ points/sec).
